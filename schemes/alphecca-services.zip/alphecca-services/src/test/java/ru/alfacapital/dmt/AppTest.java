package ru.alfacapital.dmt;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import ru.alfacapital.alphecca.services.legacy.data.dao.PositionDao;
import ru.alfacapital.alphecca.services.legacy.reports.ReportBuilder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.text.ParseException;
import java.text.SimpleDateFormat;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:context-test.xml"})
public class AppTest {
    Logger log = LoggerFactory.getLogger(AppTest.class);

    static java.sql.Date getDate(String date) {
        try {
            return new java.sql.Date(new SimpleDateFormat("dd.MM.yyyy").parse(date).getTime());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    @Autowired
    private PositionDao positionDao;

    @Autowired
    private ReportBuilder reportBuilder;

    public PositionDao getPositionDao() {
        return positionDao;
    }

//    @Test
//    public void make() throws ParseException {
//        System.out.println("==============================");
//        System.out.println("");
//
////        PositionResponse2 positionResponse = positionDao.getContractPosition2("24604", "1153021", getDate("05.02.2015"));
////
////        System.out.println("");
////        System.out.println("==============================");
////
////        for (PrimitivePosition pp : positionResponse.positions) {
////            log.info(pp.toString());
////        }
//
//        reportBuilder.buildPositionsJSON("24604", "1153021", getDate("05.02.2015"));
//
//        assert true;
//    }

    //http://localhost:8080/alphecca-services/rest/portfolio/position/contractId/2952930212/dateDQ/5472?investorId=2854866627
    @Test
    public void deposit$notesDateError_XML() {

    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.newDocument();

            Element reports = doc.createElement("reports");
            doc.appendChild(reports);

            Element report = doc.createElement("report");
            reports.appendChild(report);

            log.info(reportBuilder.buildPositionsXML(doc, report, "2868563399", "2870046462", getDate("31.10.2014")).toString());
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }

}

    @Test
    public void deposit$notesDateError_JSON() {
        //761/PM-LE-2011 Рыскина Татьяна Михайловна
        log.info(reportBuilder.buildPositionsJSON("24825", "1153062", getDate("14.04.2015")));
        assert true;
    }
}
