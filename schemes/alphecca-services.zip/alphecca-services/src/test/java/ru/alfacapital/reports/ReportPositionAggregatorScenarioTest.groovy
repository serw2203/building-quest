package ru.alfacapital.reports

import org.junit.Test
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover

class ReportPositionAggregatorScenarioTest extends AbstractReportPositionAggregatorTest {

    @Test
    void basicScenario() {
        def maturityDate = toDate("31.01.17")

        // DMT1 A1
        Turnover turnover = new Turnover(
                assetId: "1",
                dol: "1",
                date: toDate("01.01.01"),
                remainingQty: 10,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << turnover

        // DMT2 A1
        Turnover turnover2 = new Turnover(
                assetId: "1",
                dol: "2",
                date: toDate("01.01.02"),
                remainingQty: 20,
                price: 110.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << turnover2

        // A1(1)
        Turnover turnover3 = new Turnover(
                assetId: "1",
                dol: "not used 1",
                date: toDate("01.01.03"),
                remainingQty: 30,
                price: 120.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << turnover3

        // A1(2)
        Turnover turnover4 = new Turnover(
                assetId: "1",
                dol: "not used 2",
                date: toDate("01.01.04"),
                remainingQty: 40,
                price: 200.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << turnover4

        // A2
        Turnover turnover5 = new Turnover(
                assetId: "2",
                dol: "not used 3",
                date: toDate("01.01.01"),
                remainingQty: 50,
                price: 0.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << turnover5

        // DMT1 A1
        balances << new Balance(
                assetId: "1",
                positionSize: 10,
                positionValueRub: (10 * 120.420 * RATES["EUR"]),
                dol: "1",
                assetClass: "Облигация",
                isin: "ABC100500",
                positionName: "Облигация ABC100500",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 0,
                positionValueRub: (10 * 12.420 *  RATES["EUR"]),
                dol: "1",
                assetClass: null,
                isin: null,
                positionName: "НКД",
                maturityDate: null,
                ACI: true,
                security: false,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: null,
                positionSize: 0,
                positionValueRub: (10 * 120.420 *  RATES["EUR"]),
                dol: "1",
                assetClass: "Депозиты",
                isin: null,
                positionName: "Депозит",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "EUR",
        )
        balances << new Balance(
                assetId: null,
                positionSize: 0,
                positionValueRub: -(10 * 120.420 *  RATES["EUR"]),
                dol: "1",
                assetClass: "Прочее",
                isin: null,
                positionName: "Займ",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "EUR"
        )

        // DMT2 A1
        balances << new Balance(
                assetId: "1",
                positionSize: 20,
                positionValueRub: (20 * 120.420 *  RATES["EUR"]),
                dol: "2",
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 0,
                positionValueRub: (20 * 12.420 *  RATES["EUR"]),
                dol: "2",
                assetClass: null,
                isin: null,
                positionName: "НКД",
                maturityDate: null,
                ACI: true,
                security: false,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: null,
                positionSize: 0,
                positionValueRub: (20 * 120.420 *  RATES["USD"]),
                dol: "2",
                assetClass: "Депозиты",
                isin: null,
                positionName: "Депозит",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "USD",
        )
        balances << new Balance(
                assetId: null,
                assetClass: "Прочее",
                positionSize: 0,
                positionValueRub: -(20 * 120.420 *  RATES["USD"]),
                dol: "2",
                isin: null,
                positionName: "Займ",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "USD"
        )

        // A1 (1+2)
        balances << new Balance(
                assetId: "1",
                positionSize: 70,
                positionValueRub: (70 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 0,
                positionValueRub: (70 * 12.420 *  RATES["EUR"]),
                dol: null,
                assetClass: null,
                isin: null,
                positionName: "НКД",
                maturityDate: null,
                ACI: true,
                security: false,
                valuationCurrency: "EUR"
        )

        // A2
        balances << new Balance(
                assetId: "2",
                positionSize: 20,
                positionValueRub: (20 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "2",
                positionSize: 30,
                positionValueRub: (30 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )

        // Прочее
        balances << new Balance(
                assetId: null,
                positionSize: 0,
                positionValueRub: -1000,
                dol: null,
                assetClass: "Расчёты",
                isin: null,
                positionName: "Расчёты с AIML",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "USD"
        )
        balances << new Balance(
                assetId: null,
                positionSize: 0,
                positionValueRub: 555,
                dol: null,
                assetClass: "Денежные средства",
                isin: null,
                positionName: "р/c Альфа-Банк",
                maturityDate: null,
                ACI: false,
                security: false,
                valuationCurrency: "RUB"
        )


        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 14 == balances.size()
        assert 5 == turnovers.size()
        assert 7 == positions.size()
//        def first = positions.first()
//        assert reportDate == first.buyDate
//        assert 42 == first.qty
//        assert 100.50 == first.buyPrice
//        assert 42*100.5 == first.buyValue
//        assert 120.42 == first.currentPrice
//        assert 42 * 120.42 == first.currentValue
//        assert "Рога и копыта" == first.description
    }


}
