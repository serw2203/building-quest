package ru.alfacapital.reports

import org.junit.Test
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover

import java.text.SimpleDateFormat

import static org.junit.Assert.assertEquals

class ReportPositionAggregatorTest extends AbstractReportPositionAggregatorTest{

    @Test
    void emptyTurnoversAndBalances() {
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assertEquals(0, positions.size())
    }

    @Test
    void notMatchingBalanceForTurnover() {
        turnovers << new Turnover(
                assetId: "1",
                dol: "-1",
                date: toDate("2.02.14"),
                remainingQty: 42,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )
        balances << new Balance(
            assetClass: "Облигации",
            positionValue:  0,
            assetId: "2",
            positionSize: 42

        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)

        checkExpectation positions[0], [
                assetClass: "Облигации",
                qty: 42
        ]

    }

    @Test
    void notMatchingCurrencies() {
        def maturityDate = new SimpleDateFormat("dd.MM.yy").parse("31.01.17")
        turnovers << new Turnover(
                assetId: "1",
                dol: "-1",
                date: toDate("2.02.14"),
                remainingQty: 42,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 42,
                positionValueRub: (42 * 120.420 * RATES["RUB"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: maturityDate,
                ACI: false,
                security: true,
                valuationCurrency: "RUB"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)

        checkExpectation positions[0], [
                assetClass: "Облигации",
                buyDate: toDate("2.02.14"),
                buyPrice: 100.5*RATES["EUR"],
                buyValue: 42*100.5*RATES["EUR"],
                currency: "RUB",
                currentPrice: 120.42,
                currentValue: 42 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 42
        ]
    }

    @Test
    void oneTurnover() {
        turnovers << new Turnover(
                assetId: "1",
                dol: "-1",
                date: toDate("2.02.14"),
                remainingQty: 42,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )

        balances << new Balance(
                assetId: "1",
                positionSize: 42,
                positionValueRub: (42 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
        assert 0 == positions[0].subPositions.size()
        checkExpectation positions[0], [
                assetClass: "Облигации",
                buyDate: toDate("2.02.14"),
                buyPrice: 100.50,
                buyValue: 42*100.5,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 42 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 42
        ]
    }

    @Test
    void twoTurnoversOneBalance() {
        turnovers << new Turnover(
                assetId: "1",
                dol: "-1",
                date:  toDate("2.02.14"),
                remainingQty: 42,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )
        turnovers << new Turnover(
                assetId: "1",
                dol: "-2",
                date:  toDate("5.02.14"),
                remainingQty: 100,
                price: 100.200,
                aciPrice: 0,
                currency: "EUR"
        )

        balances << new Balance(
                assetId: "1",
                positionSize: 142,
                positionValueRub: (142 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигация",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )

        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 2 == positions.size()
        checkExpectation positions[0], [
                buyDate: toDate("2.02.14"),
                buyPrice: 100.50,
                buyValue: 42 * 100.5,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 42 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 42
        ]
        checkExpectation positions[1], [
                buyDate: toDate("5.02.14"),
                buyPrice: 100.200,
                buyValue: 100 * 100.200,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 100 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 100
        ]
    }


    @Test
    void oneTurnoverSeveralPositions() {
        turnovers << new Turnover(
                assetId: "1",
                dol: "-1",
                date:  toDate("2.02.14"),
                remainingQty: 42,
                price: 100.500,
                aciPrice: 0,
                currency: "EUR"
        )

        balances << new Balance(
                assetId: "1",
                positionSize: 142,
                positionValueRub: (142 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигация",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )

        balances << new Balance(
                assetId: "2",
                positionSize: 99,
                positionValueRub: (99 * 42.42 * RATES["USD"]),
                dol: null,
                assetClass: "Облигация",
                isin: "ABC100501",
                positionName: "Нечто из другого мира",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "USD"
        )


        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 3 == positions.size()
        checkExpectation positions[0], [
                buyDate: toDate("2.02.14"),
                buyPrice: 100.50,
                buyValue: 42 * 100.5,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 42 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 42
        ]
        checkExpectation positions[1], [
                buyDate: null,
                buyPrice: null,
                buyValue: null,
                currency: "USD",
                currentPrice: 42.42,
                currentValue: 99 * 42.42,
                description: "Нечто из другого мира",
                maturityDate: toDate("31.01.17"),
                qty: 99
        ]
        checkExpectation positions[2], [
                buyDate: null,
                buyPrice: null,
                buyValue: null,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 100 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 100
        ]

    }

    @Test
    void dmt() {
        turnovers << new Turnover(
                assetId: "111",
                dol: "777",
                date:  toDate("2.02.14"),
                remainingQty: 10930,
                price: 40.5,
                aciPrice: 0,
                currency: "RUB"
        )

        balances << new Balance(
                assetId: "111",
                positionSize: 10930,
                positionValueRub: (10930 * 42.42),
                dol: "777",
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                assetId: "111",
                positionSize: 0,
                positionValueRub: 100500,
                dol: "777",
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "НКД",
                ACI: true,
                security: false,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                positionSize: 0,
                positionValueRub: 42000,
                dol: "777",
                assetClass: "Депозиты",
                positionName: "ОАО \"Alfa-Bank\"",
                maturityDate: toDate("28.07.23"),
                ACI: false,
                security: false,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                positionSize: 0,
                positionValueRub: -142000.50,
                dol: "777",
                assetClass: "Прочее",
                positionName: "Расчёты c AIML",
                ACI: false,
                security: false,
                valuationCurrency: "RUB"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
        checkExpectation positions[0], [
                buyDate: toDate("2.02.14"),
                buyPrice: null,
                buyValue: 40000,
                currency: "RUB",
                currentPrice: null,
                currentValue: 10930 * 42.42 + 100500 + 42000 - 142000.50,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: null
        ]
        def subPositions = positions[0].subPositions
        assert 4 == subPositions.size()
        checkExpectation subPositions[0], [
                buyPrice: 40.50,
                buyValue: 10930 * 40.5,
                currentPrice: 42.42,
                currentValue: 10930 * 42.42,
                description: "ABC100500",
                qty: 10930
        ]
        checkExpectation subPositions[1], [
                description: "НКД",
                currentValue: 100500
        ]
        checkExpectation subPositions[2], [
                description: "Собственные средства",
                currentValue: 42000
        ]
        checkExpectation subPositions[3], [
                description: "Займ",
                currentValue: -142000.50
        ]

    }

    @Test
    void dmtDifferentDepositAndAssetCurrency() {
        turnovers << new Turnover(
                assetId: "111",
                dol: "777",
                date:  toDate("2.02.14"),
                remainingQty: 100,
                price: 5,
                aciPrice: 0,
                currency: "RUB"
        )

        balances << new Balance(
                assetId: "111",
                positionSize: 100,
                positionValueRub: 500,
                dol: "777",
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                assetId: "111",
                positionSize: 0,
                positionValueRub: 4,
                dol: "777",
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "НКД",
                ACI: true,
                security: false,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                positionSize: 0,
                positionValueRub: 42000,
                dol: "777",
                assetClass: "Депозиты",
                positionName: "ОАО \"Alfa-Bank\"",
                maturityDate: toDate("28.07.23"),
                ACI: false,
                security: false,
                valuationCurrency: "RUB"
        )
        balances << new Balance(
                positionSize: 0,
                positionValueRub: -142000.50,
                dol: "777",
                assetClass: "Прочее",
                positionName: "Расчёты c AIML",
                ACI: false,
                security: false,
                valuationCurrency: "RUB"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
        checkExpectation positions[0], [
                buyDate: toDate("2.02.14"),
                buyPrice: null,
                buyValue: 40000,
                currency: "RUB",
                currentPrice: null,
                currentValue: 10930 * 42.42 + 100500 + 42000 - 142000.50,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: null
        ]
        def subPositions = positions[0].subPositions
        assert 4 == subPositions.size()
        checkExpectation subPositions[0], [
                buyPrice: 40.50,
                buyValue: 10930 * 40.5,
                currentPrice: 42.42,
                currentValue: 10930 * 42.42,
                description: "ABC100500",
                qty: 10930
        ]
        checkExpectation subPositions[1], [
                description: "НКД",
                currentValue: 100500
        ]
        checkExpectation subPositions[2], [
                description: "Собственные средства",
                currentValue: 42000
        ]
        checkExpectation subPositions[3], [
                description: "Займ",
                currentValue: -142000.50
        ]

    }

    @Test
    void twoBalancesForOneTurnover() {
        turnovers << new Turnover(
                assetId: "2",
                dol: "123",
                date: toDate("01.01.01"),
                remainingQty: 50,
                price: 0.500,
                aciPrice: 0,
                currency: "EUR"
        )

        balances << new Balance(
                assetId: "2",
                positionSize: 20,
                positionValueRub: (20 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "2",
                positionSize: 30,
                positionValueRub: (30 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
    }

    @Test
    void simpleAssetAndACI() {
        turnovers <<  new Turnover(
                assetId: "1",
                dol: "not used 1",
                date: toDate("01.01.03"),
                remainingQty: 30,
                price: 120.500,
                aciPrice: 0,
                currency: "EUR"
        )

        balances << new Balance(
                assetId: "1",
                positionSize: 30,
                positionValueRub: (30 * 120.420 *  RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100501",
                positionName: "Облигация ABC100501",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 0,
                positionValueRub: (30 * 12.420 *  RATES["EUR"]),
                dol: null,
                assetClass: null,
                isin: null,
                positionName: "НКД",
                maturityDate: null,
                ACI: true,
                security: false,
                valuationCurrency: "EUR"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
        checkExpectation positions[0], [
                buyDate: toDate("01.01.03"),
                buyPrice: null,
                buyValue:  30 * 120.5,
                currency: "EUR",
                currentPrice: null,
                currentValue: 30 * 120.420  + 30 * 12.420,
                description: "Облигация ABC100501",
                maturityDate: toDate("31.01.17"),
                qty: null
        ]
        def subPositions = positions[0].subPositions
        assert 2 == subPositions.size()
        checkExpectation subPositions[0], [
                buyPrice: 120.5,
                buyValue: 30 * 120.5 ,
                currentPrice: 120.42,
                currentValue: 30 * 120.42,
                description: "ABC100501",
                qty: 30
        ]
        checkExpectation subPositions[1], [
                description: "НКД",
                currentValue: 30 * 12.420
        ]
    }

    @Test
    void noZeroQuantityPositions() {

        balances << new Balance(
                assetId: "1",
                positionSize: 0,
                positionValueRub: (42 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )

        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 0 == positions.size()
    }

    @Test
    void restOfBalancesShouldBeSummarized() {
        balances << new Balance(
                assetId: "1",
                positionSize: 10,
                positionValueRub: (10 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        balances << new Balance(
                assetId: "1",
                positionSize: 5,
                positionValueRub: (5 * 120.420 * RATES["EUR"]),
                dol: null,
                assetClass: "Облигации",
                isin: "ABC100500",
                positionName: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                ACI: false,
                security: true,
                valuationCurrency: "EUR"
        )
        def positions = aggregator.aggregate(turnovers, balances, reportDate)
        assert 1 == positions.size()
        checkExpectation positions[0], [
                assetClass: "Облигации",
                buyDate: null,
                buyPrice: null,
                buyValue: null,
                currency: "EUR",
                currentPrice: 120.42,
                currentValue: 15 * 120.42,
                description: "Рога и копыта",
                maturityDate: toDate("31.01.17"),
                qty: 15
        ]
    }


}
