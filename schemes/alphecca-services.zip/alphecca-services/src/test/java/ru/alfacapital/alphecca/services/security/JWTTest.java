package ru.alfacapital.alphecca.services.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import net.oauth.jsontoken.*;
import net.oauth.jsontoken.crypto.HmacSHA256Verifier;
import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import net.oauth.jsontoken.crypto.Verifier;
import net.oauth.jsontoken.discovery.*;
import org.apache.commons.codec.binary.Base64;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Duration;
import org.joda.time.Instant;
import org.junit.Before;
import org.junit.Test;
import org.springframework.util.StringUtils;

import javax.crypto.*;
import javax.crypto.spec.DESedeKeySpec;
import java.io.IOException;
import java.security.*;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class JWTTest {

    private static final String OUR_TOKEN_STRING = "eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJBbGZhLUNhcGl0YWwiLCJwYXlsb2FkIjoiQk8xQktMenlpNFFyYVdHdTR1OHFPRythOXA4TzczT3pKZlpTQ255cG9lSDd6dXhDeW1KTk1nSnpEVlJCQnU2L0kvL1psdkF3Z0JoRmc3M0xidlkrMFB6Ky8wZGowNHdmMk5EZ1ZxL0JnNCs4a1d4c3pUaVBBeXVpdHFGeE5TcUpzMG1kVTJ4YzgrZEdBWmhHdUl0VGhiM3BJUTFkZ2x2V3Z0UVdMZWNjaWVTQ0p5VCtjQXh0cmIzUHpPZ2N5YjJyS09CTlFuUzhLU2NIN0tmRy80b2FtWE1JWlFIUjhkYlRHRnVuMVNtNU5jcG5reUZDS1ozR0pUeEx1bkNPa0dDTGVSMGpWNXRTc1RJcVlCbXMvcC9jajJsTndiTVI4NkxtWHpJTnhNMnBCYzlLaW5XbGk3NHBNcWFEZCtrazJ0OE9CV1pqMzVSSmEra0ZabVBmbEVscjZhbXplWlhRU2lGaWFuVlJxclRQM1Z3S3l6bVlobXBqV0dSSTlhTEdETTIwTWw0MEhwQzhxa1JsUUNjL1hmQU5CSFhyTG8zVGRMK2x4QWFzTDlQbk9kTzZoc3FqT2NyMFpuWXZLZE9QMFI2UXVlYTV5VnYzR0ZSLzBSTlJKc2xBUEFcdTAwM2RcdTAwM2QiLCJpYXQiOjE0MjI1MzIyNDUsImV4cCI6MTQyMjUzMjI0NX0.BRSeVlZo9A8JGeDJ1Nd8TLf9fp9kmbx4OiCUMwNC2U0";
    //public static String AC_TOKEN_STRING ="eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJBbGZhLUJhbmsiLCJpYXQiOjE0MjExNjkwODgsImV4cCI6MTQyMTE3MDA4OCwicGF5bG9hZCI6ImpvQi9nMmErRFY4cVlCbXMvcC9jajc3VUZpM25ISW5rNGZkTGFNbWdwY2tIN0tmRy80b2FtWE1JWlFIUjhkYlRHRnVuMVNtNU5jb21sNXhWSFZaNXpIZHNCNXN4K0JCWGpnM0dzNUFOVitVbFRCWjg5ZDhCUnA4QnFWeUhRd00wWVpjZkJlaXBha1RlT29BNUUxaXBubS9mcXhocFlCY1F2cWVEUVRCdExjNXRBYWZLeEJpbzVid0RBV1Fsc2NaV2k2eFh0d29wWko0RlptUGZsRWxyNlFWbVk5K1VTV3ZwRy8vL0d3dXYwSmtcdTAwM2QifQ.QL1tmIyoYzdZwgkXymX-MPD2G16bQbArEPouQ9iWL4E";
//    public static String AC_TOKEN_STRING ="eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJBbGZhLUJhbmsiLCJpYXQiOjE0MjMyMTMzMzYsImV4cCI6MTQyMzIxNDMzNiwicGF5bG9hZCI6ImpvQi9nMmErRFY4cVlCbXMvcC9jajc3VUZpM25ISW5rNGZkTGFNbWdwY2tIN0tmRy80b2FtWE1JWlFIUjhkYlRHRnVuMVNtNU5jb21sNXhWSFZaNXpIZHNCNXN4K0JCWGpnM0dzNUFOVitVbFRCWjg5ZDhCUnA4QnFWeUhRd00wWVpjZkJlaXBha1RlT29BNUUxaXBubS9mcXhocFlCY1F2cWVEUVRCdExjNXRBYWZLeEJpbzVid0RBV1Fsc2NaV2k2eFh0d29wWko0RlptUGZsRWxyNlFWbVk5K1VTV3ZwRy8vL0d3dXYwSmtcdTAwM2QifQ.8cuWEkocq-Qtj5gqYzDz8OP6wqnzwdEKPiAdsvZ8XP0";
    public static String AC_TOKEN_STRING  = "eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJBbGZhLUJhbmsiLCJpYXQiOjE0MjQxNjQ4NjksImV4cCI6MTQyNDE2NTg2OSwicGF5bG9hZCI6ImpvQi9nMmErRFY4cVlCbXMvcC9jajc3VUZpM25ISW5rNGZkTGFNbWdwY2tIN0tmRy80b2FtWE1JWlFIUjhkYlRHRnVuMVNtNU5jb21sNXhWSFZaNXpIZHNCNXN4K0JCWGpnM0dzNUFOVitVbFRCWjg5ZDhCUnA4QnFWeUhRd00wWVpjZkJlaXBha1RlT29BNUUxaXBubS9mcXhocFlCY1F2cWVEUVRCdExjNXRBYWZLeEJpbzVid0RBV1Fsc2NaV0FDaUxIZVJVdlp6dFFNajhBY2s4TTFBbi9WRW1DR1hWakJ1cDUzOHcweUJwVGNHekVmT2k1bm5jYVNVMEllRVNheGthK2w3ZG9mNnIva3lBNm0zUUNtT3owWndWZzZmbUNoekpRQzNWZkNXTVpNSFFua0JWTVA5Y0hoaU04UjVOVGNhcXU5QXdOWlQ4aTlFNjhmOElGNVI1ZVVhTGluZG5VMFRCRW5xaVNyNTVEcmFVYjA1UngxTlhEaTdZK09IYjRwckNGOVlDaDJQVStUenlXK0tZZ2lJUlVPbzBpU3R5Qk9jaFUvYTFsYjdBa3I1UXAyVml3L21VZUlUczUrbFdQTTFRSUxacFZIS3VkSGpJOTVMSGFGQ200S1M2QVBIbU42VlhhN3hYQ2czRHhyQkJyS2M3czNld2FLaG5jUWtsZ0hyOFRQT0dTTEkxWDFkOFA0eHgrdGwvTGNWc09hK3VLdFNsNDNhK3BFZ0VSTDR4NThEU05UZkx2WmtILzRLK1lKVDd4MHFjN1BsNUI0Tkdsc1B0Tnp5M3hQNFRrNGVHOHp1YXF0cVNzbjFzenQyN1VMWjMvOEVUU1ZNSzZqN053N2RXRTBHTWZ2eS9xS0ZxT3l5cjIyWlhoRkFIRDJMMkNYaVRnc3ZyUXNlb2cxdVQ0S1JLeEpNZkp4Rno2cTAzL1p3WGtUYnhzcGRYTG9KcU1jZDFQL0Ftak1xVGVleUR5UXk4ZW13SHFWVzdGNTM2NTl6cWJ0VmNXNXNjWmtKcVcxUy9nMkxIVTRHdE1ZeVF0RytnQWtLeE5IMkIvNjJ1clBaR0hVdzZHa3VTY2pyNURyNlppeW8vcW1VSTNUQkMzaVQxYkp6a2lHWXRWVlpJOW9rM2tzK1lGZlhzczNYY094MDFuWkhtZFZNOThPQUdtWnVwQWE0UHhCaFljUEhyeEpDVUNUZ1RIWTNWamZSNlVLM2FFM3ZEblhyenFIaXVtVEdjWjJNQjdkSWFUUHBXWEVQelVlSG5ZZE5HWjZSdkxBRVozZWc0YThjcDRSMnJWYUZ1eEd2NjhOakxLV0dydXhhbDZRNUVEdTFQK2lQNXNobzErVkVrd0tEbUVEOUxiUUdueXNRWXFPVTdOUklBSnZDcklnUzRpM05mT2EyendFQnFPZWxpUElNT0czNmw1MnZrSW5xS1c4Mm8zQ1c4Q3RsTUMwcW9KUlliUE9QSldYTm5UN1RRT3lPYUp5WU1GUXUzbmVZSUx6d01yTklIUGpxMHpiRTlHT0ZVblAxay9GOEtwMURRdWF1OW9Vdy9NMmtOTkE5UWRvKytvUTJWU1VLV1VqT25mNmQzMmhHRkp4VFV2WStpOE9VUFlxdDM5ei9XR1E1VzJHbVFQbmFKL01iSXlPSTFHYzVEY1hjVDR0S0pkbHdVbkJmRXliUDNtMjhzTGdHNVkwbWY0aUZWaGxldC8zSDdKUHhTZCt4NXFxWU9RSmdvditxMDVpNUFjb0JnUitWRDZVTGZUSEhnVER3YUhIN3oxNGxQOWtrbXJKZE9Id3ZPOVY5WDNqZDRlSlduaEdUTk1uQVY4ajQ3TkhxRmxZU3VqVnBUQ3RydEptdzY3NVUxVHFMeFhRdklEeTVCR0pSc1BicjJiUXh1NTNuZVB5RDY2YTNBNlFLRllwcjVldzc3Rks4cWU3Z21GN1Y0ODRyRk5WME05aWZNbXVTNnZ1U2x0K1N2Y0xPSmJBNER0NlZCYWdSQXJYaEVWWWQ0dmwzNFF5aEx5TXdBV3h1OXVPZkhWOXh5N2tTM080ek5ZL1ZJTHEwK3lDVXJiN2VjemxJZ2RmK3N3OWVDIn0.5gK1G8kmDVR4_gJ2I2MOVPofD0voCjeGFjRdgOKT9-4";
    public static String TEST_TOKEN_STRING = "eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJBbGZhLUJhbmsiLCJpYXQiOjE0MTgzMDAxMDEsImV4cCI6MTQxODMwMTEwMSwicGF5bG9hZCI6ImpvQi9nMmErRFY5MFY3S3dibWZLdHczMHJuK1MrZk91M3dsS2pWaWNYSnJuTWJMSUJwWnNNcGxINTNYeGQwMDVHNjhtKzYvMnBDQjE2eTZOMDNTL3BRN1ZWaXZWd3oyN0kyc2JxcWdZUFkrWXd3T3pQOU80V29ibFFXRDJLbG13YndRRVh3b3hTeGoyNHN2OXBJQnhiMmxOd2JNUjg2TG1YeklOeE0ycEJjOU5VVlpmL0JBUE9HRmtoV1pqa2EvSlVpQjEvNnpEMTRJXHUwMDNkIn0.lCKhtbRmw5CIwoAG47XIaZDkjfv41PjCxBbuMntrklk";

    public static final String TEST_CRYPTO_KEY = "This is a test DESede key";

    public static final byte[] TEST_SIGNATURE = "AlfaBankTestKey".getBytes();

    private VerifierProviders locators;
    private Clock systemClock = new SystemClock();
    private FakeClock fakeClock = new FakeClock(Duration.standardMinutes(2));

    @Before
    public void setUp() throws Exception {
        final Verifier alfaBankVerifier = new HmacSHA256Verifier(TEST_SIGNATURE);

        VerifierProvider hmacLocator = new VerifierProvider() {
            @Override
            public List<Verifier> findVerifier(String signerId, String keyId) {
                if ("Alfa-Bank".equals(signerId)) {
                    return Lists.newArrayList(alfaBankVerifier);
                } else if ("Alfa-Capital".equals(signerId)){
                    return Lists.newArrayList(alfaBankVerifier);
                } else {
                    return null;
                }
            }
        };

        locators = new VerifierProviders();
        locators.setVerifierProvider(SignatureAlgorithm.HS256, hmacLocator);
    }


    private String decipherPayload(JsonToken token) throws GeneralSecurityException {
        String payload = token
                .getPayloadAsJsonObject()
                .getAsJsonPrimitive("payload")
                .getAsString();
        byte[] decodedBytes = Base64.decodeBase64(payload);

        String cipherName = "DESede";
        Cipher decipher = Cipher.getInstance(cipherName);
        DESedeKeySpec keySpec = new DESedeKeySpec(TEST_CRYPTO_KEY.getBytes());
        SecretKeyFactory skf = SecretKeyFactory.getInstance(cipherName);
        SecretKey key = skf.generateSecret(keySpec);
        decipher.init(Cipher.DECRYPT_MODE, key);

        return new String(decipher.doFinal(decodedBytes));
    }


    @Test
    public void decodeTestToken() throws GeneralSecurityException {
        DateTime dt = new DateTime(2014, 12, 11, 12, 15, 01, 0, DateTimeZone.UTC);
        fakeClock.setNow(dt.toInstant());
        JsonTokenParser parser = new JsonTokenParser(fakeClock, locators);
        JsonToken token = parser.verifyAndDeserialize(TEST_TOKEN_STRING);
        assertEquals("Alfa-Bank", token.getIssuer());
        String decipereString = decipherPayload(token);
        System.out.println(decipereString);
    }


    @Test
    public void myDecodeToken() throws GeneralSecurityException, IOException {
        MyJsonTokenParser parser = new MyJsonTokenParser(systemClock, locators);
        JsonToken token = parser.verifyAndDeserialize(AC_TOKEN_STRING);
        assertEquals("Alfa-Bank", token.getIssuer());
        String decipheredString = decipherPayload(token);
        System.out.println(decipheredString);

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> map = mapper.readValue(decipheredString, Map.class);
        String cus = (String) map.get("cus");
        String doucmentSeriesAndNumber = StringUtils.trimAllWhitespace((String) map.get("documentNumber"));
        String series = doucmentSeriesAndNumber.substring(0,4);
        String number = doucmentSeriesAndNumber.substring(4);

        assertEquals("AHQFL8", cus);
    }

    @Test
    public void decodeOurToken() throws GeneralSecurityException, IOException {
        MyJsonTokenParser parser = new MyJsonTokenParser(systemClock, locators);
        JsonToken token = parser.verifyAndDeserialize(OUR_TOKEN_STRING);
        assertEquals("Alfa-Capital", token.getIssuer());
        String decipheredString = decipherPayload(token);
        System.out.println(decipheredString);

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> map = mapper.readValue(decipheredString, Map.class);
        String cus = (String) map.get("cus");
        String doucmentSeriesAndNumber = StringUtils.trimAllWhitespace((String) map.get("documentNumber"));
        String series = doucmentSeriesAndNumber.substring(0,4);
        String number = doucmentSeriesAndNumber.substring(4);

        assertEquals("AHQFL8", cus);
    }


}

class FakeClock extends SystemClock {

    private Instant now = new Instant();

    public FakeClock() {
        super(Duration.ZERO);
    }

    public FakeClock(Duration acceptableClockSkew) {
        super(acceptableClockSkew);
    }

    public void setNow(Instant i) {
        now = i;
    }

    @Override
    public Instant now() {
        return now;
    }
}

