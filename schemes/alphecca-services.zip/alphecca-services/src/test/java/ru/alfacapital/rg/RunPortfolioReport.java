package ru.alfacapital.rg;

import org.apache.fop.apps.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import ru.alfacapital.alphecca.services.xml.XslTemplates;
import ru.ingie.commons.JDBCUtils;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;
import java.sql.*;

public class RunPortfolioReport {

    static Connection connect() throws SQLException {
        java.util.Properties info = new java.util.Properties();
        info.put("user", "user_webapp");
        info.put("password", "{eqL0uflftimcz!");
        info.put("defaultRowPrefetch","20");
        info.put("defaultBatchValue", "5");
        Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@bro-ln-srv114.corp.alfacapital.ru:1521:prod", info);
        connection.setAutoCommit(false);
        return connection;
    }

    public static void main(String[] args) throws IOException, TransformerException, ParserConfigurationException, SAXException, SQLException {
        Connection connection = null;
        try {
            connection = connect();
            processRequests(connection);
            connection.commit();
        }
        finally {
            JDBCUtils.close(connection);
        }
    }

    private static void processRequests(Connection connection) throws SQLException, ParserConfigurationException, IOException, SAXException, TransformerException {
        PreparedStatement stmt = null;
        try {
            // todo (1):
//            String sql = "select report_request_content_id, generated_xml, investor_id from ss.tab_report_request_content where generated_xml is not null";
//            String sql = "select report_request_content_id, generated_xml, investor_id from ss.tab_report_request_content where report_request_id = 932081 and generated_xml is not null";
//            String sql = "select report_request_content_id, generated_xml, investor_id from ss.tab_report_request_content where investor_id = 24444 and generated_xml is not null";
            // ЕСЛИ ДЕЛАЕМ ПЕРВЫЙ ПРОГОН, ХОТИМ ВСЕ ОТЧЁТЫ ИЗ ОЧЕРЕДИ ПРЕВРАТИТЬ В PDF
            String sql = "select report_request_content_id, generated_xml, investor_id from ss.tab_report_request_content where generated_xml is not null";
            stmt = connection.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String id = rs.getString(1);
                System.out.println(id);
                Blob blob = rs.getBlob(2);
                String investorId = rs.getString(3);
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.parse(blob.getBinaryStream());
//                processRequest(document, email, new ManagerPhotoResolver(connection));
                ByteArrayOutputStream out = processRequest(document);
//                todo (2): в БД или в файл
                saveReport(connection, out.toByteArray(), investorId);
                saveReportToFile(connection, out.toByteArray(), investorId);
                out.close();
            }
        }
        finally {
            JDBCUtils.close(stmt);
        }
    }

    private static void saveReport(Connection connection, byte[] data, String investorId) throws SQLException, IOException {
        String reportId = JDBCUtils.queryString(connection, "select ss.hibernate_sequence.nextval from sys.dual");
        PreparedStatement stmt = null;
        try {
            // todo: (3) !!! нолики и единички тоже очень важны
            stmt = connection.prepareStatement("insert into ss.tab_report values (?, to_date('31.10.2014', 'DD.MM.RRRR'), 'Отчёт о деятельности по доверительному управлению за Октябрь 2014.pdf', 'application/pdf', null, null, null, null, null, null, 0, ?, 0, 0, null, null, null, null, sysdate)");
            stmt.setString(1, reportId);
            stmt.setString(2, investorId);
            stmt.executeUpdate();
        }
        finally {
            JDBCUtils.close(stmt);
        }
        final ByteArrayInputStream in = new ByteArrayInputStream(data);
        writeBlob(connection, in, reportId);
        in.close();
    }

    private static void saveReportToFile(Connection connection, byte[] data, String investorId) throws SQLException, IOException {
        String name = JDBCUtils.queryString(connection, "select max(name) from ss.vie_ss_investor where investor_id = ?", investorId);
        name = name.replace('&', ' ').replace('"', ' ').replace('\'', ' ').replace('\\', ' ').replace('/', ' ');
        // todo: 4.
        FileOutputStream fos = new FileOutputStream("c:\\01234\\" + name + "___" + investorId + "___" + new java.util.Date().getTime() + ".pdf");
        fos.write(data);
        fos.close();
    }

    private static ByteArrayOutputStream processRequest(Document document) throws IOException, FOPException, TransformerException {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("classpath:data-sources-context.xml");
        FopFactory fopFactory = (FopFactory) ctx.getBean("fopFactory");
        XslTemplates xslTemplates = (XslTemplates) ctx.getBean("xslTemplates");
        ByteArrayOutputStream out = new ByteArrayOutputStream(400000);
        FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
        Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
        TransformerFactory factory = TransformerFactory.newInstance();
        StreamSource source = new StreamSource(xslTemplates.getXslPortfolioReportAsStream());
        Transformer transformer = factory.newTransformer(source);
        transformer.setParameter("versionParam", "2.0");
        Source src = new DOMSource(document);
        Result res = new SAXResult(fop.getDefaultHandler());
        transformer.transform(src, res);

        return out;
    }

    private static void writeBlob(Connection c, InputStream data, String id) throws SQLException, IOException {
        PreparedStatement pstmt = null;
        try {
            pstmt = c.prepareStatement("update ss.tab_report set report_body = ? where report_id = ?");
            pstmt.setBinaryStream(1, data);
            pstmt.setString(2, id);
            pstmt.executeUpdate();
        }
        finally {
            JDBCUtils.close(pstmt);
        }
    }

}
