package ru.alfacapital.rg;

import org.apache.fop.apps.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import ru.alfacapital.alphecca.services.xml.XslTemplates;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class DebugPortfolioReport {

        public static void main(String[] args) throws IOException, TransformerException, ParserConfigurationException, SAXException {
            FileInputStream fis = new FileInputStream("C:\\work\\docs\\newReport.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(fis);
            ByteArrayOutputStream out = processRequest(document);
            saveReportToFile(out.toByteArray());
            out.close();

        }

        private static ByteArrayOutputStream processRequest(Document document) throws IOException, FOPException, TransformerException {
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("testContext.xml");
        FopFactory fopFactory = (FopFactory) ctx.getBean("fopFactory");
        XslTemplates xslTemplates = (XslTemplates) ctx.getBean("xslTemplates");

        ByteArrayOutputStream out = new ByteArrayOutputStream(400000);
        FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
        Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
        TransformerFactory factory = TransformerFactory.newInstance();
        StreamSource source = new StreamSource(xslTemplates.getXslPortfolioReportAsStream());
        Transformer transformer = factory.newTransformer(source);
        transformer.setParameter("versionParam", "2.0");
        Source src = new DOMSource(document);
        Result res = new SAXResult(fop.getDefaultHandler());
        transformer.transform(src, res);

        return out;
    }

    private static void saveReportToFile(byte[] data) throws IOException {
        FileOutputStream fos = new FileOutputStream("c:\\5\\report_" + new java.util.Date().getTime() + ".pdf");
        fos.write(data);
        fos.close();
    }


}
