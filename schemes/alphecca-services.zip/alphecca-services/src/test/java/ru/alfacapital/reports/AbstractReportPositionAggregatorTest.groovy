package ru.alfacapital.reports

import org.junit.Before
import ru.alfacapital.alphecca.services.legacy.DefaultCurrencyRater
import ru.alfacapital.alphecca.services.legacy.reports.ReportPositionAggregator
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover

import java.text.SimpleDateFormat

abstract class AbstractReportPositionAggregatorTest {
    def RATES = ["EUR": 47.1145,"USD": 34.6481,"RUB": 1]

    ReportPositionAggregator aggregator;
    List<Turnover> turnovers;
    List<Balance> balances;

    def dateFormat = new SimpleDateFormat("dd.MM.yy")
    def toDate = { String str -> dateFormat.parse( str) }
    def reportDate = toDate("30.04.14")

    def checkExpectation = { actual, Map expected ->
        expected.each { key, value ->
            assert value == actual[key]
        }
    }

    @Before
    void setUp() {
        final Map r = RATES;
        DefaultCurrencyRater currencyRater = new DefaultCurrencyRater() {
            @Override
            BigDecimal rate(BigDecimal value, String currency, Date date) {
                return value / r[currency]
            }
            @Override
            BigDecimal rate(BigDecimal value, String sourceCurrency, String targetCurrency, Date date) {
                return  (value / r[targetCurrency]) * r[sourceCurrency]
            }
        }
        aggregator = new ReportPositionAggregator(currencyRater: currencyRater)
        turnovers = new ArrayList<>()
        balances = new ArrayList<>()
    }

}
