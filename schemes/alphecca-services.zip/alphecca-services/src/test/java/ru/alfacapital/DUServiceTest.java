package ru.alfacapital;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ru.alfacapital.alphecca.services.legacy.du.DUServices;
import ru.alfacapital.schemas.survey.SurveyRequest;

import static junit.framework.TestCase.assertTrue;

/**
 * Created by a.khotov on 12.08.2015.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:/context-test.xml" })
public class DUServiceTest {

    @Autowired
    DUServices duServices;

    @Before
    public void setup(){
        System.setProperty("alphecca.deployment.profile", "investor");
        System.setProperty("alphecca.edf.services", "http://bro-ln-srv108:8080/du/services/ContractRegistrationService");
    }

    @Test
    public void test() {
        assertTrue(duServices.isNumber("1"));
    }

}
