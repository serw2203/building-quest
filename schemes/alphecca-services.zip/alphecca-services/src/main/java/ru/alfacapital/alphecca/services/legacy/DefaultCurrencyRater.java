package ru.alfacapital.alphecca.services.legacy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;
import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class DefaultCurrencyRater implements CurrencyRater {

    Map<Date, Map<String,BigDecimal>> datesMap = new HashMap<>();

    @Autowired
    private SSDaoImpl currencyRateDao;

    public Map<String,BigDecimal> getRatesOnDate(Date date) {
        return datesMap.get(date);
    }

    @Override
    public BigDecimal rate(BigDecimal value, String currencyCodeToConvert, Date date) {
        if (currencyCodeToConvert.equals("RUB")) {
            return value;
        } else {
            Map<String,BigDecimal> currenciesMap =  datesMap.get(date);
            if (currenciesMap == null) {
                currenciesMap = new HashMap<>();
                datesMap.put(date, currenciesMap);
            }
            BigDecimal rate = currenciesMap.get(currencyCodeToConvert);
            if (rate == null) {
                rate = currencyRateDao.getCalcRate(currencyCodeToConvert, SSConstants.toDQ(date));
                currenciesMap.put(currencyCodeToConvert, rate);
            }
            if (rate != null && rate.compareTo(BigDecimal.ZERO) != 0) {
                return value.divide(rate, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
            } else {
                throw new NoRateException();
            }
        }
    }

    @Override
    public BigDecimal rate(BigDecimal value, String sourceCurrency, String targetCurrency, Date date) {
        if (sourceCurrency.equals(targetCurrency)) {
            return value;
        } else {
            Map<String,BigDecimal> currenciesMap =  datesMap.get(date);
            if (currenciesMap == null) {
                currenciesMap = new HashMap<>();
                datesMap.put(date, currenciesMap);
            }
            BigDecimal sourceToRub = currenciesMap.get(sourceCurrency);
            if (sourceToRub == null) {
                sourceToRub = currencyRateDao.getCalcRate(sourceCurrency, SSConstants.toDQ(date));
                currenciesMap.put(sourceCurrency, sourceToRub);
            }
            BigDecimal targetToRub = currenciesMap.get(targetCurrency);
            if (targetToRub == null) {
                targetToRub = currencyRateDao.getCalcRate(targetCurrency, SSConstants.toDQ(date));
                currenciesMap.put(targetCurrency, targetToRub);
            }
            if (targetToRub != null && targetToRub.compareTo(BigDecimal.ZERO) != 0 && sourceToRub != null && sourceToRub.compareTo(BigDecimal.ZERO) != 0) {
                return value.multiply(sourceToRub).divide(targetToRub, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
            } else {
                throw new NoRateException();
            }
        }
    }

    public SSDaoImpl getCurrencyRateDao() {
        return currencyRateDao;
    }

    public void setCurrencyRateDao(SSDaoImpl currencyRateDao) {
        this.currencyRateDao = currencyRateDao;
    }
}
