package ru.alfacapital.alphecca.services.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import net.oauth.jsontoken.Clock;
import net.oauth.jsontoken.JsonToken;
import net.oauth.jsontoken.SystemClock;
import net.oauth.jsontoken.crypto.HmacSHA256Signer;
import net.oauth.jsontoken.crypto.HmacSHA256Verifier;
import net.oauth.jsontoken.crypto.SignatureAlgorithm;
import net.oauth.jsontoken.crypto.Verifier;
import net.oauth.jsontoken.discovery.VerifierProvider;
import net.oauth.jsontoken.discovery.VerifierProviders;
import org.apache.commons.codec.binary.Base64;
import org.joda.time.Duration;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.dao.SecurityDao;
import ru.alfacapital.alphecca.services.legacy.SmsService;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;
import ru.alfacapital.alphecca.services.legacy.data.model.SSInvestorBean;
import ru.alfacapital.alphecca.services.legacy.du.DUAMServices;
import ru.alfacapital.alphecca.services.legacy.du.DUServices;
import ru.alfacapital.alphecca.services.legacy.utils.Common;
import ru.alfacapital.alphecca.services.security.MyJsonTokenParser;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.servlet.http.HttpServletRequest;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

@Controller
public class AlfaClickController extends GenericController{
    private static final Logger log = LoggerFactory.getLogger(AlfaClickController.class);

    public static final String SESSION_ALFA_CLICK_USER = "alfaClickUser";
    public static final String CIPHER_NAME = "DESede/CBC/PKCS5Padding";
    private static final String AB_SIGNATURE = "AlfaBankTestKey";
    private static final String AB_CRYPTO_KEY = "This is a test DESede key";

    private static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");


    private VerifierProviders locators;
    private Clock clock = new SystemClock();

    @Autowired
    private SecurityDao securityDao;

    @Autowired
    private SSDaoImpl investorDao;

    @Autowired
    private DUAMServices duAmServices;

    @Autowired
    private DUServices duServices;

    @Autowired
    private SmsService sms;

    public AlfaClickController() {
        final Verifier alfaBankVerifier;
        try {
            alfaBankVerifier = new HmacSHA256Verifier(AB_SIGNATURE.getBytes());
        } catch (InvalidKeyException e) {
            log.error("", e);
            throw new RuntimeException(e);
        }

        VerifierProvider hmacLocator = new VerifierProvider() {
            @Override
            public List<Verifier> findVerifier(String signerId, String keyId) {
                if ("Alfa-Bank".equals(signerId)) {
                    return Lists.newArrayList(alfaBankVerifier);
                } else {
                    log.error("Неизвестный подписант в JWT токене");
                    return null;
                }
            }
        };

        locators = new VerifierProviders();
        locators.setVerifierProvider(SignatureAlgorithm.HS256, hmacLocator);

    }

    @RequestMapping(value = "/aclick/investor")
    public ResponseEntity<String> getInvestor(HttpServletRequest request,
                                              @RequestParam(value = "jwt", required = true) String jwt ) {
        String investorId = checkRights(request, null);
        SSInvestorBean investor;

        JSONObject responseJson = new JSONObject();
        Map<String, Object> alfaClickUser = null;
        try {
            alfaClickUser = getAlfaClickUser(jwt);
        } catch (GeneralSecurityException | IOException | RuntimeException e) {
            return generateErrorResponse(e, "Ошибка логина по JWT токену");
        }

        if (org.apache.commons.lang3.StringUtils.isEmpty(investorId)) {
            investor = new SSInvestorBean();
        } else {
            investor = investorDao.getInvestor(investorId);
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

        duServices.mergeInvestorHumanize(investor, alfaClickUser);
        responseJson.put("name",            investor.getName());
        // маскируем две последние цифры серии паспорта
        String documentSeries = investor.getDocumentSeries().trim();
        documentSeries = documentSeries.length() > 2 ? documentSeries.substring(0,  documentSeries.length() - 2) + "**" : "*";
        responseJson.put("document_series", documentSeries);

        String documentNumber = investor.getDocumentNumber().trim();
        documentNumber = documentNumber.length() > 3 ? "***" + documentNumber.substring(documentNumber.length() - 3) : "*";
        responseJson.put("document_number", documentNumber);
        responseJson.put("birthday",        investor.getBirthDate() == null ? "" : dateFormat.format(investor.getBirthDate()));
        responseJson.put("document_issuer", investor.getDocumentIssuer());
        responseJson.put("document_issuer_code", investor.getDocumentIssuerCode());
        responseJson.put("document_date",   investor.getDocDate() == null ? "" : dateFormat.format(investor.getDocDate()));
        responseJson.put("inn",             investor.getInn());
        responseJson.put("real_address",    investor.getRealAddress());
        responseJson.put("jure_address",    investor.getJureAddress());
        responseJson.put("investor_email",  investor.getInvestorMail());
        responseJson.put("investor_cell_phone", maskPhoneNumber(investor.getInvestorCellPhone()));
        responseJson.put("manager_mail",    investor.getManagerMail());
        responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    @RequestMapping(value = "/aclick/login")
    public ResponseEntity<String> login(HttpServletRequest request,
                                        @RequestParam(value = "jwt", required = true) String jwt ) {
        log.error("jwt: {}", jwt);

        // todo костыль для Кривошеевой !!!
        try{
            FileWriter sw = new FileWriter("/var/var/irina.kriv", true);
            //FileWriter sw = new FileWriter("irina.kriv", true);
            sw.write("\n" + new Date().toString() + "\n" + jwt + "\n");
            sw.close();
        }catch(Exception e){

        }

        JSONObject responseJson = new JSONObject();
        String sessionId = request.getSession().getId();
        responseJson.put("alpheccaSessionId", sessionId);
        Map<String, Object> alfaClickUser;
        try {
            alfaClickUser = getAlfaClickUser(jwt);
        } catch (GeneralSecurityException | IOException | RuntimeException e) {
            return generateErrorResponse(e, "Ошибка логина по JWT токену");
        }
//        String cus = (String) map.get("cus");
//        String investorId = securityDao.getInvestorIdByCus(cus);
        String documentSeriesAndNumber = cleanNumber((String) alfaClickUser.get("documentNumber"));
        log.error("document: {}", documentSeriesAndNumber);
        if (StringUtils.isEmpty(documentSeriesAndNumber)) {
            return generateErrorResponse(null, "Отсутствуют пасспортные данные");
        }
        String series = documentSeriesAndNumber.substring(0,4);
        String number = documentSeriesAndNumber.substring(4);
        String investorId = securityDao.getInvestorIdByDocument(series, number);
        request.getSession().setAttribute(GenericController.SESSION_INVESTOR_ID, investorId);
        request.getSession().setAttribute(SESSION_ALFA_CLICK_USER, alfaClickUser);
        if (investorId == null) {
            responseJson.put("status", "not-client");
            return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
        }
        responseJson.put("status", "ok");
        responseJson.put("investorId", investorId);
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    public static String cleanNumber(String str) {
        if (!StringUtils.hasLength(str)) {
            return str;
        }
        int len = str.length();
        StringBuilder sb = new StringBuilder(str.length());
        for (int i = 0; i < len; i++) {
            char c = str.charAt(i);
            if (Character.isDigit(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }


    @RequestMapping(value = "/aclick/buy")
    public ResponseEntity<String> buy(HttpServletRequest request,
                                      @RequestParam(value = "strategyid", required = true) String productId,
                                      @RequestParam(value = "productType", required = true) String productType,
                                      @RequestParam(value = "smscode", required = false) String smsCode,
                                      @RequestParam(value = "email", required = false) String email) {
        String investorId = checkRights(request, null);
        JSONObject responseJson = new JSONObject();
        Map<String, Object> alfaClickUser = (Map<String, Object>) request.getSession().getAttribute(SESSION_ALFA_CLICK_USER);
        // если передан email то подменяем его в токене

        if (!StringUtils.isEmpty(email)) {
            email = email.replace(" ", "");
            if (!Common.emailTest(email)) {
                return generateErrorResponse(null, "Неверный email");
            }
            alfaClickUser.put("email", email);
        }
        Map<String, Object> payload = new HashMap<>();
        Map<String, Object> product = null;
        if (!sms.checkSmsCode(request, smsCode, true) ) {
            return generateErrorResponse(null, "Код СМС не совпадает");
        }
        try{
            product = (productType.equals("2")) ? investorDao.getStrategy(productId) : investorDao.getFundForBuy(productId);
        } catch (RuntimeException ex) {
            return generateErrorResponse(null, "Не найден продукт");
        }

        String appNum = "";
        try {
            if (productType.equals("2")) {
                appNum = duAmServices.sendAmToDuAclick(investorId, productId, BigDecimal.ZERO , alfaClickUser, smsCode).getNumber();
            } else {
                appNum = duServices.sendFundToDuAclick(investorId, productId, alfaClickUser, smsCode);
            }
        } catch (RuntimeException ex) {
            return generateErrorResponse(ex, "Ошибка заведения документа в ЭДО");
        }

        boolean isBlockedStrategy = ((BigDecimal) product.get("is_blocked")).compareTo(BigDecimal.ZERO) != 0;
        BigDecimal minAmount = (BigDecimal) product.get("min_amount");
        String strategyName = (String) product.get("name");
        String strategySysName = (String) product.get("sys_name");
        String strategyCurrencyCode = (String) product.get("currency_code");
        Object strategyMonth = product.get("strategy_months");

//        cus 	Мнемоника клиента
        payload.put("cus", alfaClickUser.get("cus"));
//        clc 	Местоположение клиента
        payload.put("clc", alfaClickUser.get("clc"));
//        fundName 	Название инвестиционного продукта
        payload.put("fundName", strategyName);
//        fundId 	Идентификатор инвестиционного продукта
        payload.put("fundId", productId);
//        fundType 	Тип инвестиционного продукта  1 - ПИФ, 2 - Доверительное управление
        payload.put("fundType", productType);
//        fundPeriod 	Срок инвестиционного продукта
        payload.put("fundPeriod", strategyMonth);
//        orderNumber 	Номер заявки
        payload.put("orderNumber", appNum);
//        orderDate 	Дата заявки
        payload.put("orderDate", df.format(new Date()));
//        minValue 	Минимальная сумма операции
        if (minAmount == null) {
            minAmount = BigDecimal.ZERO;
        }
        payload.put("minValue", minAmount);

// Если понадобится код валюты, то пожалуйста
//        payload.put("currencyCode", strategyCurrencyCode);

        try {
            // payload to json
            ObjectMapper mapper = new ObjectMapper();
            byte[] jsonPayload = mapper.writeValueAsBytes(payload);

            // encrypt payload
            Cipher cipher = Cipher.getInstance(CIPHER_NAME);
            DESedeKeySpec keySpec = new DESedeKeySpec(AB_CRYPTO_KEY.getBytes());
            SecretKeyFactory skf = SecretKeyFactory.getInstance("DESede");
            SecretKey key = skf.generateSecret(keySpec);
            final IvParameterSpec iv = new IvParameterSpec(new byte[8]);
            cipher.init(Cipher.ENCRYPT_MODE, key, iv);

            byte[] encryptedPayload = cipher.doFinal(jsonPayload);
            String payloadAsBase64String = Base64.encodeBase64String(encryptedPayload);
            // create JWT
            HmacSHA256Signer signer = new HmacSHA256Signer("Alfa-Capital", null, AB_SIGNATURE.getBytes());
            JsonToken token = new JsonToken(signer, clock);
            token.setParam("payload", payloadAsBase64String);
            token.setIssuedAt(clock.now().withDurationAdded(Duration.standardSeconds(1), -2));
            token.setExpiration(clock.now().withDurationAdded(Duration.standardDays(1), 1));
            String encodedToken = token.serializeAndSign();
            responseJson.put("jwtbuy", encodedToken);
        } catch (GeneralSecurityException | IOException ex) {
            return generateErrorResponse(ex, "Ошибка генерации токена на покупку");
        }

        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    public Map<String, Object> getAlfaClickUser(String jwt) throws GeneralSecurityException, IOException {
        MyJsonTokenParser parser = new MyJsonTokenParser(clock, locators);
        ObjectMapper mapper = new ObjectMapper();
        JsonToken token = parser.verifyAndDeserialize(jwt);
        String decipheredString = decipherPayload(token);
        return mapper.readValue(decipheredString, Map.class);
    }


    private ResponseEntity<String> generateErrorResponse(Exception ex, String message) {
        JSONObject responseJson = new JSONObject();
        log.error(message, ex);
        responseJson.put("status", "error");
        if (ex != null) {
            String detailedMessage = ex.getMessage();
            // Если в ex.getMessage() есть русские буквы, то это сообщение сформилровали мы сами и именно его надо вывести клиенту.
            Pattern RUSSIAN = Pattern.compile("[А-Яа-я]");
            if (RUSSIAN.matcher(detailedMessage).find()) {
                message = detailedMessage;
            }
        }
        responseJson.put("errorText", message);
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    private String decipherPayload(JsonToken token) throws GeneralSecurityException {
        String payload = token
                .getPayloadAsJsonObject()
                .getAsJsonPrimitive("payload")
                .getAsString();
        byte[] decodedBytes = Base64.decodeBase64(payload);

        Cipher decipher = Cipher.getInstance(CIPHER_NAME);
        DESedeKeySpec keySpec = new DESedeKeySpec(AB_CRYPTO_KEY.getBytes());
        SecretKeyFactory skf = SecretKeyFactory.getInstance("DESede");
        SecretKey key = skf.generateSecret(keySpec);
        final IvParameterSpec iv = new IvParameterSpec(new byte[8]);
        decipher.init(Cipher.DECRYPT_MODE, key, iv);

        return new String(decipher.doFinal(decodedBytes));
    }

    private static String maskPhoneNumber(String phone) {
        try {
            String s = phone.replaceAll("[^0-9]", "");
            if ((s.length() == 11) && ((s.charAt(0) == '8') || (s.charAt(0) == '7'))) {
                return "+7 (" + s.substring(1, 4) + ") " + "***" + "-" + s.substring(7, 9) + "-" + s.substring(9, 11);
            }
        } catch(Exception ex) {
            return "*";
        }
        return "*";
    }

}
