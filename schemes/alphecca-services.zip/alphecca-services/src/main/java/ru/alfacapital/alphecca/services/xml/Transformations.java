package ru.alfacapital.alphecca.services.xml;

import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.fop.apps.FopFactory;
import org.springframework.core.io.Resource;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class Transformations {

    private Resource fopConfig;

    public void setFopConfig(Resource fopConfig) {
        this.fopConfig = fopConfig;
    }

    public File getFopConfigAsFile() throws URISyntaxException, IOException {
        return new File(fopConfig.getURI());
    }

    public FopFactory createFopFactory() throws URISyntaxException, IOException, SAXException, ConfigurationException {
        FopFactory factory = FopFactory.newInstance();
        factory.setUserConfig(fopConfig.getFile());
        factory.getFOURIResolver().setCustomURIResolver(new ClasspathURIResolver());
        return factory;
    }

}
