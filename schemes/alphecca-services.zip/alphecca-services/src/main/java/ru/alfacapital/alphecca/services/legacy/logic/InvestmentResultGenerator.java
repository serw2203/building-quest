package ru.alfacapital.alphecca.services.legacy.logic;

import java.util.Date;

/**
 * Любой объект способный генерировать инвестиционный результат за период инвестирования
 */
public interface InvestmentResultGenerator {

    /**
     * Возвращает инвестиционный результат за период инвестирования.
     *
     * @param start начало инвестирования
     * @param stop конец инвестирования
     * @return инвестиционный результат
     */
    InvestmentResult getInvestmentResultForPeriod(Date start, Date stop);

}
