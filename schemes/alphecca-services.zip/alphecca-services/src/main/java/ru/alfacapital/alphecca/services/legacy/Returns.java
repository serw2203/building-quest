package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;
import java.util.*;

public class Returns {

    /**
     * Money-Weighted Rate of Return.
     *
     * Если считается доходность портфеля за период:
     * В качестве первого элемента итератор должен возвращать оценку на начало периода.
     * В качестве последнего элемента итератор должен возвращать минус оценку на конец периода.
     * (Если ввод в портфель - плюс, а вывод - минус)
     *
     * Получившаяся доходность выражена в единицах, для привидения к процентам необходимо умножить на 100.
     * Если доходность не может быть определена однозначно возвпащается null.
     *
     * @see #mwrr(Iterable, int, int)
     *
     * @param cashflowIterator финансовые потоки
     * @return доходность методом MWRR
     */
    public static BigDecimal mwrr(Iterable<BigDecimal> cashflowIterator) {
        return irr(cashflowIterator);
    }

    /**
     * @see #mwrr(Iterable)
     *
     * @param cashflowIterator финансовые потоки
     * @param precission точность
     * @param maxIterations максимальное число итераций при вычислении приближения
     * @return доходность методом MWRR
     */
    public static BigDecimal mwrr(Iterable<BigDecimal> cashflowIterator, int precission, int maxIterations) {
        return irr(cashflowIterator, precission, maxIterations);
    }

    /**
     * Internal Rate of Return.
     *
     * То же самое, что MWRR.
     *
     * По умолчанию используется точность 4 знака и 10000 итераций максимум.
     *
     * @see #mwrr(Iterable)
     *
     * @param cashflowIterator финансовые потоки
     * @return доходность методом IRR
     */
    public static BigDecimal irr(Iterable<BigDecimal> cashflowIterator) {
        return irr(cashflowIterator, 4, 10000);
    }

    /**
     * Internal Rate of Return.
     *
     * То же самое, что MWRR.
     *
     * @see #mwrr(Iterable)
     *
     * @param cashflowIterator финансовые потоки
     * @param precission точность
     * @param maxIterations максимальное число итераций при вычислении приближения
     * @return доходность методом IRR
     */
    public static BigDecimal irr(Iterable<BigDecimal> cashflowIterator, int precission, int maxIterations) {
        if (precission < 0) throw new IllegalArgumentException();
        if (maxIterations < 1) throw new IllegalArgumentException();

        Iterator<BigDecimal> i = cashflowIterator.iterator();
        int count = 0;
        while (i.hasNext()) {
            i.next();
            count++;
        }

        if (count == 0) {
            // ничего не вложили, ничего не получили - доходность 0.
            return BigDecimal.ZERO;
        }
        else if (count == 1) {
            // что-то безвозмездное
            return null;
        }

        // данная реализация использует метод секущих (secant)
        // x := 1 / (1 + r)
        // первое приближение = 1, это в принципе мат. ожидание любой инвестиции в условиях неопределенности
        BigDecimal x0 = BigDecimal.ONE;
        // второе приближение определяется методом Ньютона
        i = cashflowIterator.iterator();
        BigDecimal cashflows = BigDecimal.ZERO;
        BigDecimal weightedCashflows = BigDecimal.ZERO;
        int ii = 0;
        while (i.hasNext()) {
            BigDecimal a = i.next();
            cashflows = cashflows.add(a);
            weightedCashflows = weightedCashflows.add(a.multiply(new BigDecimal(ii)));
            ii++;
        }

        BigDecimal x1;
        if (weightedCashflows.setScale(precission, BigDecimal.ROUND_HALF_UP).compareTo(BigDecimal.ZERO) == 0) {
            // производная в x0 = 0, придется взять что-то произвольное рядом
            x1 = new BigDecimal("0.0");
        }
        else {
            x1 = BigDecimal.ONE.subtract(cashflows.divide(weightedCashflows, precission, BigDecimal.ROUND_HALF_UP));
        }

        // Дальше метод секущих в чистом виде, пока итераций не станет слишком много или мы не выйдем на нужную точность.
        BigDecimal xNm1 = x0;
        BigDecimal xN = x1;
        int iterations;
        for (iterations = 0; iterations < maxIterations; iterations++) {
            // итерация
            BigDecimal FxN = BigDecimal.ZERO;
            BigDecimal FxNm1 = BigDecimal.ZERO;
            i = cashflowIterator.iterator();
            ii = 0;
            while (i.hasNext()) {
                BigDecimal a = i.next();
                FxN = FxN.add(a.multiply(xN.pow(ii)));
                FxNm1 = FxNm1.add(a.multiply(xNm1.pow(ii)));
                ii++;
            }

            BigDecimal deltaF = FxN.subtract(FxNm1);
            if (deltaF.setScale(precission, BigDecimal.ROUND_HALF_UP).compareTo(BigDecimal.ZERO) == 0) {
                break;
            }
            BigDecimal xNp1 = xN.subtract(FxN.multiply(xN.subtract(xNm1)).divide(deltaF, 2 * precission, BigDecimal.ROUND_HALF_UP));

            // подготовка к седующей итерации
            xNm1 = xN;
            xN = xNp1;
        }

        // xN = 1 / (1 + r)
        // r = 1 / xN - 1

        if (xN.compareTo(BigDecimal.ZERO) == 0) {
            // предельные потери
            return null;
        }
        if (maxIterations == iterations) {
            // корни не найдены
            return null;
        }
        return BigDecimal.ONE.divide(xN, precission, BigDecimal.ROUND_HALF_UP).subtract(BigDecimal.ONE).setScale(precission, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * Расчёт доходности методом Modified Dietz.
     * Оценки портфеля должны быть известны на любую дату внутри периода, если одна из них неизвестна, считаем, что она равна 0.
     *
     * Данный метод игнорирует периоды в течении которых сумма инвестиций равнялась 0.
     *
     * @param start начало периода (т.е. с оценки на начало этого дня, т.е. с оценки на конец предыдущего дня)
     * @param stop конец периода
     * @param cashflow внешние финансовые потоки
     * @param aums оценки портфеля
     * @param precission точность, знаков после запятой
     * @return доходность или null, если доходность не может быть рассчитана
     */
    public static BigDecimal modifiedDietz(Long start, Long stop, Map<Long, BigDecimal> cashflow, Map<Long, BigDecimal> aums, int precission) {
        int periodDays = (int) (stop - start + 1);
        if (periodDays <= 0) {
            return null;
        }
        BigDecimal a0 = aums.get(start - 1);
        BigDecimal a1 = aums.get(stop);
        if (a0 == null || a1 == null) {
            return null;
        }
        List<Integer> di = new ArrayList<Integer>(); // дней с начала периода
        List<BigDecimal> ci = new ArrayList<BigDecimal>(); // внешний финансовый поток
        Long day = start;
        int skeptDays = 0;
        for (int i = 0; i < periodDays; i++, day++) {
            BigDecimal aum = aums.get(day);
            if (aum == null) {
                return null;
            }
            BigDecimal f = cashflow.get(day);
            if (f != null) {
                // т.е. если после вывода оценка на конец дня 0, этот день считается в весовом коэффициенте и длине периода
                di.add(i - skeptDays);
                ci.add(f);
            }
            else if (aum.compareTo(BigDecimal.ZERO) <= 0) {
                // этот день не в счёт
                skeptDays++;
            }
        }
        periodDays -= skeptDays;
        if (periodDays <= 0) {
            return null;
        }
        BigDecimal flow = BigDecimal.ZERO;
        BigDecimal cwi = BigDecimal.ZERO;
        for (int i = 0; i < di.size(); i++) {
            int d = di.get(i);
            BigDecimal c = ci.get(i);
            flow = flow.add(c);
            double w = ((double) (periodDays - d)) / ((double) periodDays);
            cwi = cwi.add(c.multiply(new BigDecimal(w)));
        }
        BigDecimal b = a0.add(cwi);
        if (b.setScale(precission, BigDecimal.ROUND_HALF_UP).compareTo(BigDecimal.ZERO) == 0) {
            return null;
        }
        return a1.subtract(a0).subtract(flow).divide(b, precission, BigDecimal.ROUND_HALF_UP).setScale(precission, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * Заполнить пропуски значениями с прошлых дат.
     * Метод с побочным эффектом
     *
     * @param aums соответствие
     */
    public static void fillGaps(Map<Long, BigDecimal> aums) {
        List<Map.Entry<Long, BigDecimal>> list = new ArrayList<Map.Entry<Long, BigDecimal>>(aums.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<Long, BigDecimal>>() {
            @Override
            public int compare(Map.Entry<Long, BigDecimal> o1, Map.Entry<Long, BigDecimal> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });
        Long lastDate = null;
        BigDecimal lastValue = null;
        for (Map.Entry<Long, BigDecimal> e : list) {
            if (lastDate != null) {
                Long curDate = e.getKey();
                if (lastDate + 1 < curDate) {
                    for (Long d = lastDate; d < curDate; d++) {
                        aums.put(d, lastValue);
                    }
                }
            }
            lastDate = e.getKey();
            lastValue = e.getValue();
        }
    }

}
