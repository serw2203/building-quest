package ru.alfacapital.alphecca.services.legacy.du;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.alfacapital.alphecca.services.legacy.KladrAddress;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;
import ru.alfacapital.alphecca.services.legacy.data.model.SSInvestorBean;
import ru.alfacapital.alphecca.services.rest.RuleController;
import ru.alfacapital.schemas.common.PaymentInfoType;
import ru.alfacapital.schemas.survey.SurveyRequest;
import ru.alfacapital.schemas.survey.SurveyResponse;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;


@Service
public class DUAMServices {


    @Autowired
    private DUServices duServices;

    @Autowired
    private SSDaoImpl ssDao;

    @Autowired
    private SSDaoImpl investorDao;

    @Autowired
    private RuleController rule;

    public DUServices.DUResponse sendAmToDuAclick(String investorId, String strategyId, BigDecimal amount, Map<String, Object> alfaClickUser, String smsCode) {
        SSInvestorBean investor;
        if (StringUtils.isEmpty(investorId)) {
            investor = new SSInvestorBean();
        } else {
            investor = investorDao.getInvestor(investorId);
        }
        duServices.mergeInvestor(investor, alfaClickUser);
        return sendContractToDU(investor,
                strategyId,
                amount,
                smsCode,
                (String) alfaClickUser.get("BIC"),
                (String) alfaClickUser.get("bankName"),
                (String) alfaClickUser.get("ksn"),
                (String) alfaClickUser.get("account"),
                duServices.LOGIN_LK);
    }

    public DUServices.DUResponse sendAmToDuLK(String investorId, String strategyId, BigDecimal amount, String bic, String bankName, String cr, String pr) {
        SSInvestorBean investor;
        if (StringUtils.isEmpty(investorId)) {
            investor = new SSInvestorBean();
        } else {
            investor = investorDao.getInvestor(investorId);
        }
        return sendContractToDU(investor,
                strategyId,
                amount,
                "",
                bic,
                bankName,
                cr,
                pr,
                duServices.LOGIN_LK);
    }

    private DUServices.DUResponse sendContractToDU(SSInvestorBean investor,
                                       String strategyId,
                                       BigDecimal amount,
                                       String sign,
                                       String bic,
                                       String bankName,
                                       String cr,
                                       String pr,
                                       String loginEmp) {

        Map<String, Object> strategy = investorDao.getStrategy(strategyId);
        if ((strategy == null) || (investor == null)) {
            throw new RuntimeException("Некорректно определены : " + (strategy == null ? "cтратегия, " : "") +
                    (investor == null ? "инвестор, " : "")
            );
        }

        boolean isBlockedStrategy = ((BigDecimal) strategy.get("is_blocked")).compareTo(BigDecimal.ZERO) != 0;


        String strategySysName = (String) strategy.get("sys_name");
        String currencyCode = (String) strategy.get("currency_code");
        String actionCode = duServices.CODE_BUY;

        if (isBlockedStrategy) {
            throw new RuntimeException("Указанная Вами стратегия заблокирована");
        }
        if ((investor.getName() == null) || (investor.getName().length() == 0)) {
            throw new RuntimeException("Неверное имя");
        }
//        if ((investor.getInvestorMail() == null) || (investor.getInvestorMail().length() == 0)) {
//            throw new RuntimeException("Неверный email");
//        }
        if ((investor.getInvestorCellPhone() == null) || (investor.getInvestorCellPhone().length() < 5)) {
            throw new RuntimeException("Неверный телефон");
        }
        if ((investor.getDocDate() == null) ||
                (investor.getDocumentSeries() == null) || (investor.getDocumentSeries().length() == 0) ||
                (investor.getDocumentNumber() == null) || (investor.getDocumentNumber().length() == 0) ||
                (investor.getDocumentIssuer() == null) || (investor.getDocumentIssuer().length() == 0) ||
                (investor.getDocumentIssuerCode() == null) || (investor.getDocumentIssuerCode().length() == 0)) {
            throw new RuntimeException("Неверные паспортные данные");
        }
        // минимальная сумма
        BigDecimal minAmount = (BigDecimal) strategy.get("min_amount");
/*        if (minAmount.compareTo(amount) == 1) {
            throw new RuntimeException("Для стратегии " + strategyName + " сумма должна быть больше " + minAmount);
        }*/

        SurveyRequest surveyRequest = new SurveyRequest();
        duServices.setInvestorData(surveyRequest, investor);
        // адрес по кладру
        surveyRequest.setPostAddress        (duServices.kladrToAddressType(new KladrAddress(investor.getRealAddress())));
        surveyRequest.setRegistrationAddress(duServices.kladrToAddressType(new KladrAddress(investor.getJureAddress())));

        surveyRequest.setLogin(loginEmp);
        surveyRequest.setProduct(duServices.AM_PRODUCT);
        surveyRequest.setQuery(actionCode);

        surveyRequest.setCurrencyCode(currencyCode);
        surveyRequest.setAmount(amount.setScale(4, RoundingMode.CEILING));
        // переделать сервис чтобы он работал с BigDecimal
        surveyRequest.setSign(sign);
        surveyRequest.setProductId(strategySysName);

        PaymentInfoType p = new PaymentInfoType();
        p.setBankBik(bic);
        p.setBankName(bankName);
        p.setCorrespondentAccount(cr);
        p.setPersonalAccount(pr);
        surveyRequest.setPaymentInfo(p);

        SurveyResponse surveyResponse = duServices.sendProductToDU(surveyRequest);

        if (StringUtils.isNotEmpty(investor.getInvestorId())) {
            investorDao.addPendingContract(investor.getInvestorId(), surveyResponse.getAppNum(), strategyId, amount.toString(), actionCode, surveyResponse.getDate().toGregorianCalendar().getTime());
        }

        return new DUServices.DUResponse(surveyResponse.getAppNum(), surveyResponse.getDate().toGregorianCalendar().getTime());
    }


}
