package ru.alfacapital.alphecca.services.rest

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import ru.alfacapital.alphecca.services.dao.SecurityDao
import ru.alfacapital.alphecca.services.legacy.ProjectProperty

import javax.servlet.http.HttpServletRequest
import java.security.Principal

public abstract class GenericController {

    public static final String SESSION_INVESTOR_ID = "investorId"
    public static final String SESSION_HAS_WELCOME_SMS_CODE = "sessionHasWelcomeSmsCode";

    @Autowired
    private SecurityDao securityDao;

    protected static HttpHeaders defaultHeaders() {
        def headers = new HttpHeaders()
        headers.add("Content-Type", "application/json; charset=utf-8")
        headers.add("Cache-Control", "no-cache")
        headers
    }

    protected String checkRights(HttpServletRequest request, String investorId) {
        // пытаемся получить идентификатор инвестора
        String resultId = getInvestorId(request, investorId);
        // если не требуется аутентификация по смс
        if (!ProjectProperty.checkWelcomeSms()) {
            return resultId
        }
        // проверяем была ли подтверждена смс
        if (Boolean.TRUE.equals(request.getSession().getAttribute(SESSION_HAS_WELCOME_SMS_CODE))) {
            return resultId
        }
        return null;
    }

    protected String getInvestorId(HttpServletRequest request, String investorId) {
        // Вначале смотрим нет ли в сессии investorId. Туда он может попасть авторизовав клиента Альфа-Клик по JWT токену.
        String sessionInvestorId = request.getSession().getAttribute(SESSION_INVESTOR_ID);
        if (sessionInvestorId != null) {
            return sessionInvestorId;
        }

        Principal principal = request.getUserPrincipal()
        if (principal == null) {
            // до аутентификации возможно выполнение только запросов без investorId
            // т.е. любой запрос не содержащий investorId в параметрах вернёт результат, а остальные - нет
            return null
        }
        String login = principal.getName()
        if (login == null) {
            // невозможный случай, аутентифицирован пользователь с неизвестным именем
            return null
        }
        if (investorId == null) {
            String iid = securityDao.getInvestorIdByLogin(login)
            if (iid == null) {
                // Обращения сотрудника без определённого идентификатора клиента
                return null
            }
            else {
                // Типичный случай приложения запущенного клиентом
                return iid
            }
        }
        else {
            // Типичный случай приложения запущенного сотрудником
            boolean haveRights = request.isUserInRole("ROLE_SS-NOFILTERS") || securityDao.haveRights(login, investorId)
            if (haveRights) {
                return investorId;
            }
            else {
                throw new SecurityException("No rights")
            }
        } /* */
    }

}
