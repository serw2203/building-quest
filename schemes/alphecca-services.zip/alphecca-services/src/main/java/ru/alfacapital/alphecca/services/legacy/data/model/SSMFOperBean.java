package ru.alfacapital.alphecca.services.legacy.data.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class SSMFOperBean implements Serializable {

    private String operNumber;
    private SSFundBean fund;
    private String investorId;
    private Date date;
    private Date realDate;
    private Long dateDQ;
    private BigDecimal qty;
    private BigDecimal amount;
    private BigDecimal amountVal;
    private BigDecimal totalQty;

    public String getOperNumber() {
        return operNumber;
    }

    public void setOperNumber(String operNumber) {
        this.operNumber = operNumber;
    }

    public SSFundBean getFund() {
        return fund;
    }

    public void setFund(SSFundBean fund) {
        this.fund = fund;
    }

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public Date getRealDate() {
        return realDate;
    }

    public void setRealDate(Date realDate) {
        this.realDate = realDate;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getDateDQ() {
        return dateDQ;
    }

    public void setDateDQ(Long dateDQ) {
        this.dateDQ = dateDQ;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getAmountVal() {
        return amountVal;
    }

    public void setAmountVal(BigDecimal amountVal) {
        this.amountVal = amountVal;
    }

    public BigDecimal getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(BigDecimal totalQty) {
        this.totalQty = totalQty;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSMFOperBean that = (SSMFOperBean) o;

        if (date != null ? !date.equals(that.date) : that.date != null) return false;
        if (fund != null ? !fund.equals(that.fund) : that.fund != null) return false;
        if (investorId != null ? !investorId.equals(that.investorId) : that.investorId != null) return false;
        if (operNumber != null ? !operNumber.equals(that.operNumber) : that.operNumber != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = operNumber != null ? operNumber.hashCode() : 0;
        result = 31 * result + (fund != null ? fund.hashCode() : 0);
        result = 31 * result + (investorId != null ? investorId.hashCode() : 0);
        result = 31 * result + (date != null ? date.hashCode() : 0);
        return result;
    }

}
