package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;
import java.util.TreeMap;


public class BenchmarkResponse {

    public String selectionType;
    public TreeMap<Long, BigDecimal> navs = new TreeMap<Long, BigDecimal>();
    public TreeMap<Long, BigDecimal> yields = new TreeMap<Long, BigDecimal>();

    public void clear() {
        navs.clear();
        yields.clear();
    }

}
