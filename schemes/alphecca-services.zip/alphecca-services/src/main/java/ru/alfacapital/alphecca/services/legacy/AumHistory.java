package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * История владения активами. Всех трех поддерживаемых типов.
 * Все даты определяются количеством дней прошедших с 01.01.2000.
 */
public class AumHistory {

    public Map<Long, BigDecimal> fundHistory = new HashMap<Long, BigDecimal>();
    public Map<Long, BigDecimal> fundCashflow = new HashMap<Long, BigDecimal>();

    public Map<Long, BigDecimal> amHistory = new HashMap<Long, BigDecimal>();
    public Map<Long, BigDecimal> amCashflow = new HashMap<Long, BigDecimal>();

    public void clear() {
        fundHistory.clear();
        fundCashflow.clear();
        amHistory.clear();
        amCashflow.clear();
    }

    public String toString() {
        return "{fundHistory:{" + fundHistory + "},fundCashflow:{" + fundCashflow + "}, amHistory:{" + amHistory + "},amCashflow:{" + amCashflow + "}}";
    }

}
