package ru.alfacapital.alphecca.services.legacy.logic;


import ru.alfacapital.alphecca.services.legacy.AMResponse;
import ru.alfacapital.alphecca.services.legacy.CurrencyRater;
import ru.alfacapital.alphecca.services.legacy.Returns;
import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;
import ru.alfacapital.alphecca.services.legacy.service.model.FundResponse;
import ru.ingie.commons.BigDecimals;
import ru.ingie.commons.DateUtils2;


import java.math.BigDecimal;
import java.util.*;

public class AggregatedInvestmentResultGenerator implements InvestmentResultGenerator {

    private final FundResponse fundResponse;
    private final AMResponse amResponse;
    private final String currencyCode;
    private final CurrencyRater currencyRater;

    public AggregatedInvestmentResultGenerator(FundResponse fr, AMResponse ar, String currencyCode, CurrencyRater currencyRater) {
        this.fundResponse = fr;
        this.amResponse = ar;
        this.currencyCode = currencyCode;
        this.currencyRater = currencyRater;
    }

    @Override
    public InvestmentResult getInvestmentResultForPeriod(Date start, Date stop) {
        Date yearStart = DateUtils2.truncateToYear(stop);
        Long yearStartDQ = SSConstants.toDQ(yearStart);
        Long startDQ = SSConstants.toDQ(start);
        Long stopDQ = SSConstants.toDQ(stop);
        Long minDate = null;

        List<InvestmentResult> results = new ArrayList<InvestmentResult>();
        InvestmentResult fundResult = fundResponse.asInvestmentResultGeneratorInCurrency(currencyCode, currencyRater).getInvestmentResultForPeriod(start, stop);
        if (fundResult != null) {
            results.add(fundResult);
            minDate = fundResult.getMinDate();
        }
        List<String> contractIds = new ArrayList<String>();
        for (Map.Entry<String, String> e : amResponse.names.entrySet()) {
            InvestmentResult ir =  amResponse.asInvestmentResultGenerator(e.getKey(), currencyCode, currencyRater).getInvestmentResultForPeriod(start, stop);
            if (ir != null) {
                results.add(ir);
                contractIds.add(e.getKey());
                Long d = ir.getMinDate();
                if (d != null && (minDate == null || minDate > d)) {
                    minDate = d;
                }
            }
        }

        if (minDate == null) {
            minDate = startDQ;
        }

        if (minDate >= yearStartDQ) {
            yearStartDQ = minDate;
        }

        Map<Long, BigDecimal> solidNavs = new HashMap<Long, BigDecimal>();
        solidNavs.put(minDate - 1, BigDecimal.ZERO);
        solidNavs.put(startDQ - 1, BigDecimal.ZERO);

        BigDecimal firstAum = BigDecimal.ZERO;
        BigDecimal yearFirstAum = BigDecimal.ZERO;
        BigDecimal lastAum = BigDecimal.ZERO;
        BigDecimal inflow = BigDecimal.ZERO;
        BigDecimal outflow = BigDecimal.ZERO;
        BigDecimal yearInflow = BigDecimal.ZERO;
        BigDecimal yearOutflow = BigDecimal.ZERO;
        BigDecimal totalInflow = BigDecimal.ZERO;
        BigDecimal totalOutflow = BigDecimal.ZERO;
        for (InvestmentResult ir : results) {
            firstAum = firstAum.add(ir.getFirstAum());
            yearFirstAum = yearFirstAum.add(ir.getYearFirstAum());
            lastAum = lastAum.add(ir.getLastAum());
            inflow = inflow.add(ir.getInflow());
            outflow = outflow.add(ir.getOutflow());
            yearInflow = yearInflow.add(ir.getYearInflow());
            yearOutflow = yearOutflow.add(ir.getYearOutflow());
            totalInflow = totalInflow.add(ir.getTotalInflow());
            totalOutflow = totalOutflow.add(ir.getTotalOutflow());
            Map<Long, BigDecimal> map = ir.getAllAums();
            if (map != null) {
                for (Map.Entry<Long, BigDecimal> e : map.entrySet()) {
                    Long d = e.getKey();
                    BigDecimal was = solidNavs.get(d);
                    if (was == null) {
                        was = BigDecimal.ZERO;
                    }
                    was = was.add(e.getValue());
                    solidNavs.put(d, was);
                }
            }
        }

        Map<Long, BigDecimal> mapOperations = new HashMap<Long, BigDecimal>();

        // Все операции по всем фондам
        {
            Map<Long, MFOperationValue> mfOpers = new HashMap<Long, MFOperationValue>();
            for (String fundId : fundResponse.names.keySet()) {
                MFOperationValue.populate(mfOpers, fundResponse.opers.get(fundId));
            }
            for (Map.Entry<Long, MFOperationValue> e : mfOpers.entrySet()) {
                mapOperations.put(e.getKey(), e.getValue().getCash());
            }
        }

        // Все операции по всему ДУ
        {
            for (String contractId : contractIds) {
                Map<Long, AMResponse.Oper> opers = amResponse.opers.get(contractId);
                if (opers != null) {
                    for (Map.Entry<Long, AMResponse.Oper> e2 : opers.entrySet()) {
                        BigDecimal was = mapOperations.get(e2.getKey());
                        if (was == null) {
                            was = BigDecimal.ZERO;
                        }
                        mapOperations.put(e2.getKey(), was.add(e2.getValue().amount));
                    }
                }
            }
        }

        // Упорядочивание и фильтрация операций
        Map<Long, BigDecimal> opersByDates = new HashMap<Long, BigDecimal>();
        {
            List<Long> operDatesDQ = new ArrayList<Long>(mapOperations.keySet());
            Collections.sort(operDatesDQ);
            for (Long dateDQ : operDatesDQ) {
                if (dateDQ <= stopDQ) {
                    BigDecimal operationAmount = SSConstants.rate(currencyRater, mapOperations.get(dateDQ), currencyCode, dateDQ);
                    opersByDates.put(dateDQ, operationAmount);
                }
                else {
                    break;
                }
            }
        }

        BigDecimal yield;
        {   // за период
            yield = Returns.modifiedDietz(startDQ, stopDQ, opersByDates, solidNavs, 4);
            if (yield != null) {
                yield = yield.multiply(BigDecimals.BD100);
                if (yield.abs().compareTo(BigDecimals.BD100) >= 0) {
                    yield = null;
                }
            }
        }

        BigDecimal yearYield;
        {   // с начала инвестирования
            yearYield = Returns.modifiedDietz(yearStartDQ, stopDQ, opersByDates, solidNavs, 4);
            if (yearYield != null) {
                yearYield = yearYield.multiply(BigDecimals.BD100);
                if (yearYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                    yearYield = null;
                }
            }
        }

        BigDecimal totalYield;
        {   // с начала инвестирования
            totalYield = Returns.modifiedDietz(minDate, stopDQ, opersByDates, solidNavs, 4);
            if (totalYield != null) {
                totalYield = totalYield.multiply(BigDecimals.BD100);
                if (totalYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                    totalYield = null;
                }
            }
        }
        return new InvestmentResult(currencyCode, firstAum, yearFirstAum, BigDecimal.ZERO, BigDecimal.ZERO, lastAum, inflow, outflow, yield, yearInflow, yearOutflow, yearYield, totalInflow, totalOutflow, totalYield, minDate, opersByDates, solidNavs);
    }

}
