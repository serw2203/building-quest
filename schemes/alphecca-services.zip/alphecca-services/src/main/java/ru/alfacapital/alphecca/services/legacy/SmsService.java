package ru.alfacapital.alphecca.services.legacy;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.alfacapital.alphecca.services.legacy.utils.HashUtils;
import ru.alfacapital.auxapi.mfms.MFMSFacade;
import ru.alfacapital.auxapi.mfms.MFMSFactory;
import ru.alfacapital.auxapi.mfms.MFMSFactoryImpl;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Сервис отправки SMS.
 */
@Service
public class SmsService {

    private static final String SESSION_SMS_CODE_HASH = "SMS_CODE_HASH";

    private static final String MAGIC_SMS = "invalid_sms_777";

    private static final Logger logger = LoggerFactory.getLogger(SmsService.class);

    //private SecureRandom random = new SecureRandom(("Fuck you all ребятки " + System.currentTimeMillis()).getBytes());

    private MFMSFactory mfmsFactory = new MFMSFactoryImpl();
    private MFMSFacade mfms;

    @Autowired
    private SmsDao smsDao;

    @PostConstruct
    public void afterPropertiesSet() {
        mfms = mfmsFactory.createFacade();
        if (mfms == null) {
            logger.error("MFMS have not been initialized");
        }
    }

    private static boolean checkMagicSms(String smsCode) {
        return ProjectProperty.allowMasterSms() && MAGIC_SMS.equals(smsCode);
    }

    // cleanIfInvalid - очистить СМС в сессии если смс не совпадают
    // должен быть true если метод не ведет подсчет введенных СМС
    public boolean checkSmsCode(HttpServletRequest request, String smsCode, boolean cleanIfInvalid) {
        if (SmsService.checkMagicSms(smsCode)) {
            return true;
        }
        String savedSmsCodeHash = (String) request.getSession().getAttribute(SESSION_SMS_CODE_HASH);
        boolean result = !(StringUtils.isEmpty(smsCode) || !HashUtils.hashPassword(smsCode.trim()).equals(savedSmsCodeHash));
        // если СМС ошибочное то чистим СМС
        if (!result && cleanIfInvalid) {
            saveSmsCode(request, "");
        }
        return result;
    }

    public void saveSmsCode(HttpServletRequest request, String smsCode) {
        String smsCodeHash = HashUtils.hashPassword(smsCode);
        request.getSession().setAttribute(SESSION_SMS_CODE_HASH, smsCodeHash);
    }

    /**
     * Отправить постоянный пароль по Sms.
     *
     * @param to получатель
     * @param login логин
     * @param password пароль
     */
    @Transactional ( readOnly = false )
    public void sendMainPassword(String loginId, String to, String login, String password) {
        send(loginId, to, "Добро пожаловать в Личный кабинет (my.alfacapital.ru). Ваш логин: " + login + " Пароль: " + password);
    }



    /**
     * Отправить SMS с номера по умолчанию.
     *
     * @param to получатель
     * @param text текст сообщения
     * @return результат отправки
     */
    @Transactional ( readOnly = false )
    public boolean send(String loginId, String to, String text) {

        if (ProjectProperty.sendSms()) {
            if (ProjectProperty.sendMagicSms()) {
                to = ProjectProperty.getMagicPhoneNumber();
            }
            return send(loginId, "Alfacapital", to, text);
            //return send("AlfaCapital", to, text);
        }
        return true;
    }



    private String formatNumber(String n) {
        if (n == null) return "";
        String num = n.replaceAll("[^\\d]", "");
        if (n.trim().startsWith("+8")) {
            // страна с кодом 8. ок.
        }
        else if (num.startsWith("810")) {
            num = num.substring(3);
        }
        else {
            if (num.length() == 11 && num.startsWith("8")) {
                num = "7" + num.substring(1);
            }
            if (num.length() == 10 && num.startsWith("9")) {
                num = "7" + num;
            }
        }
        return num;
    }


    /**
     * Отправить SMS.
     *
     * @param from отправитель (короткий номер отправителя)
     * @param to получатель
     * @param text текст сообщения
     * @return результат отправки
     */
    @Transactional( readOnly = true )
    private boolean send(String loginId, String from, String to, String text) {
        if (from == null) throw new NullPointerException();
        if (to == null) throw new NullPointerException();
        if (text == null) throw new NullPointerException();
        String formattedNumber = formatNumber(to);
        try {
            boolean sended = sendViaMFMS(loginId, formattedNumber, text);
            if (sended) return sended;
        }
        catch (Exception ex) {
            logger.error("Exception when sending sms: ", ex);
            smsDao.smsSended(loginId, "FAIL", "mfms.ru", to, text);
        }
        // Резервный вариант. Технологически более простой, но медленный и ненадежный.
        try {
            return sendViaSmsDirect(loginId, from, text, formattedNumber);
        }
        catch (Exception ex2) {
            logger.error("Exception when sending sms 2: ", ex2);
            smsDao.smsSended(loginId, "FAIL", "smsdirect.ru", to, text);
        }
        return false;
    }

    @Transactional ( readOnly = false )
    private boolean sendViaMFMS(String loginId, String to, String text) {
        Long nextId = smsDao.getNextSmsId();
        Long providerId = mfms.send(nextId, to, text);
        if (providerId != null) {
            smsDao.smsSended(loginId, "OK", "mfms.ru", to, text);
        }
        else {
            smsDao.smsSended(loginId, "FAIL", "mfms.ru", to, text);
        }
        return providerId != null;
    }

    private boolean sendViaSmsDirect(String loginId, String from, String text, String formattedNumber) {
        BufferedReader in = null;
        try {
            String uFrom = URLEncoder.encode(from, "UTF-8");
            String uTo = URLEncoder.encode(formattedNumber, "UTF-8");
            String uText = URLEncoder.encode(text, "UTF-8");
            String url = "https://www.smsdirect.ru/submit_message?login=Mperesypkin&pass=Op1NqQVsD&from=" + uFrom + "&to=" + uTo + "&text=" + uText;
            logger.trace("SMSDirect URL: " + url);
            URL oracle = new URL(url);
            in = new BufferedReader(new InputStreamReader(oracle.openStream()));
            in.readLine();
            smsDao.smsSended(loginId, "OK", "smsdirect.ru", formattedNumber, text);
            return true;
        }
        catch (Exception ex) {
            logger.error("Can't send SMS", ex);
            smsDao.smsSended(loginId, "FAIL", "smsdirect.ru", formattedNumber, text);
            return false;
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                // silently ignore
            }
        }
    }



    /**
     * Отправить одноразовый пароль по Sms.
     *
     * @param to получатель
     * @return пароль, или null если отправка невозможна
     */
    /*@Transactional ( readOnly = false )
    public String sendSecureRandom(String loginId, String to) {
        String strPass = getSecureRandom();
        boolean sended = send(loginId, to, "Пароль для входа в Личный кабинет: " + strPass);
        return sended ? strPass : null;
    }

    public String getSecureRandom() {
        byte[] pass = random.generateSeed(6);
        String strPass = "";
        for (byte b : pass) {
            strPass += (Math.abs(b) % 10);
        }
        return strPass;
    }*/



}
