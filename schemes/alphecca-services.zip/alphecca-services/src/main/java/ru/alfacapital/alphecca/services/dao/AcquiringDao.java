package ru.alfacapital.alphecca.services.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.alfacapital.alphecca.services.rest.AcquiringController;

import javax.sql.DataSource;
import java.math.BigDecimal;

@Repository
public class AcquiringDao {

    private JdbcTemplate jdbc;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        jdbc = new JdbcTemplate(dataSource);
    }

    public String registerOrder(String investorId, String productId, BigDecimal amount) {
        String orderId = jdbc.queryForObject("select ss.seq_order.nextval from sys.dual", String.class);
        String sql = "insert into ss.tab_order (order_id, order_date, investor_id, product_id, amount) values (?, sysdate, ?, ?, ?)";
        jdbc.update(sql, orderId, investorId, productId, amount);
        return orderId;
    }

    public void setAuxOrderId(String orderId, String auxOrderId) {
        jdbc.update("update ss.tab_order set aux_order_id = ? where order_id = ?", auxOrderId, orderId);
    }

    public boolean isOrderOfInvestor(String orderId, String investorId) {
        int count = jdbc.queryForObject("select count(*) from ss.tab_order where investor_id = ? and aux_order_id = ?", Integer.class, investorId, orderId);
        return count > 0;
    }

    public void setAuxOrderStatus(String orderId, AcquiringController.StatusResponse response) {
        String sql = "update ss.tab_order set aux_orderstatus = ?, aux_errorcode = ?, aux_errormessage = ?, aux_ordernumber = ?, aux_pan = ?, " +
                " aux_expiration = ?, aux_cardholdername = ?, aux_amount = ?, aux_currency = ?, aux_approvalcode = ?, aux_authcode = ?, aux_ip = ? " +
                " where aux_order_id = ?";
        jdbc.update(sql, response.getOrderStatus(), response.getErrorCode(), response.getErrorMessage(), response.getOrderNumber(), response.getPan(),
                response.getExpiration(), response.getCardholderName(), response.getAmount(), response.getCurrency(), response.getApprovalCode(), response.getAuthCode(), response.getIp(),
                orderId);
    }

}
