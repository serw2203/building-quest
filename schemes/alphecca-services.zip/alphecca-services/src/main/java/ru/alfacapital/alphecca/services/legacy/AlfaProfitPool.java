package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class AlfaProfitPool {

    public Date startDate;
    public Date stopDate;
    public int stepMonths;
    public BigDecimal coeffYield;
    public List<Long> observeDates = new ArrayList<Long>();

}
