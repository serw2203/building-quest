package ru.alfacapital.alphecca.services.rest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.legacy.ProjectProperty;
import ru.alfacapital.alphecca.services.legacy.SmsService;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;

import javax.servlet.http.HttpServletRequest;

@Controller
public class RuleController extends GenericController {


    @Autowired
    private SmsService sms;

    @Autowired
    private SSDaoImpl ssDao;

    @RequestMapping(value = "/investor/allowRules")
    public ResponseEntity<String> allowRules(HttpServletRequest request) {
        String investorId = checkRights(request, null);
        JSONObject responseJson = new JSONObject();
        // если правила не нужно показывать но запрос пришел то отдаем заглушку
        if (!ProjectProperty.showRule()) {
            responseJson.put("rulev1", "01.01.2001");
            responseJson.put("rulev2", "01.01.2001");
            responseJson.put("typeresult", "1");
        } else {
            responseJson = new JSONObject(ssDao.getAcceptedRules(investorId));
        }
        responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
        return new ResponseEntity<>(responseJson.toString().toLowerCase(), defaultHeaders(), HttpStatus.OK);
    }



    @RequestMapping(value = "/rule/accept")
    public ResponseEntity<String> accept(HttpServletRequest request,
                                      @RequestParam(value = "smscode", required = false) String smsCode) {
        String investorId = checkRights(request, null);
        JSONObject responseJson = new JSONObject();
        responseJson.put("status", "ok");
        if (!sms.checkSmsCode(request, smsCode, true)) {
            responseJson.put("error", "Код СМС не совпадает");
        } else {
            ssDao.setRuleAllowed(investorId);
        }
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }


    @RequestMapping(value = "/rule/accept/edf")
    public ResponseEntity<String> acceptRulesEdf(HttpServletRequest request,
                                         @RequestParam(value = "smscode", required = false) String smsCode) {
        String investorId = checkRights(request, null);
        JSONObject responseJson = new JSONObject();
        responseJson.put("status", "ok");
        if (!sms.checkSmsCode(request, smsCode, true)) {
            responseJson.put("error", "Код СМС не совпадает");
        } else {
            ssDao.acceptRulesEdf(investorId,smsCode);
        }
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }


    @RequestMapping(value = "/rule/accept/pers")
    public ResponseEntity<String> acceptRulesPers(HttpServletRequest request,
                                                 @RequestParam(value = "smscode", required = false) String smsCode) {
        String investorId = checkRights(request, null);
        JSONObject responseJson = new JSONObject();
        responseJson.put("status", "ok");
        if (!sms.checkSmsCode(request, smsCode, true)) {
            responseJson.put("error", "Код СМС не совпадает");
        } else {
            ssDao.acceptRulesPers(investorId,smsCode);
        }
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }



}
