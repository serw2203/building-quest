package ru.alfacapital.alphecca.services.legacy.reports.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance;
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover;


import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PrintableReportDao {

    public static String getXMLDate(java.sql.Date date) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+04:00");
            return sdf.format(date);
        } else {
            return null;
        }
    }

    public static java.sql.Date getDateFromXML(String date) {
        if (date != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+04:00");
            try {
                return new Date(sdf.parse(date).getTime());
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        } else {
            return null;
        }
    }

    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    @Resource
    public void setDataSource(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Transactional(readOnly = true)
    public Collection<Balance> findBalances(String investorId, String contractId, Date date) {
        String sql = "select p.valuation_currency, p.accounting_currency, p.asset_class, p.position_name, p.position_size, p.position_value, " +
                " p.position_value_rub, p.balance_value, p.maturity_date, p.asset_id, p.is_sci, p.is_security, p.isin, p.dol, s.std_description " +
                " from ss.mv_contract_position_r3 p" +
                " left join ss_datalink.mv_asset s on p.asset_id = s.asset_id " +
                "where p.investor_id = ? and p.contract_id = ? and p.aum_date = ? ";
        List<Balance> result = getJdbcTemplate().query(sql, new Object[]{investorId, contractId, date}, new RowMapper<Balance>() {
            @Override
            public Balance mapRow(ResultSet rs, int rowNum) throws SQLException {
                Balance balance = new Balance();
                balance.setValuationCurrency(rs.getString(1));
                balance.setPositionCurrency(rs.getString(2));
                balance.setAssetClass(rs.getString(3));
                balance.setPositionName(rs.getString(4));
                balance.setPositionSize(rs.getBigDecimal(5));
                balance.setPositionValue(rs.getBigDecimal(6));
                balance.setPositionValueRub(rs.getBigDecimal(7));
                balance.setBalanceValue(rs.getBigDecimal(8));
                balance.setMaturityDate(getXMLDate(rs.getDate(9)));
                balance.setAssetId(rs.getString(10));
                balance.setACI(rs.getBoolean(11));
                balance.setSecurity(rs.getBoolean(12));
                balance.setIsin(rs.getString(13));
                balance.setDol(rs.getString(14));
                balance.setAssetStdDescription(rs.getString(15));
                return balance;
            }
        });
        return result;
    }

    @Transactional(readOnly = true)
    public Collection<Turnover> findTurnovers(String contractId, Date date) {
        // Это должен быть FIFO который не трогает DMT. Т.е. Позиции открытые в следствии DMT сделок могут закрыться только сделками закрывающими DMT.
        // Шансов отследить это - нет. Поэтому DMT позиции закрываются только при полном совпадении количества бумаг в обороте.
        // Это означает, что на самом деле мы не имеем никакого права суммировать на ежедневной основе.
        // И я не вижу никакого способа обойти это цивилизованно при таком учёте.

        // В итоге. Сначала строим стек по всему что не имеет отношения к DMT
        String sql = "select asset_id, dol, fifo_qty, price, aci_price, wiring_day, cur.iso_alpha3\n" +
                "  from (\n" +
                "select contract_id, asset_id, dol, currency_id, wiring_day, \n" +
                "       least(case when total_qty + sold_after_qty > 0 then total_qty + sold_after_qty else 0 end, positive_qty) fifo_qty,\n" +
                "       price, aci_price \n" +
                "  from (\n" +
                "    select contract_id, asset_id, dol, currency_id, value / qty price, aci_value / qty aci_price, wiring_day, qty,\n" +
                "           case when qty > 0 then qty else 0 end positive_qty,\n" +
                "           sum(qty) over (partition by contract_id, asset_id, currency_id order by wiring_day, dol) total_qty, \n" +
                "           sum(case when qty < 0 then qty else 0 end) over (partition by contract_id, asset_id, currency_id order by wiring_day desc, dol desc) sold_after_qty\n" +
                "      from (select dturn.*, ROW_NUMBER() over (PARTITION BY contract_id, asset_id, qty ORDER BY WIRING_DAY, dol) AS rn from ss_datalink.mv_daily_turn dturn) t where contract_id = ? and wiring_day <= ? and dmt is null and not exists (select 1 from (select dturn.*, ROW_NUMBER() over (PARTITION BY contract_id, asset_id, qty ORDER BY WIRING_DAY, dol) AS rn from ss_datalink.mv_daily_turn dturn) tt where contract_id = ? and dmt is not null and qty = -t.qty and asset_id = t.asset_id AND rn = t.rn and wiring_day <= ? and ((qty < 0 and wiring_day > t.wiring_day) or (qty > 0 and wiring_day < t.wiring_day)))\n" +
                "  )\n" +
                ") fifo\n" +
                "join ss_datalink.mv_currency cur on cur.currency_id = fifo.currency_id " +
                "where fifo_qty <> 0 and contract_id = ?\n";
        List<Turnover> result = jdbcTemplate.query(sql, new Object[]{contractId, date, contractId, date, contractId}, new RowMapper<Turnover>() {
            @Override
            public Turnover mapRow(ResultSet rs, int rowNum) throws SQLException {
                Turnover turnover = new Turnover();
                turnover.setAssetId(rs.getString(1));
                turnover.setDol(rs.getString(2));
                turnover.setRemainingQty(rs.getBigDecimal(3));
                turnover.setPrice(rs.getBigDecimal(4));
                turnover.setAciPrice(rs.getBigDecimal(5));
                turnover.setDate(getXMLDate(rs.getDate(6)));
                turnover.setCurrency(rs.getString(7));
                return turnover;
            }
        });

        sql = "select asset_id, dol, fifo.qty, price, aci_price, wiring_day, cur.iso_alpha3\n" +
                "  from (\n" +
                "                select contract_id, asset_id, dol, qty, price, aci_price, wiring_day, currency_id from (\n" +
                "                select pos.contract_id, pos.asset_id, pos.dol, pos.currency_id, pos.price, pos.aci_price, pos.wiring_day, pos.qty + case when lead(neg.dol, 1, null) over (order by neg.dol) = neg.dol then 0 else  nvl(neg.qty, 0) end qty from\n" +
                "                (select contract_id, asset_id, dol, currency_id, value / qty price, aci_value / qty aci_price, wiring_day, qty, ROW_NUMBER() over (PARTITION BY asset_id, qty ORDER BY WIRING_DAY, dol) as rn \n" +
                "                  from ss_datalink.mv_daily_turn t where contract_id = ? and wiring_day <= ? and (dmt is not null or exists (select 1 from ss_datalink.mv_daily_turn where contract_id = ? and dmt is not null and qty = -t.qty and asset_id = t.asset_id and wiring_day > t.wiring_day and wiring_day <= ?))\n" +
                "                   and qty > 0) pos,\n" +
                "                (select contract_id, asset_id, dol, currency_id, value / qty price, aci_value / qty aci_price, wiring_day, qty, ROW_NUMBER() over (PARTITION BY asset_id, qty ORDER BY WIRING_DAY, dol) as rn \n" +
                "                  from ss_datalink.mv_daily_turn t where contract_id = ? and wiring_day <= ? and (dmt is not null or exists (select 1 from ss_datalink.mv_daily_turn where contract_id = ? and dmt is not null and qty = -t.qty and asset_id = t.asset_id and wiring_day < t.wiring_day and wiring_day <= ?))\n" +
                "                   and qty < 0) neg\n" +
                "                 where pos.contract_id = neg.contract_id(+) and pos.asset_id = neg.asset_id(+) and -pos.qty = neg.qty(+) and pos.wiring_day < neg.wiring_day(+) and pos.rn = neg.rn(+)) where qty <> 0\n" +
                ") fifo\n" +
                "join ss_datalink.mv_currency cur on cur.currency_id = fifo.currency_id " +
                "where fifo.qty <> 0 and contract_id = ?\n";
        result.addAll(jdbcTemplate.query(sql, new Object[]{contractId, date, contractId, date, contractId, date, contractId, date, contractId}, new RowMapper<Turnover>() {
            @Override
            public Turnover mapRow(ResultSet rs, int rowNum) throws SQLException {
                Turnover turnover = new Turnover();
                turnover.setAssetId(rs.getString(1));
                turnover.setDol(rs.getString(2));
                turnover.setRemainingQty(rs.getBigDecimal(3));
                turnover.setPrice(rs.getBigDecimal(4));
                turnover.setAciPrice(rs.getBigDecimal(5));
                turnover.setDate(getXMLDate(rs.getDate(6)));
                turnover.setCurrency(rs.getString(7));
                return turnover;
            }
        }));
        return result;
    }

    @Transactional(readOnly = true)
    public Map<String, Integer> getAssetClassSortOrders() {
        String sql = "select ss_name, ss_priority from ss_datalink.mv_asset_class";
        final Map<String, Integer> result = new HashMap<>();
        jdbcTemplate.query(sql, new RowMapper<Object>() {
            @Override
            public Object mapRow(ResultSet rs, int i) throws SQLException {
                result.put(rs.getString(1), rs.getInt(2));
                return null;
            }
        });
        return result;
    }

}
