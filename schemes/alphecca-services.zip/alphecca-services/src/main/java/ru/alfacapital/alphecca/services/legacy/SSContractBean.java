package ru.alfacapital.alphecca.services.legacy;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class SSContractBean implements Serializable {
    private SimpleDateFormat DDMMYYYY = new SimpleDateFormat("dd.MM.yyyy");

    private String id;
    private String investorId;
    private String contractId;
    private String orgCode;
    private String strategyName;
    private String contractNumber;
    private java.sql.Date contractDate;
    private int investmentType;

    private String compositeId;

    private Integer strategyMonths;
    private Integer stepMonths;
    private BigDecimal coeffYield;
    private Clob cancelCondition;
    private Clob disclaimer;

    private String currencyName;
    private String currencyCode;

    private Boolean blocked;



    /**
     * Периодичность отправления отчётов.
     */
    private Integer reportPeriod;

    /**
     * Идентификатор базового актива. Используется для визуализации прогноза, например для стратегий Альфа-Профит.
     */
    private String assetId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public void setStrategyName(String strategyName) {
        this.strategyName = strategyName;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }


    public String getContractNumberDate() {
        return getContractNumber() + " от " + DDMMYYYY.format(getContractDate());
    }

    public int getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(int investmentType) {
        this.investmentType = investmentType;
    }

    public String getCompositeId() {
        return compositeId;
    }

    public void setCompositeId(String compositeId) {
        this.compositeId = compositeId;
    }

    public Integer getStrategyMonths() {
        return strategyMonths;
    }

    public void setStrategyMonths(Integer strategyMonths) {
        this.strategyMonths = strategyMonths;
    }

    public Integer getStepMonths() {
        return stepMonths;
    }

    public void setStepMonths(Integer stepMonths) {
        this.stepMonths = stepMonths;
    }

    public BigDecimal getCoeffYield() {
        return coeffYield;
    }

    public void setCoeffYield(BigDecimal coeffYield) {
        this.coeffYield = coeffYield;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public Date getContractDate() {
        return contractDate;
    }

    public void setContractDate(Date contractDate) {
        this.contractDate = contractDate;
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public Integer getReportPeriod() {
        return reportPeriod;
    }

    public void setReportPeriod(Integer reportPeriod) {
        this.reportPeriod = reportPeriod;
    }

    public Clob getCancelCondition() {
        return cancelCondition;
    }

    public void setCancelCondition(Clob cancelCondition) {
        this.cancelCondition = cancelCondition;
    }

    public Clob getDisclaimer() {
        return disclaimer;
    }

    public void setDisclaimer(Clob disclaimer) {
        this.disclaimer = disclaimer;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Boolean getBlocked() {
        return blocked;
    }

    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSContractBean that = (SSContractBean) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }


}
