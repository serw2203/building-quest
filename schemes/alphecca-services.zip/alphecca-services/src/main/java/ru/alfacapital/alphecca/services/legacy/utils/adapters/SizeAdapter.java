package ru.alfacapital.alphecca.services.legacy.utils.adapters;

import ru.alfacapital.alphecca.services.legacy.utils.XMLUtils;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.math.BigDecimal;

public class SizeAdapter extends XmlAdapter<String, BigDecimal> {

    @Override
    public BigDecimal unmarshal(String v) throws Exception {
        return new BigDecimal(v);
    }

    @Override
    public String marshal(BigDecimal v) throws Exception {
        if (v == null) {
            return null;
        } else {
            return XMLUtils.xmlFormatSize(v);
        }
    }

}
