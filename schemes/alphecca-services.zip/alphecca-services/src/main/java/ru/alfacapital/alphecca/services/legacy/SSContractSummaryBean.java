package ru.alfacapital.alphecca.services.legacy;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class SSContractSummaryBean implements Serializable {

    private String investorId;
    private String contractId;
    private int investmentType;
    private Date date;
    private Long dateDQ;
    private BigDecimal aum;
    private BigDecimal closingAum;

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public int getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(int investmentType) {
        this.investmentType = investmentType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getDateDQ() {
        return dateDQ;
    }

    public void setDateDQ(Long dateDQ) {
        this.dateDQ = dateDQ;
    }

    public BigDecimal getAum() {
        return aum;
    }

    public void setAum(BigDecimal aum) {
        this.aum = aum;
    }

    public BigDecimal getClosingAum() {
        return closingAum;
    }

    public void setClosingAum(BigDecimal closingAum) {
        this.closingAum = closingAum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSContractSummaryBean that = (SSContractSummaryBean) o;

        if (investmentType != that.investmentType) return false;
        if (date != null ? !date.equals(that.date) : that.date != null) return false;
        if (contractId != null ? !contractId.equals(that.contractId) : that.contractId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = contractId != null ? contractId.hashCode() : 0;
        result = 31 * result + investmentType;
        result = 31 * result + (date != null ? date.hashCode() : 0);
        return result;
    }

}
