package ru.alfacapital.alphecca.services.legacy.data.model;

import java.io.Serializable;

public class SSFundBean implements Serializable {

    private String id;
    private String name;

    // todo эти поля есть в ДУ
    private String currencyFund;
    private String fundCode;
    private String fundName;
    private String fundNameFull;
    // ООО УК "Альфа-Капитал" Д.У. ОПИФ смешанных инвестиций «Альфа-Капитал Смешанные Инвестиции»
    private String ownerRecipientFund;
    // ИНН
    private String bankInnFund;
    // КПП
    private String bankKppFund;
    //  Наименования банка:
    private String bankRecipientFund;
    // К/с


    private String bankKAccountFund;
    // Р/c
    private String bankRAccountFund;
    // БИК
    private String bankBicFund;

    // todo следующих полей вообще нет в БД
    // Р/c  // какойто второй непонятной счет  4070 1810 9027 5000 0386 (вместо счета 40702810100000007490 — закрыт) в ОАО «АЛЬФА-БАНК» г. Москва
    private String bankRAccountFund2;
    // ОКВЭД
    private String okvd ;
    // ОКПО
    private String okpo;
    // ОГРН
    private String ogrn;
    // ОКАТО
    private String okato;
    // ОКОГУ
    private String okogu;
    // ОКФС
    private String okfs;
    // ОКОПФ
    private String okopf;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSFundBean that = (SSFundBean) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    public String getCurrencyFund() {
        return currencyFund;
    }

    public void setCurrencyFund(String currencyFund) {
        this.currencyFund = currencyFund;
    }

    public String getFundCode() {
        return fundCode;
    }

    public void setFundCode(String fundCode) {
        this.fundCode = fundCode;
    }

    public String getFundName() {
        return fundName;
    }

    public void setFundName(String fundName) {
        this.fundName = fundName;
    }

    public String getFundNameFull() {
        return fundNameFull;
    }

    public void setFundNameFull(String fundNameFull) {
        this.fundNameFull = fundNameFull;
    }

    public String getOwnerRecipientFund() {
        return ownerRecipientFund;
    }

    public void setOwnerRecipientFund(String ownerRecipientFund) {
        this.ownerRecipientFund = ownerRecipientFund;
    }

    public String getBankInnFund() {
        return bankInnFund;
    }

    public void setBankInnFund(String bankInnFund) {
        this.bankInnFund = bankInnFund;
    }

    public String getBankKppFund() {
        return bankKppFund;
    }

    public void setBankKppFund(String bankKppFund) {
        this.bankKppFund = bankKppFund;
    }

    public String getBankRecipientFund() {
        return bankRecipientFund;
    }

    public void setBankRecipientFund(String bankRecipientFund) {
        this.bankRecipientFund = bankRecipientFund;
    }

    public String getBankKAccountFund() {
        return bankKAccountFund;
    }

    public void setBankKAccountFund(String bankKAccountFund) {
        this.bankKAccountFund = bankKAccountFund;
    }

    public String getBankRAccountFund() {
        return bankRAccountFund;
    }

    public void setBankRAccountFund(String bankRAccountFund) {
        this.bankRAccountFund = bankRAccountFund;
    }

    public String getBankBicFund() {
        return bankBicFund;
    }

    public void setBankBicFund(String bankBicFund) {
        this.bankBicFund = bankBicFund;
    }

    public String getBankRAccountFund2() {
        return bankRAccountFund2;
    }

    public void setBankRAccountFund2(String bankRAccountFund2) {
        this.bankRAccountFund2 = bankRAccountFund2;
    }

    public String getOkvd() {
        return okvd;
    }

    public void setOkvd(String okvd) {
        this.okvd = okvd;
    }

    public String getOkpo() {
        return okpo;
    }

    public void setOkpo(String okpo) {
        this.okpo = okpo;
    }

    public String getOgrn() {
        return ogrn;
    }

    public void setOgrn(String ogrn) {
        this.ogrn = ogrn;
    }

    public String getOkato() {
        return okato;
    }

    public void setOkato(String okato) {
        this.okato = okato;
    }

    public String getOkogu() {
        return okogu;
    }

    public void setOkogu(String okogu) {
        this.okogu = okogu;
    }

    public String getOkfs() {
        return okfs;
    }

    public void setOkfs(String okfs) {
        this.okfs = okfs;
    }

    public String getOkopf() {
        return okopf;
    }

    public void setOkopf(String okopf) {
        this.okopf = okopf;
    }


}
