package ru.alfacapital.alphecca.services.legacy.utils;

/**
 * Created by y.bocharov on 17.09.14.
 */
public class PdfFile {

    String id;
    private byte[] pdf;
    private String fileName;

    public PdfFile() {}

    public PdfFile(String id, byte[] pdf, String fileName) {
        this.id = id;
        this.pdf = pdf;
        this.fileName = fileName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public byte[] getPdf() {
        return pdf;
    }

    public void setPdf(byte[] pdf) {
        this.pdf = pdf;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

}
