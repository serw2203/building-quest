package ru.alfacapital.alphecca.services.legacy.data.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Deprecated
public class Balance implements Serializable{

    private String valuationCurrency;
    private String assetClass;
    private String positionName;
    private String assetId;
    private String assetStdDescription;
    private String isin;
    private Date maturityDate;
    private BigDecimal positionSize;
    private BigDecimal positionValue;
    private String positionCurrency;
    private BigDecimal positionValueRub;
    private BigDecimal balanceValueRub;
    private boolean security;
    private boolean ACI;
    private String dol;

    public String getValuationCurrency() {
        return valuationCurrency;
    }

    public void setValuationCurrency(String valuationCurrency) {
        this.valuationCurrency = valuationCurrency;
    }

    public String getAssetClass() {
        return assetClass;
    }

    public void setAssetClass(String assetClass) {
        this.assetClass = assetClass;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getIsin() {
        return isin;
    }

    public void setIsin(String isin) {
        this.isin = isin;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public BigDecimal getPositionSize() {
        return positionSize;
    }

    public void setPositionSize(BigDecimal positionSize) {
        this.positionSize = positionSize;
    }

    public BigDecimal getPositionValue() {
        return positionValue;
    }

    public void setPositionValue(BigDecimal positionValue) {
        this.positionValue = positionValue;
    }

    public String getPositionCurrency() {
        return positionCurrency;
    }

    public void setPositionCurrency(String positionCurrency) {
        this.positionCurrency = positionCurrency;
    }

    public BigDecimal getPositionValueRub() {
        return positionValueRub;
    }

    public void setPositionValueRub(BigDecimal positionValueRub) {
        this.positionValueRub = positionValueRub;
    }

    public BigDecimal getBalanceValueRub() {
        return balanceValueRub;
    }

    public void setBalanceValueRub(BigDecimal balanceValueRub) {
        this.balanceValueRub = balanceValueRub;
    }

    public boolean isSecurity() {
        return security;
    }

    public void setSecurity(boolean security) {
        this.security = security;
    }

    public boolean isACI() {
        return ACI;
    }

    public void setACI(boolean ACI) {
        this.ACI = ACI;
    }

    public String getDol() {
        return dol;
    }

    public void setDol(String dol) {
        this.dol = dol;
    }

    public String getAssetStdDescription() {
        return assetStdDescription;
    }

    public void setAssetStdDescription(String assetStdDescription) {
        this.assetStdDescription = assetStdDescription;
    }
}
