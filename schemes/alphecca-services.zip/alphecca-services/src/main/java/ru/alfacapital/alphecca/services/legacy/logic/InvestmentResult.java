package ru.alfacapital.alphecca.services.legacy.logic;

import ru.ingie.commons.BigDecimals;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Результат инвестирования.
 */
public class InvestmentResult {

    private final String valuationCurrency;

    private final BigDecimal firstAum;
    private final BigDecimal yearFirstAum;

    private final BigDecimal lastQty;
    private final BigDecimal lastPrice;
    private final BigDecimal lastAum;

    private final BigDecimal inflow;
    private final BigDecimal outflow;
    private final BigDecimal yield;

    private final BigDecimal yearInflow;
    private final BigDecimal yearOutflow;
    private final BigDecimal yearYield;

    private final BigDecimal totalInflow;
    private final BigDecimal totalOutflow;
    private final BigDecimal totalYield;

    private final Long minDate;

    private final Map<Long, BigDecimal> allOperations;
    private final Map<Long, BigDecimal> allAums;

    public InvestmentResult(String valuationCurrency, BigDecimal firstAum, BigDecimal yearFirstAum, BigDecimal lastQty, BigDecimal lastPrice, BigDecimal lastAum, BigDecimal inflow, BigDecimal outflow, BigDecimal yield, BigDecimal yearInflow, BigDecimal yearOutflow, BigDecimal yearYield, BigDecimal totalInflow, BigDecimal totalOutflow, BigDecimal totalYield, Long minDate, Map<Long, BigDecimal> allOperations, Map<Long, BigDecimal> allAums) {
        this.valuationCurrency = valuationCurrency;
        this.firstAum = firstAum;
        this.yearFirstAum = yearFirstAum;
        this.lastQty = lastQty;
        this.lastPrice = lastPrice;
        this.lastAum = lastAum;

        this.inflow = inflow;
        this.outflow = outflow;
        this.yield = yield;

        this.yearInflow = yearInflow;
        this.yearOutflow = yearOutflow;
        this.yearYield = yearYield;

        this.totalInflow = totalInflow;
        this.totalOutflow = totalOutflow;
        this.totalYield = totalYield;

        this.minDate = minDate;
        this.allOperations = allOperations;
        this.allAums = allAums;
    }

    /**
     * Возвращает валюту, в которой произведена оценка.
     * Эта валюта - максимальная валюта позиции.
     *
     * @return валюта оценки
     */
    public String getValuationCurrency() {
        return valuationCurrency;
    }

    /**
     * Возвращает СЧА на начало периода.
     *
     * @return начальное СЧА
     */
    public BigDecimal getFirstAum() {
        return firstAum;
    }


    /**
     * Возвращает СЧА на начало года.
     *
     * @return начальное СЧА
     */
    public BigDecimal getYearFirstAum() {
        return yearFirstAum;
    }

    /**
     * Возвращает количество на конец периода (если применимо)
     *
     * @return количество
     */
    public BigDecimal getLastQty() {
        return lastQty;
    }

    /**
     * Возвращает стоимость единицы на конец периода (если применимо)
     *
     * @return стоимость единицы
     */
    public BigDecimal getLastPrice() {
        return lastPrice;
    }

    /**
     * Возвращает СЧА на конец периода.
     *
     * @return СЧА на конец периода
     */
    public BigDecimal getLastAum() {
        return lastAum;
    }

    /**
     * Возвращает сумму вводов за период.
     *
     * @return сумма вводов за период
     */
    public BigDecimal getInflow() {
        return inflow;
    }

    /**
     * Возвращает сумму выводов за период.
     *
     * @return сумма выводов за период
     */
    public BigDecimal getOutflow() {
        return outflow;
    }

    /**
     * Возвращает доходность за период.
     *
     * @return доходность за период
     */
    public BigDecimal getYield() {
        return yield;
    }

    /**
     * Возвращает внешний финансовый поток за период.
     *
     * @return сумма вводов и выводов за период
     */
    public BigDecimal getFlow() {
        return getInflow().subtract(getOutflow());
    }

    /**
     * Возвращает финансовый результат периода
     *
     * @return финансовый результат периода
     */
    public BigDecimal getIncome() {
        return getLastAum().subtract(getFirstAum()).subtract(getFlow());
    }

    /**
     * Возвращает финансовый результат периода
     *
     * @return финансовый результат периода
     */
    public BigDecimal getIncomePercent() {
        BigDecimal a = getIncome();
        BigDecimal b = getInflow().add(getFirstAum());
        if (b.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        else {
            return a.multiply(BigDecimals.BD100).divide(b, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
    }

    /**
     * Возвращает сумму вводов с начала инвестирования.
     *
     * @return сумма вводов с начала инвестирования
     */
    public BigDecimal getTotalInflow() {
        return totalInflow;
    }

    /**
     * Возвращает сумму выводов с начала инвестирования.
     *
     * @return сумма выводов с начала инвестирования
     */
    public BigDecimal getTotalOutflow() {
        return totalOutflow;
    }

    /**
     * Доходность с начала инвестирования.
     *
     * @return доходность с начала инвестирования
     */
    public BigDecimal getTotalYield() {
        return totalYield;
    }

    /**
     * Возвращает внешний финансовый поток с начала инвестирования.
     *
     * @return сумма вводов и выводов за период
     */
    public BigDecimal getTotalFlow() {
        return getTotalInflow().subtract(getTotalOutflow());
    }

    /**
     * Возвращает финансовый результат с начала инвестирования.
     *
     * @return финансовый результат с начала инвестирования
     */
    public BigDecimal getTotalIncome() {
        return getLastAum().subtract(getTotalFlow());
    }

    /**
     * Возвращает финансовый результат с начала инвестирования.
     *
     * @return финансовый результат с начала инвестирования
     */
    public BigDecimal getTotalIncomePercent() {
        BigDecimal a = getTotalIncome();
        BigDecimal b = getTotalInflow();
        if (b.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        else {
            return a.multiply(BigDecimals.BD100).divide(b, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
    }

    /**
     * Возвращает сумму вводов с начала года.
     *
     * @return сумма вводов с начала года
     */
    public BigDecimal getYearInflow() {
        return yearInflow;
    }

    /**
     * Возвращает сумму выводов с начала года.
     *
     * @return сумма выводов с начала года
     */
    public BigDecimal getYearOutflow() {
        return yearOutflow;
    }

    /**
     * Доходность с начала года.
     *
     * @return доходность с начала года
     */
    public BigDecimal getYearYield() {
        return yearYield;
    }

    /**
     * Возвращает внешний финансовый поток с начала года.
     *
     * @return сумма вводов и выводов с начала года
     */
    public BigDecimal getYearFlow() {
        return getYearInflow().subtract(getYearOutflow());
    }


    public BigDecimal getYearIncome() {
        return getLastAum().subtract(getYearFirstAum()).subtract(getYearFlow());
    }

    /**
     * Возвращает финансовый результат периода
     *
     * @return финансовый результат периода
     */
    public BigDecimal getYearIncomePercent() {
        BigDecimal a = getYearIncome();
        BigDecimal b = getYearInflow().add(getYearFirstAum());
        if (b.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        else {
            return a.multiply(BigDecimals.BD100).divide(b, 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
    }

    /**
     * Возвращает дату начала инвестиций. Т.е. дату первой операции приобретения/ввода ДС.
     *
     * @return дата начала инвестиций
     */
    public Long getMinDate() {
        return minDate;
    }

    /**
     * Все операции вне зависимости от периода.
     *
     * @return все операции
     */
    public Map<Long, BigDecimal> getAllOperations() {
        return allOperations;
    }

    /**
     * Все оценки вне зависимости от периода
     *
     * @return все оценки
     */
    public Map<Long, BigDecimal> getAllAums() {
        return allAums;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InvestmentResult that = (InvestmentResult) o;

        if (firstAum != null ? !firstAum.equals(that.firstAum) : that.firstAum != null) return false;
        if (inflow != null ? !inflow.equals(that.inflow) : that.inflow != null) return false;
        if (lastAum != null ? !lastAum.equals(that.lastAum) : that.lastAum != null) return false;
        if (lastPrice != null ? !lastPrice.equals(that.lastPrice) : that.lastPrice != null) return false;
        if (lastQty != null ? !lastQty.equals(that.lastQty) : that.lastQty != null) return false;
        if (outflow != null ? !outflow.equals(that.outflow) : that.outflow != null) return false;
        if (totalInflow != null ? !totalInflow.equals(that.totalInflow) : that.totalInflow != null) return false;
        if (totalOutflow != null ? !totalOutflow.equals(that.totalOutflow) : that.totalOutflow != null) return false;
        if (totalYield != null ? !totalYield.equals(that.totalYield) : that.totalYield != null) return false;
        if (valuationCurrency != null ? !valuationCurrency.equals(that.valuationCurrency) : that.valuationCurrency != null)
            return false;
        if (yield != null ? !yield.equals(that.yield) : that.yield != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = valuationCurrency != null ? valuationCurrency.hashCode() : 0;
        result = 31 * result + (firstAum != null ? firstAum.hashCode() : 0);
        result = 31 * result + (lastQty != null ? lastQty.hashCode() : 0);
        result = 31 * result + (lastPrice != null ? lastPrice.hashCode() : 0);
        result = 31 * result + (lastAum != null ? lastAum.hashCode() : 0);
        result = 31 * result + (inflow != null ? inflow.hashCode() : 0);
        result = 31 * result + (outflow != null ? outflow.hashCode() : 0);
        result = 31 * result + (yield != null ? yield.hashCode() : 0);
        result = 31 * result + (totalInflow != null ? totalInflow.hashCode() : 0);
        result = 31 * result + (totalOutflow != null ? totalOutflow.hashCode() : 0);
        result = 31 * result + (totalYield != null ? totalYield.hashCode() : 0);
        return result;
    }

}
