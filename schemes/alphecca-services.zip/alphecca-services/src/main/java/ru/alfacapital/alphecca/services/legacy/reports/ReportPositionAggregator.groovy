package ru.alfacapital.alphecca.services.legacy.reports

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import ru.alfacapital.alphecca.services.legacy.DefaultCurrencyRater
import ru.alfacapital.alphecca.services.legacy.data.dao.PositionDao
import ru.alfacapital.alphecca.services.legacy.reports.dao.PrintableReportDao
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance
import ru.alfacapital.alphecca.services.legacy.reports.model.FinancialResult
import ru.alfacapital.alphecca.services.legacy.reports.model.ReportPosition
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover


@Component
public class ReportPositionAggregator {

    @Autowired
    private DefaultCurrencyRater currencyRater;

    @Autowired
    private PositionDao positionDao;

    public List<ReportPosition> aggregate(Collection<Turnover> turnovers, Collection<Balance> balances, Date reportDate) {

        def totalAssetQuantities = balances.findAll { it.security }.groupBy { it.assetId }.collectEntries { [it.key, it.value.sum({ it.positionSize })] }
        def totalAssetACI = balances.findAll { it.ACI }.groupBy { it.assetId }.collectEntries { [it.key, it.value.sum({ it.positionValueRub })] }

        Collection<Balance> mutableBalances = deepcopy(balances) as Collection<Balance>

        def positions = turnovers.collect { turnover ->
            // Сначала пытаемся найти ДМТ для данного оборота
            Balance balance = mutableBalances.find { it.security && (it.dol != null && turnover.dol != null && it.dol == turnover.dol)}
            // Если не получилось, то ищем обычные остатки для данного assetId и суммируем их в один остаток.
            if (balance == null) {
                Collection<Balance> balancesForAsset = mutableBalances.findAll { it.security && (it.assetId == turnover.assetId) }
                if (balancesForAsset.size() == 0) {
                    // Не найден остаток по обороту. Это возможно, например, если у нас были позиции с одним и тем же инструментом в DMT и без DMT.
                    // Придётся игнорировать.
                    return null;
//                    throw new IllegalArgumentException("Не найден остаток по обороту ( assetId=${turnover.assetId}, buyDate=${turnover.date} )")
                }
                balance = balancesForAsset.inject(summarizeBalances)
                mutableBalances.removeAll(balancesForAsset)
            } else {
                mutableBalances.remove(balance)
            }

            def turnoverPrice = turnover.price
            def turnoverAciPrice = turnover.aciPrice
            if (balance.valuationCurrency != turnover.currency) {
                turnoverPrice = currencyRater.rate(turnoverPrice, turnover.currency, balance.valuationCurrency, turnover.date)
                turnoverAciPrice = currencyRater.rate(turnoverAciPrice, turnover.currency, balance.valuationCurrency, turnover.date)
            }
            def remainingSize = balance.positionSize - turnover.remainingQty
            if (remainingSize < 0) {
                // Таких портфеля 3 на 14.07.2014. Не хватило времени разобраться.
                return null
                //throw new IllegalArgumentException("Количество по оборотам превысило количество по остаткам (assetId=${turnover.assetId}, remainingSize=${remainingSize})")
            }
            ReportPosition position = new ReportPosition()
            position.qty = turnover.remainingQty
            position.buyPrice = turnoverPrice
            position.buyDate = turnover.date
            position.buyValue = turnoverPrice * turnover.remainingQty
            def aciValue = turnoverAciPrice * turnover.remainingQty
            def accumulatedValue = currencyRater.rate(balance.positionValueRub, balance.valuationCurrency, reportDate)
            position.assetClass = balance.assetClass
            position.currentPrice = accumulatedValue / balance.positionSize
            position.currentValue = Math.round(position.currentPrice * turnover.remainingQty * 100) / 100
            position.description = balance.positionName
            position.stdDescription = balance.assetStdDescription
            position.currency = balance.valuationCurrency
            position.maturityDate = balance.maturityDate
            position.totalResult = new FinancialResult(
                    financialResult: position.buyValue == 0 ? 0 : position.currentValue - position.buyValue,
                    yield: position.buyValue == 0 ? 0 : (position.currentValue / position.buyValue - 1) * 100,
            );
            position.yearResult = zeroFinancialResult()
            position.periodResult = zeroFinancialResult()
            // Сначала ищем составные части по dol (для ДМТ)
            Collection<Balance> parts = mutableBalances.findAll { it.dol != null && turnover.dol != null && it.dol == turnover.dol }
            // Если не нашли, то попробуем поискать по assetId
            def assetId = turnover.assetId;
            def aciPerShare = (totalAssetACI[assetId] == null ? 0 : totalAssetACI[assetId]) / totalAssetQuantities[assetId];
            if (parts.isEmpty()) {
                parts = mutableBalances.findAll { ( ! it.isSecurity() ) && it.assetId == assetId }
            }
            Map<String, List<Balance>> classifiedBalances = parts.groupBy(classifyBalances)
            makeSubpositions(classifiedBalances, position, balance, reportDate, aciPerShare as BigDecimal, aciValue)

            classifiedBalances.each { partName, partBalance ->
                partBalance.each {
                    // Во всех остатках только одна строка с расчётным НКД, её нужно оставить для использования
                    if (!it.ACI) mutableBalances.remove(it)
                }
            }

            // Возвращаем в коллекцию остаток, который не вошел в позицию
            if (remainingSize > 0) {
                def priceRub = balance.positionValueRub / balance.positionSize
                balance.positionSize = remainingSize
                balance.positionValueRub = priceRub * remainingSize
                mutableBalances << balance
            }

            return position
        }

        positions.findAll() // *.findAll() - убирает элементы null из коллекции

        // Обрабатываем остатки, по которым нет оборотов
        def balancesByAssets =  mutableBalances.findAll({it.assetId != null}).groupBy { it.assetId }
        balancesByAssets.each { assetId, listOfBalances ->
            def listOfSecurityBalances = listOfBalances.findAll({ it.security })
            if (!listOfSecurityBalances.isEmpty()) {
                def securityBalance = listOfSecurityBalances.inject(summarizeBalances)
                def classifiedBalances = listOfBalances.findAll({ !it.security }).groupBy(classifyBalances)
                // не включаем в отчет позицции с нулевым размером
                if (securityBalance.positionSize != 0) {
                    def position = makePositionFromOnlyBalance(securityBalance, reportDate)
                    def aciPerShare = (totalAssetACI[assetId] == null ? 0 : totalAssetACI[assetId]) / totalAssetQuantities[assetId];
                    makeSubpositions(classifiedBalances, position, securityBalance, reportDate, aciPerShare as BigDecimal, 0)
                    positions << position
                }
                mutableBalances.removeAll(listOfBalances)
            }
        }

        // Чуть выше мы манипулировали с остатками НКД, старательно оберегая их от затирания. Теперь мы можем сделать это.
        mutableBalances.removeAll({it.ACI})

        // Всякое разное без assetId
        def remainingPositions = mutableBalances.collect { balance ->
            ReportPosition position = makePositionFromOnlyBalance(balance, reportDate)
            return position
        }
        positions.addAll(remainingPositions)
        return positions.findAll() // *.findAll() - убирает элементы null из коллекции
    }

    private ReportPosition makePositionFromOnlyBalance(Balance balance, Date reportDate) {
        ReportPosition position = new ReportPosition()
        position.assetClass = balance.assetClass
        position.qty = balance.positionSize
        if (balance.valuationCurrency == balance.positionCurrency) {
            // Если можно обойтись без бессмысленных конвертаций - обходимся
            position.currentValue = balance.positionValue
        }
        else {
            position.currentValue = Math.round(currencyRater.rate(balance.positionValueRub, balance.valuationCurrency, reportDate) * 100) / 100
        }
        // Если размер позиции нулевой, то не считаем её цену
        if (balance.positionSize != 0) {
            position.currentPrice = position.currentValue / position.qty
        }
        position.description = balance.positionName
        position.stdDescription = balance.assetStdDescription
        position.currency = balance.valuationCurrency
        position.maturityDate = balance.maturityDate
        position.totalResult = zeroFinancialResult()
        position.yearResult = zeroFinancialResult()
        position.periodResult = zeroFinancialResult()
        position
    }

    private static FinancialResult zeroFinancialResult() {
        new FinancialResult(
                financialResult: 0,
                yield: 0
        )
    }

    private void makeSubpositions(Map<String, List<Balance>> classifiedBalances, ReportPosition position, Balance balance, Date reportDate, BigDecimal aciPerShareRub, BigDecimal aciValue) {
        def originalQty = position.qty
        if (classifiedBalances.size() > 0) {
            position.subPositions << new ReportPosition(
                    description: balance.isin,
                    qty: position.qty,
                    buyPrice: position.buyPrice,
                    buyValue: position.buyValue,
                    currentPrice: position.currentPrice,
                    currentValue: position.currentValue,
                    currency: position.currency
            )

            def depositFinancialResult = zeroFinancialResult();
            classifiedBalances.each { classifier, listOfBalances ->
                if (listOfBalances.size() > 0) {
                    // todo: Тут было бы лучше выбрасывать эксепшен, если будут находиться больше одного остатка по каждой подпозиции
                    Balance reducedBalance = listOfBalances.inject(summarizeBalances)
                    reducedBalance.balanceValue = listOfBalances.get(0).balanceValue // усиливает необходимость в выбрасывании исключения выше
                    reducedBalance.positionCurrency = listOfBalances.get(0).positionCurrency

                    def buyValue = null;
                    def value;
                    if (classifier == 'НКД') {
                        buyValue = aciValue
                        value = currencyRater.rate(position.qty * aciPerShareRub, position.currency, reportDate)
                    }
                    else {
                        value = currencyRater.rate(reducedBalance.positionValueRub, position.currency, reportDate)
                    }
                    position.subPositions << new ReportPosition(
                            description: classifier,
                            currentValue: Math.round(value * 100) / 100,
                            buyValue: buyValue
                    )
                    if (classifier == "Собственные средства") {
                        def a0 = currencyRater.rate(reducedBalance.balanceValue, reducedBalance.positionCurrency, position.currency, PrintableReportDao.getDateFromXML( position.buyDate))
                        def a9 = value
                        depositFinancialResult = new FinancialResult(
                                    financialResult: a9 - a0,
                                    yield: (a9 / a0 - 1) * 100
                            );
                    }
                }
            }

            position.subPositions.sort { a, b ->
                def ai = a.description == "НКД" ? 1 : (a.description == "Собственные средства" ? 2 : (a.description == "Займ" ? 3 : 0))
                def bi = b.description == "НКД" ? 1 : (b.description == "Собственные средства" ? 2 : (b.description == "Займ" ? 3 : 0))
                ai.compareTo(bi)
            }

            // Оценку основной позиции нужно пересчитать просуммировав подпозиции
            position.currentValue = position.subPositions.currentValue.sum() as BigDecimal
            position.buyPrice = null
            position.currentPrice = null
            position.qty = null

            if (position.subPositions.find { it.description == "Собственные средства" } != null) { // Для DMT-позиций финансовый результат считается особенным образом
                def totalPnL = depositFinancialResult.financialResult
                def totalInflow = -totalPnL
                position.subPositions.each {
                    if (it.description != "Собственные средства") {
                        totalPnL += it.currentValue
                    } else {
                        totalInflow += it.currentValue
                    }
                }
                position.totalResult = new FinancialResult(
                        financialResult: totalPnL,
                        yield: totalInflow == 0 ? 0 : (totalPnL / totalInflow) * 100
                )
                position.yearResult = zeroFinancialResult()
                position.periodResult = zeroFinancialResult()
                position.buyValue = totalInflow
            }
            else { // Для остальных позиций по прочим ЦБ прибавляем к результату целиком выплаченные купоны
                position.buyValue = 0
                position.subPositions.each { if (it.buyValue != null) position.buyValue += it.buyValue }
                def aciPerShareAccuired = position.buyDate == null ? 0 : calculateAccuiredCouponIncome(balance.assetId, PrintableReportDao.getDateFromXML( position.buyDate), reportDate)
                position.totalResult = new FinancialResult(
                        financialResult: position.buyValue == 0 ? 0 : (position.currentValue - position.buyValue + originalQty * aciPerShareAccuired),
                        yield: position.buyValue == 0 ? 0 : ((position.currentValue + originalQty * aciPerShareAccuired) / position.buyValue - 1) * 100
                )
                position.yearResult = zeroFinancialResult()
                position.periodResult = zeroFinancialResult()
            }
        }
    }

    private calculateAccuiredCouponIncome(String assetId, Date startDate, Date stopDate) {
        return positionDao.getAccuiredCouponIncome(assetId, startDate, stopDate);
    }

    def summarizeBalances = { Balance value, Balance item ->
        value.positionSize += item.positionSize
        value.positionValueRub += item.positionValueRub
        return value
    }

    def classifyBalances = { Balance balance ->
        if (balance.ACI) {
            "НКД"
        } else if (balance.assetClass == "Депозиты") {
            "Собственные средства"
        } else if (balance.assetClass == "Прочее") {
            "Займ"
        }
    }

    static def deepcopy(orig) {
        def baos = new ByteArrayOutputStream()
        baos.withObjectOutputStream { it.writeObject(orig) }
        def bais = new ByteArrayInputStream(baos.toByteArray())
        bais.withObjectInputStream { it.readObject() }
    }

}
