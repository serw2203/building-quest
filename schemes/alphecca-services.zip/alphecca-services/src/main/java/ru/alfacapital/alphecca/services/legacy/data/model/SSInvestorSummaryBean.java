package ru.alfacapital.alphecca.services.legacy.data.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;


public class SSInvestorSummaryBean implements Serializable {

    private String investorId;
    private int investmentType;
    private Date date;
    private Long dateDQ;
    private BigDecimal aum;
    private BigDecimal closingAum;

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public int getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(int investmentType) {
        this.investmentType = investmentType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getDateDQ() {
        return dateDQ;
    }

    public void setDateDQ(Long dateDQ) {
        this.dateDQ = dateDQ;
    }

    public BigDecimal getAum() {
        return aum;
    }

    public void setAum(BigDecimal aum) {
        this.aum = aum;
    }

    public BigDecimal getClosingAum() {
        return closingAum;
    }

    public void setClosingAum(BigDecimal closingAum) {
        this.closingAum = closingAum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSInvestorSummaryBean that = (SSInvestorSummaryBean) o;

        if (investmentType != that.investmentType) return false;
        if (dateDQ != null ? !dateDQ.equals(that.dateDQ) : that.dateDQ != null) return false;
        if (investorId != null ? !investorId.equals(that.investorId) : that.investorId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = investorId != null ? investorId.hashCode() : 0;
        result = 31 * result + investmentType;
        result = 31 * result + (date != null ? date.hashCode() : 0);
        return result;
    }

}
