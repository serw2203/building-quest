package ru.alfacapital.alphecca.services.legacy;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;

import java.util.List;

/**
 * Created by y.bocharov on 09.06.14.
 */
public class KladrAddress {


    private String country   = "";
    private String index     = "";
    private String region    = "";
    private String district  = "";   // район
    private String city      = "";
    private String locality  = "";   // населенный пункт
    private String street    = "";
    private String building  = "";
    private String flat      = "";

    private void restField() {
        country  = "";
        index    = "";
        region   = "";
        district = "";
        city     = "";
        locality = "";
        street   = "";
        building = "";
        flat     = "";
    }

    public KladrAddress() {

    }

    public KladrAddress(String country,
                        String index,
                        String region,
                        String district,
                        String city,
                        String locality,
                        String street,
                        String building ,
                        String flat) {
        setCountry(country);
        setIndex(index);
        setRegion(region);
        setDistrict(district);
        setCity(city);
        setLocality(locality);
        setStreet(street);
        setBuilding(building);
        setFlat(flat);

    }

    public KladrAddress(String address) {
        setValue(address);
    }

    public void setValue(String value) {
        if (value == null) {
            restField();
            return;
        }
        List<String> parts = Splitter.on(",").splitToList(value);
        if (parts.size() < 9) {
            restField();
            return;
        }
        // Альфа капиталл использует свой особый стандрат КЛАДР в котором страна идет перед индексом,
        // Россия,620042,Свердловская обл,-,Екатеринбург г,-,Бакинских комиссаров ул,40,7
        // в то время как все остальные используют неверный формат в котором индекс идет перед страной
        // 109559, РОССИЯ, г. Москва, г. МОСКВА, ГОРОД МОСКВА, УЛИЦА ВЕРХНИЕ ПОЛЯ, д.35, кор.2, кв.49
        if (isIndex(parts.get(0)) && isRussia(parts.get(1))) {
            setCountry(parts.get(1));
            setIndex(parts.get(0));
        } else {
            setCountry(parts.get(0));
            setIndex(parts.get(1));
        }
        setRegion(parts.get(2));
        setDistrict(parts.get(3));
        setCity(parts.get(4));
        setLocality(parts.get(5));
        setStreet(parts.get(6));
        setBuilding(parts.get(7));
        setFlat(parts.get(8));
    }

    public static boolean isIndex(String str) {
        return ((str != null) && (str.length() == 6) && str.matches("[0-9]+"));
    }

    public static boolean isRussia(String country) {
        return "РОССИЯ".equals(country.toUpperCase());
    }

    @Override
    public String toString() {
        String[] array = new String[] {
                getCountry().replace(",", ";"),
                getIndex().replace(",", ";"),
                getRegion().replace(",", ";"),
                getDistrict().replace(",", ";"),
                getCity().replace(",", ";"),
                getLocality().replace(",", ";"),
                getStreet().replace(",", ";"),
                getBuilding().replace(",", ";"),
                getFlat().replace(",", ";")
        };
        return Joiner.on(",").join(array);
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getFlat() {
        return flat;
    }

    public void setFlat(String flat) {
        this.flat = flat;
    }

}
