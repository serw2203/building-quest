package ru.alfacapital.alphecca.services.legacy.reports.model;

import ru.alfacapital.alphecca.services.legacy.CurrencyRater;
import ru.alfacapital.alphecca.services.legacy.logic.ValuedPosition;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PositionResponse2 {

    // Позиция ложится сюда отсортированная в нужном порядке, сначала по валюте, потом по классу
    public List<PrimitivePosition> positions = new ArrayList<PrimitivePosition>();

    public ValuedPosition asValuedPosition(CurrencyRater currencyRater, Date positionDate) {
        // Тут считаем сумму по каждой валюте в самой валюте
        Map<String, BigDecimal> valuesByCurrencies = new HashMap<>();
        for (PrimitivePosition p: positions) {
            BigDecimal thisValue = currencyRater.rate(p.positionValueRub, p.valuationCurrency, positionDate);;
            if (p.sciValueRub != null) {
                BigDecimal sciValueCur= currencyRater.rate(p.sciValueRub, p.valuationCurrency, positionDate);
                thisValue = thisValue.add(sciValueCur);
            }
            if (p.debtValueRub != null) {
                BigDecimal debtValueCur= currencyRater.rate(p.debtValueRub, p.valuationCurrency, positionDate);
                thisValue = thisValue.add(debtValueCur);
            }
            if (p.depositValueRub != null) {
                BigDecimal depositValueCur= currencyRater.rate(p.depositValueRub, p.valuationCurrency, positionDate);
                thisValue = thisValue.add(depositValueCur);
            }
            BigDecimal accumulatedValue = valuesByCurrencies.get(p.valuationCurrency);
            if (accumulatedValue != null) {
                accumulatedValue = accumulatedValue.add(thisValue);
            } else {
                accumulatedValue = thisValue;
            }
            valuesByCurrencies.put(p.valuationCurrency, accumulatedValue);
        }

        // сложение и сравнение происходит в национальной валюте
        Map<String, BigDecimal> map = new HashMap<>();
        BigDecimal positionValueNC = BigDecimal.ZERO;
        for (PrimitivePosition p : positions) {
            BigDecimal was = map.get(p.valuationCurrency);
            if (was == null) was = BigDecimal.ZERO;
            map.put(p.valuationCurrency, was.add(p.positionValueRub));
            positionValueNC = positionValueNC.add(p.positionValueRub);
        }
        BigDecimal max = null;

        // тут выводим преобладающую валюту
        String prevailedCurrencyCode = "RUB";
        for (Map.Entry<String, BigDecimal> e : map.entrySet()) {
            BigDecimal pret = e.getValue();
            if (max == null || pret.compareTo(max) > 0) {
                max = pret;
                prevailedCurrencyCode = e.getKey();
            }
        }
        return new ValuedPosition(positionValueNC, prevailedCurrencyCode, valuesByCurrencies );
    }

}
