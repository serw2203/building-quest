package ru.alfacapital.alphecca.services.legacy.utils;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

public class JasperUtils {

    private static final Logger log = LoggerFactory.getLogger(JasperUtils.class);

    public static byte[] generate(JSONObject json, byte[] template) {
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport(new ByteArrayInputStream(template));
            List<Map<String,?>> list = new ArrayList<Map<String,?>>();
            Map resMap = new HashMap();
            resMap.putAll(toMap(((JSONObject)json.get("request"))));
            resMap.putAll(toMap((JSONObject) ((JSONArray)json.get("response")).get(0)));
            list.add(resMap);
            JRMapCollectionDataSource jrMapCollectionDataSource = new JRMapCollectionDataSource(list);
            Map<String, Object> metadata = new HashMap<>();
            // эта строчка не помогает для изменения даты с 31 march -> 31 марта
            // возможно она помогает для чего-то другого
            Locale locale = new Locale("ru", "RU");
            metadata.put(JRParameter.REPORT_LOCALE, locale);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, metadata, jrMapCollectionDataSource);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JasperExportManager.exportReportToPdfStream(jasperPrint, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        }
        catch (JRException e) {
            log.error("Error during generation of the PDF document.");

        }
        return new byte[0];
    }

    public static Map toMap(JSONObject object) throws JSONException {
        Map<String, Object> map = new HashMap<String, Object>();
        Iterator<String> keysItr = object.keys();
        while(keysItr.hasNext()) {
            String key = keysItr.next();
            Object value = object.get(key);
            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }
            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            map.put(key, value);
        }
        return map;
    }

    public static List toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for(int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }
            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }
        return list;
    }

}
