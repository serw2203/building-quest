package ru.alfacapital.alphecca.services.rest;

import flexjson.JSONSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;
import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;
import ru.alfacapital.alphecca.services.legacy.data.model.SSFundBean;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;

@Controller
public class FundController extends GenericController {

    @Autowired
    private SSDaoImpl ssFundDao;

    @RequestMapping(value = "/fund/fundRequestConfirm")
    public ResponseEntity<String> fundRequestConfirm(@RequestParam(value = "fundId", required = false) String fundId,
                                                     @RequestParam(value = "price", required = false) String price,
                                                     @RequestParam(value = "currency", required = false) String currency,
                                                     @RequestParam(value = "investorId", required = false) String investorId,
                                                     HttpServletRequest request) {
        investorId = checkRights(request, investorId);
        return new ResponseEntity<>(getDataConfirm(investorId, fundId, price, currency) , defaultHeaders(), HttpStatus.OK);
    }

    /*@RequestMapping(value = "/fund/fundDetails")
    public ResponseEntity<String> fundDetails(@RequestParam(value = "fund", required = true) String idFund, HttpServletRequest request) {
        return new ResponseEntity<>(getDataFunds(idFund), defaultHeaders(), HttpStatus.OK);
    }*/

    public String getDataConfirm(String investorId, String idFund, String price, String currency) {
        Long crtDate = SSConstants.toDQ(new Date());
        BigDecimal priceFund = ssFundDao.getShareValue(idFund, crtDate, crtDate).get(crtDate);
        BigDecimal countPif = (new BigDecimal(price)).divide(priceFund);

        StringBuilder sb = new StringBuilder();
        String orderNumber =  ssFundDao.getNextOrderNumber();
        // todo в зависимоти от пола меняем обращение уважаемый / уважаемая
        String treatment = "Уважаемый клиент";


        sb.append("{");
        sb.append("\"treatment\":\"").append(treatment).append("\",");
        sb.append("\"countPif\":\"").append(countPif).append("\",");
        sb.append("\"price\":\"").append(price).append("\",");
        sb.append("\"orderNumber\":\"").append(orderNumber).append("\",");
        sb.append("\"fund\":").append(getDataFunds(idFund)).append("");
        sb.append("}");

        return sb.toString();
    }

    public String getDataFunds(String idFund) {
        SSFundBean fund = this.getSsFundDao().getFund(idFund);
        Map <String, Object> resultStruct = new HashMap<String, Object> ();

        resultStruct.put("id", fund.getId());
        resultStruct.put("name", fund.getName());
        resultStruct.put("currencyFund", fund.getCurrencyFund());
        resultStruct.put("fundCode", fund.getFundCode());
        resultStruct.put("fundName", fund.getFundName());
        resultStruct.put("fundNameFull", fund.getFundNameFull());
        resultStruct.put("ownerRecipientFund", fund.getOwnerRecipientFund());
        resultStruct.put("bankInnFund", fund.getBankInnFund());
        resultStruct.put("bankKppFund", fund.getBankKppFund());
        resultStruct.put("bankRecipientFund", fund.getBankRecipientFund());
        resultStruct.put("bankKAccountFund", fund.getBankKAccountFund());
        resultStruct.put("bankRAccountFund", fund.getBankRAccountFund());
        resultStruct.put("bankBicFund", fund.getBankBicFund());
        resultStruct.put("bankRAccountFund2", fund.getBankRAccountFund2());
        resultStruct.put("okvd", fund.getOkvd());
        resultStruct.put("okpo", fund.getOkpo());
        resultStruct.put("ogrn", fund.getOgrn());
        resultStruct.put("okato", fund.getOkato());
        resultStruct.put("okogu", fund.getOkogu());
        resultStruct.put("okfs", fund.getOkfs());
        resultStruct.put("okopf", fund.getOkopf());
        return new JSONSerializer().deepSerialize(resultStruct);
    }

    public SSDaoImpl getSsFundDao() {
        return ssFundDao;
    }

}
