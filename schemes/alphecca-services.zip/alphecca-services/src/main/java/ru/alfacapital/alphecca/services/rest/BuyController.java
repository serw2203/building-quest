package ru.alfacapital.alphecca.services.rest;

import flexjson.JSONSerializer;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.dao.JsonJdbcDao;
import ru.alfacapital.alphecca.services.legacy.SmsService;
import ru.alfacapital.alphecca.services.legacy.du.DUAMServices;
import ru.alfacapital.alphecca.services.legacy.du.DUServices;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Date;

@Controller
public class BuyController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(BuyController.class);

    private SecureRandom random = new SecureRandom(("a[93jfo93mf asdf90cz39m01jfm57" + System.currentTimeMillis()).getBytes());

    @Autowired
    private JsonJdbcDao dao;

    @Autowired
    private DUServices duServices;

    @Autowired
    private DUAMServices duAmServices;


    @Autowired
    private SmsService sms;

    @Autowired
    private RuleController rule;

    @Autowired
    AlfaClickController alfaClickController;

    public static class BuyControllerResponse {

        String error;
        String number;
        Date date;

        public BuyControllerResponse(String number, Date date, String error) {
            this.number = number;
            this.date = date;
            this.error = error;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public Date getDate() {
            return date;
        }

        public void setDate(Date date) {
            this.date = date;
        }
    }

    @RequestMapping("/buy/send-sms-code")
    public ResponseEntity<String> generateInvestorPassword(
                                                    HttpServletRequest request,
                                                    @RequestParam(value = "jwt", required = false) String jwt) {
        byte[] pass = random.generateSeed(6);
        String smsCode = "";
        for (byte b : pass) {
            smsCode += (Math.abs(b) % 10);
        }
        sms.saveSmsCode(request, smsCode);



        String investorId = checkRights(request, null);
        String loginId = dao.getLoginIdByInvestorId(investorId);
        String phoneNumber = null;

        // пытаемся вытащить номер телефона из логина
        if (!StringUtils.isEmpty(jwt)) {
            try {
                phoneNumber = (String) alfaClickController.getAlfaClickUser(jwt).get("mbln");
            } catch (GeneralSecurityException | IOException | RuntimeException e)  {
                // если токен не распарсился значи оно не надо
            }
        }
        // если из токена номер не взялся то берем из базы
        // тут зашита логика что если есть токен то всегда берем данные из токена
        if (StringUtils.isEmpty(phoneNumber)) {
            phoneNumber = dao.getPhoneByInvestorId(investorId);
        }
        String smsMessage = "Kod dlya podtverzhdeniya operacii - " + smsCode;
        JSONObject responseJson = new JSONObject();
        boolean isSent = sms.send(loginId, phoneNumber, smsMessage);
        if (isSent) {
            responseJson.put("status", "ok");
            responseJson.put("phoneNumber", phoneNumber);
        } else {
            responseJson.put("status", "error");
            responseJson.put("error", "Сбой службы отправки SMS");
        }
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    @RequestMapping("/buy/checksms")
    public ResponseEntity<String> checksms(HttpServletRequest request,
                                            @RequestParam(value = "smscode", required = true) String smscode)  {
        JSONObject responseJson = new JSONObject();
        if (sms.checkSmsCode(request, smscode, true) ) {
            responseJson.put("ok", "ok");
        } else {
            responseJson.put("error", "Неверно введен СМС код");
        }
        responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    @RequestMapping(value = "/buy/buyfundss")
    public ResponseEntity<String> buyfundss(HttpServletRequest request,
                                          @RequestParam(value = "fundid", required = true) String fundId,
                                          @RequestParam(value = "smscode", required = true) String smscode,
                                          @RequestParam(value = "investorId", required = false) String investorId,

                                          @RequestParam(value = "bic", required = false) String bic,
                                          @RequestParam(value = "bankname", required = false) String bankName,
                                          @RequestParam(value = "cr", required = false) String cr,
                                          @RequestParam(value = "pr", required = false) String pr,

                                          @RequestParam(value = "pc", required = false) String personalAccount) {
        log.info("InvestorId:" + investorId + " started buying fundId:" + fundId);
        BuyControllerResponse response;
        investorId = checkRights(request, investorId);
        log.info("InvestorId:" + investorId + " started buying fundId:" + fundId + "rights checked...OK");
        try {
          /*  if (!rule.checkRule(investorId)) {
                log.error("Для совершения покупки необходимо согаситься с правилами."  + investorId);
                throw new RuntimeException("Для совершения покупки необходимо согаситься с правилами.");
            }*/
            log.info("InvestorId:" + investorId + " started buying fundId:" + fundId + "rule checked...OK");
            if (!sms.checkSmsCode(request, smscode, true) ) {
                log.error("Код СМС не совпадает."  + investorId);
                throw new RuntimeException("Код СМС не совпадает");
            }
            log.info("InvestorId:" + investorId + " started buying fundId:" + fundId + "sms checked...OK");
            DUServices.DUResponse duResp = duServices.sendFundToDU(investorId, fundId, smscode, DUServices.CODE_BUY, BigDecimal.ZERO, BigDecimal.ZERO, null, bic, bankName, cr, pr, personalAccount, "", duServices.LOGIN_LK);
            log.info("InvestorId:" + investorId + " started buying fundId:" + fundId + "DU_SERVICE checked...OK");
            response = new BuyControllerResponse(duResp.getNumber(), duResp.getDate(), "");
        } catch (RuntimeException e) {
            response = new BuyControllerResponse("", null, e.getMessage());
        }
        String json = new JSONSerializer().exclude("class").deepSerialize(response);
        return new ResponseEntity<>(json, defaultHeaders(), HttpStatus.OK);
    }

    @RequestMapping(value = "/sell/fund")
    public ResponseEntity<String> sellFund(HttpServletRequest request,
                                            @RequestParam(value = "fundid", required = true) String fundId,
                                            @RequestParam(value = "smscode", required = false) String smscode,
                                            @RequestParam(value = "investorId", required = false) String investorId,
                                            @RequestParam(value = "amount", required = false) BigDecimal amount,

                                            @RequestParam(value = "bic", required = false) String bic,
                                            @RequestParam(value = "bankname", required = false) String bankName,
                                            @RequestParam(value = "cr", required = false) String cr,
                                            @RequestParam(value = "pr", required = false) String pr,

                                            @RequestParam(value = "pc", required = false) String personalAccount) {

        investorId = checkRights(request, investorId);
        BuyControllerResponse response;
        try {
            /*if (!rule.checkRule(investorId)) {
                throw new RuntimeException("Для совершения покупки необходимо согаситься с правилами.");
            }*/
            DUServices.DUResponse duResp = duServices.sendFundToDU(investorId, fundId, "", DUServices.CODE_SELL, BigDecimal.ZERO, amount, null, bic, bankName, cr, pr, personalAccount, "", duServices.LOGIN_LK);
            response = new BuyControllerResponse(duResp.getNumber(), duResp.getDate(), "");
        } catch (RuntimeException e) {
            response = new BuyControllerResponse("", null, e.getMessage());
        }
        String json = new JSONSerializer().exclude("class").deepSerialize(response);
        return new ResponseEntity<>(json, defaultHeaders(), HttpStatus.OK);
    }

    @RequestMapping(value = "/change/fund")
    public ResponseEntity<String> changeFund(HttpServletRequest request,
                                           @RequestParam(value = "fundid", required = true) String fundId,
                                           @RequestParam(value = "smscode", required = false) String smscode,
                                           @RequestParam(value = "investorId", required = false) String investorId,
                                           @RequestParam(value = "amount", required = false) BigDecimal amount,
                                           @RequestParam(value = "fundidswap", required = true) String fundIdswap,

                                           @RequestParam(value = "pc", required = false) String personalAccount,
                                           @RequestParam(value = "pcsrc", required = false) String personalAccountSwap) {
        investorId = checkRights(request, investorId);
        BuyControllerResponse response;
        try {
           /* if (!rule.checkRule(investorId)) {
                throw new RuntimeException("Для совершения покупки необходимо согаситься с правилами.");
            }*/
            if (!sms.checkSmsCode(request, smscode, true) ) {
                throw new RuntimeException("Код СМС не совпадает");
            }
            DUServices.DUResponse duResp = duServices.sendFundToDU(investorId, fundId, smscode, DUServices.CODE_EXCH , BigDecimal.ZERO, amount, fundIdswap, "", "", "", "", personalAccount, personalAccountSwap, duServices.LOGIN_LK);
            response = new BuyControllerResponse(duResp.getNumber(), duResp.getDate(), "");
        } catch (RuntimeException e) {
            response = new BuyControllerResponse("", null, e.getMessage());
        }
        String json = new JSONSerializer().exclude("class").deepSerialize(response);
        return new ResponseEntity<>(json, defaultHeaders(), HttpStatus.OK);
    }

    @Deprecated
    @RequestMapping(value = "/buy/buyam")
    public ResponseEntity<String> details(HttpServletRequest request,
                                          @RequestParam(value = "strategyid", required = true) String contractid,
                                          @RequestParam(value = "amount", required = true) String amount,

                                          @RequestParam(value = "bic", required = false) String bic,
                                          @RequestParam(value = "bankname", required = false) String bankName,
                                          @RequestParam(value = "cr", required = false) String cr,
                                          @RequestParam(value = "pr", required = false) String pr,

                                          @RequestParam(value = "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        BuyControllerResponse response;
        try {
           /* if (!rule.checkRule(investorId)) {
                throw new RuntimeException("Для совершения покупки необходимо согаситься с правилами.");
            }*/
            DUServices.DUResponse duResponse = duAmServices.sendAmToDuLK(investorId, contractid, new BigDecimal(amount), bic, bankName, cr, pr);
            response = new BuyControllerResponse(duResponse.getNumber().split("/")[0], duResponse.getDate(), "");
        } catch (RuntimeException e) {
            response = new BuyControllerResponse("", null, e.getMessage());
        }
        String json = new JSONSerializer().exclude("class").deepSerialize(response);
        return new ResponseEntity<>(json, defaultHeaders(), HttpStatus.OK);

    }
}
