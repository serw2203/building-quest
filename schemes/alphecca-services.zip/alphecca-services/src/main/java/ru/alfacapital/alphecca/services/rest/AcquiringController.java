package ru.alfacapital.alphecca.services.rest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import ru.alfacapital.alphecca.services.dao.AcquiringDao;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;

@Controller
public class AcquiringController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(AcquiringController.class);

    // todo: EDIT on DEPLOYMENT
    private static final String USERNAME = "alfacapital-api";
    private static final String PASSWORD = "alfacapital";
    public static final String URL_BASE = "https://test.paymentgate.ru/testpayment/rest/";
    private static final String URL_REGISTER_ORDER = URL_BASE + "register.do";
    private static final String URL_GET_ORDER_STATUS = URL_BASE + "getOrderStatus.do";

    // todo: EDIT on DEPLOYMENT
    // Страница на которую эквайер вернёт браузер клиента после успешной оплаты
    // Настройка для запуска через alphecca-js
//    private static final String URL_FINAL = "http://localhost:8000/private/finish.html";
    // Тестовый стенд в ДЦ
    private static final String URL_FINAL = "https://itg-ln-srv127:8443/alphecca-private/finish.html";

    // Естественно из Альфа-Банка JSON приходит в виде text/plain. Никто не удивлён.
    private MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter() {
        {
            List<MediaType> list = new ArrayList<>(getSupportedMediaTypes());
            list.add(new MediaType("text", "plain", DEFAULT_CHARSET));
            setSupportedMediaTypes(list);
        }
    };
    private RestTemplate rest = new RestTemplate() {
        {
            getMessageConverters().add(converter);
        }
    };

    @Autowired
    private AcquiringDao dao;

    @RequestMapping ("/acquiring/create-order/productid/{productid}/amount/{amount}")
    public ResponseEntity<String> createOrder(HttpServletRequest request,
                                              @PathVariable(value = "amount") BigDecimal amount,
                                              @PathVariable(value = "productid") String productid,
                                              @RequestParam(value = "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        String orderId = dao.registerOrder(investorId, productid, amount);
        Map<String, Object> params = new HashMap<>();
        params.put("userName", USERNAME);
        params.put("password", PASSWORD);
        params.put("amount", amount.multiply(new BigDecimal("100"))); // У Альфа-Банка всё в копейках.
        params.put("orderNumber", orderId);
        params.put("returnUrl", URL_FINAL);
        params.put("description", "Оплата инвестиционных продуктов ООО УК \"Альфа-Капитал\"");
        RegisterResponse response = rest.getForObject(URL_REGISTER_ORDER + "?userName={userName}&password={password}&amount={amount}&orderNumber={orderNumber}&language=ru&currency=810&returnUrl={returnUrl}&description={description}", RegisterResponse.class, params);
        if (response.errorCode != 0) {
            log.error("{} returned for order {} ({})", response.errorCode, orderId, response.errorMessage);
        }
        dao.setAuxOrderId(orderId, response.getOrderId());
        JSONObject json = new JSONObject();
        json.put("formUrl", response.getFormUrl());
        json.put("orderId", response.getOrderId());
        json.put("errorCode", response.getErrorCode());
        json.put("errorMessage", response.getErrorMessage());
        return new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK);
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class RegisterResponse {
        private String orderId;
        private String formUrl;
        int errorCode;
        String errorMessage;

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public String getFormUrl() {
            return formUrl;
        }

        public void setFormUrl(String formUrl) {
            this.formUrl = formUrl;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(int errorCode) {
            this.errorCode = errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }

    @RequestMapping ("/acquiring/get-status/orderid/{orderid}")
    public ResponseEntity<String> getStatus(HttpServletRequest request,
                                            @PathVariable(value = "orderid") String orderId,
                                            @RequestParam(value = "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        JSONObject json = new JSONObject();
        boolean securityCheck = dao.isOrderOfInvestor(orderId, investorId);
        if (securityCheck) {
            Map<String, Object> params = new HashMap<>();
            params.put("userName", USERNAME);
            params.put("password", PASSWORD);
            params.put("orderId", orderId);
            StatusResponse response = rest.getForObject(URL_GET_ORDER_STATUS + "?userName={userName}&password={password}&orderId={orderId}&language=ru", StatusResponse.class, params);
            dao.setAuxOrderStatus(orderId, response);
            if (response.ErrorCode == null) {
                // странная ситуация возникающая как минимум на тестовом стенде, означает, что нужно подождать
                json.put("complete", false);
                json.put("retryOrderId", orderId);
            } else if (response.ErrorCode != 0 && response.ErrorCode != 2) {
                log.error("{} returned for order {} ({})", response.ErrorCode, orderId, response.ErrorMessage);
                json.put("complete", false);
                json.put("errorMessage", "Системная ошибка");
            } else {
                if (response.OrderStatus != null && response.OrderStatus == 2) {
                    json.put("complete", true);
                } else {
                    json.put("complete", false);
                    json.put("errorMessage", "Транзакция не завершена. " + (response.ErrorMessage != null ? response.ErrorMessage : ""));
                }
            }
        }
        else {
            json.put("complete", false);
            json.put("errorMessage", "Попытка обращения к чужому заказу");
            log.error("Restricted access of investor {} to order {}", investorId, orderId);
        }
        return new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK);
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class StatusResponse {
        private Integer OrderStatus;
        private Integer ErrorCode;
        private String ErrorMessage;
        private String OrderNumber;
        private String Pan;
        private Integer expiration;
        private String cardholderName;
        private long Amount;
        private Integer currency;
        private String approvalCode;
        private Integer authCode;
        private String Ip;

        @JsonProperty ("OrderStatus")
        public Integer getOrderStatus() {
            return OrderStatus;
        }

        @JsonProperty ("OrderStatus")
        public void setOrderStatus(Integer orderStatus) {
            this.OrderStatus = orderStatus;
        }

        @JsonProperty ("ErrorCode")
        public Integer getErrorCode() {
            return ErrorCode;
        }

        @JsonProperty ("ErrorCode")
        public void setErrorCode(Integer errorCode) {
            this.ErrorCode = errorCode;
        }

        @JsonProperty ("ErrorMessage")
        public String getErrorMessage() {
            return ErrorMessage;
        }

        @JsonProperty ("ErrorMessage")
        public void setErrorMessage(String errorMessage) {
            this.ErrorMessage = errorMessage;
        }

        @JsonProperty ("OrderNumber")
        public String getOrderNumber() {
            return OrderNumber;
        }

        @JsonProperty ("OrderNumber")
        public void setOrderNumber(String orderNumber) {
            this.OrderNumber = orderNumber;
        }

        @JsonProperty ("Pan")
        public String getPan() {
            return Pan;
        }

        @JsonProperty ("Pan")
        public void setPan(String pan) {
            this.Pan = pan;
        }

        public Integer getExpiration() {
            return expiration;
        }

        public void setExpiration(Integer expiration) {
            this.expiration = expiration;
        }

        public String getCardholderName() {
            return cardholderName;
        }

        public void setCardholderName(String cardholderName) {
            this.cardholderName = cardholderName;
        }

        @JsonProperty ("Amount")
        public long getAmount() {
            return Amount;
        }

        @JsonProperty ("Amount")
        public void setAmount(long amount) {
            this.Amount = amount;
        }

        public Integer getCurrency() {
            return currency;
        }

        public void setCurrency(Integer currency) {
            this.currency = currency;
        }

        public String getApprovalCode() {
            return approvalCode;
        }

        public void setApprovalCode(String approvalCode) {
            this.approvalCode = approvalCode;
        }

        public Integer getAuthCode() {
            return authCode;
        }

        public void setAuthCode(Integer authCode) {
            this.authCode = authCode;
        }

        @JsonProperty ("Ip")
        public String getIp() {
            return Ip;
        }

        @JsonProperty ("Ip")
        public void setIp(String ip) {
            this.Ip = ip;
        }

    }

}
