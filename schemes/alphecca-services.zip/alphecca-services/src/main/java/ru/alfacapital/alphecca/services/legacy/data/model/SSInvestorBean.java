package ru.alfacapital.alphecca.services.legacy.data.model;


import java.io.Serializable;
import java.sql.Blob;
import java.sql.Date;

public class SSInvestorBean implements Serializable {

    private String investorId;
    private String loginId;
    private String userId;
    private String login;
    private String name;
    private Date birthDate;
    private String overridedName;
    private String passHash;

    private String managerFirstName;
    private String managerLastName;
    private String managerName;
    private String managerMobile;
    private String managerMail;
    private Blob managerPhoto;
    private String managerPhotoMimeType;

    private int fundsCount;
    private int assetsCount;
    private boolean legalEntity;

    private String documentSeries;
    private String documentNumber;
    private String documentSeriesNumber;



    private Date docDate;
    private String inn;
    private String kpp;

    private String realAddress;
    private String jureAddress;

    private int mailCount;

    private Date maxReportDate;
    private long maxReportDateDQ;

    private String investorMail;
    private String investorCellPhone;

    private boolean showManagerPhone;

    private Date blockDate;
    private boolean blocked;
    private Date rulesAcceptDate;

    private String serviceClass;
    private String reportCurrencyId;


    private String birthplace;
    private String gender;
    private String documentIssuer;
    private String documentIssuerCode;
    private String documentType;
    private int usaCitizen;

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLogin() {
        return login;
    }

    //@Override
    public String getDisplayName() {
        return getOverridedName() == null ? getName() : getOverridedName();
    }

    //@Override
    public String getNameWithDocument() {
        if (getDocumentNumber() == null && getDocumentSeries() == null) {
            return getName();
        }
        else {
            return getName() + " (" + (getDocumentSeries() != null ? getDocumentSeries()  + " " : "") + (getDocumentNumber() != null ? getDocumentNumber() : "") + ")";
        }
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getOverridedName() {
        return overridedName;
    }

    public void setOverridedName(String overridedName) {
        this.overridedName = overridedName;
    }

    public String getPassHash() {
        return passHash;
    }

    public void setPassHash(String passHash) {
        this.passHash = passHash;
    }

    public String getManagerFirstName() {
        return managerFirstName;
    }

    public void setManagerFirstName(String managerFirstName) {
        this.managerFirstName = managerFirstName;
    }

    public String getManagerLastName() {
        return managerLastName;
    }

    public void setManagerLastName(String managerLastName) {
        this.managerLastName = managerLastName;
    }

    public int getFundsCount() {
        return fundsCount;
    }

    public void setFundsCount(int fundsCount) {
        this.fundsCount = fundsCount;
    }

    public int getAssetsCount() {
        return assetsCount;
    }

    public void setAssetsCount(int assetsCount) {
        this.assetsCount = assetsCount;
    }

    public boolean isLegalEntity() {
        return legalEntity;
    }

    public void setLegalEntity(boolean legalEntity) {
        this.legalEntity = legalEntity;
    }

    public String getDocumentSeries() {
        return documentSeries;
    }

    public void setDocumentSeries(String documentSeries) {
        this.documentSeries = documentSeries;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentSeriesNumber() {
        return documentSeriesNumber;
    }

    public void setDocumentSeriesNumber(String documentSeriesNumber) {
        this.documentSeriesNumber = documentSeriesNumber;
    }

    public String getRealAddress() {
        return realAddress;
    }

    public void setRealAddress(String realAddress) {
        this.realAddress = realAddress;
    }

    public Date getDocDate() {
        return docDate;
    }

    public void setDocDate(Date docDate) {
        this.docDate = docDate;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public int getMailCount() {
        return mailCount;
    }

    public void setMailCount(int mailCount) {
        this.mailCount = mailCount;
    }

    public Date getMaxReportDate() {
        return maxReportDate;
    }

    public void setMaxReportDate(Date maxReportDate) {
        this.maxReportDate = maxReportDate;
    }

    public long getMaxReportDateDQ() {
        return maxReportDateDQ;
    }

    public void setMaxReportDateDQ(long maxReportDateDQ) {
        this.maxReportDateDQ = maxReportDateDQ;
    }

    //@Override
    public boolean isPerson() {
        return !isLegalEntity();
    }

    //@Override
    public String getId() {
        return getInvestorId();
    }

    //@Override
    public void setId(String id) {
        setInvestorId(id);
    }




    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public String getManagerMobile() {
        return managerMobile;
    }

    public void setManagerMobile(String managerMobile) {
        this.managerMobile = managerMobile;
    }

    public String getManagerMail() {
        return managerMail;
    }

    public void setManagerMail(String managerMail) {
        this.managerMail = managerMail;
    }

    public Blob getManagerPhoto() {
        return managerPhoto;
    }

    public void setManagerPhoto(Blob managerPhoto) {
        this.managerPhoto = managerPhoto;
    }

    public String getManagerPhotoMimeType() {
        return managerPhotoMimeType;
    }

    public void setManagerPhotoMimeType(String managerPhotoMimeType) {
        this.managerPhotoMimeType = managerPhotoMimeType;
    }

    public String getInvestorMail() {
        return investorMail;
    }

    public void setInvestorMail(String investorMail) {
        this.investorMail = investorMail;
    }

    public String getInvestorCellPhone() {
        return investorCellPhone;
    }

    public void setInvestorCellPhone(String investorCellPhone) {
        this.investorCellPhone = investorCellPhone;
    }

    public boolean isShowManagerPhone() {
        return showManagerPhone;
    }

    public boolean isReallyShowManagerPhone() {
        return isShowManagerPhone() || (getAssetsCount() ) > 0;
    }

    public void setShowManagerPhone(boolean showManagerPhone) {
        this.showManagerPhone = showManagerPhone;
    }

    public Date getBlockDate() {
        return blockDate;
    }

    public void setBlockDate(Date blockDate) {
        this.blockDate = blockDate;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

    public Date getRulesAcceptDate() {
        return rulesAcceptDate;
    }

    public void setRulesAcceptDate(Date rulesAcceptDate) {
        this.rulesAcceptDate = rulesAcceptDate;
    }

    public String getServiceClass() {
        return serviceClass;
    }

    public void setServiceClass(String serviceClass) {
        this.serviceClass = serviceClass;
    }

    public String getReportCurrencyId() {
        return reportCurrencyId;
    }

    public void setReportCurrencyId(String reportCurrencyId) {
        this.reportCurrencyId = reportCurrencyId;
    }

    public String getJureAddress() {
        return jureAddress;
    }

    public void setJureAddress(String jureAddress) {
        this.jureAddress = jureAddress;
    }

    public String getKpp() {
        return kpp;
    }

    public void setKpp(String kpp) {
        this.kpp = kpp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSInvestorBean that = (SSInvestorBean) o;

        if (investorId != null ? !investorId.equals(that.investorId) : that.investorId != null) return false;
        if (loginId != null ? !loginId.equals(that.loginId) : that.loginId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = investorId != null ? investorId.hashCode() : 0;
        result = 31 * result + (loginId != null ? loginId.hashCode() : 0);
        return result;
    }

    /**
     * Возвращает фамилию и имя инвестиционного консультанта, если это человек, иначе то, что в БД.
     *
     * @return имя ИК для отображения пользователю
     */
    public String getManagerNameForDisplay() {
        String test = getManagerName();
        if (test != null && (test.endsWith("вич") || test.endsWith("вна"))) {
            int idx1 = test.indexOf(" ");
            if (idx1 > 0) {
                int idx2 = test.indexOf(" ", idx1 + 1);
                if (idx2 > 0) {
                    int idx3 = test.indexOf(" ", idx2 + 1);
                    if (idx3 < 0) {
                        return test.substring(0, idx2).trim();
                    }
                    else {
                        return test;
                    }
                }
                else {
                    return test;
                }
            }
            else {
                return test;
            }
        }
        else {
            return test;
        }
    }

    public String getBirthplace() {
        return birthplace;
    }

    public void setBirthplace(String birthplace) {
        this.birthplace = birthplace;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDocumentIssuer() {
        return documentIssuer;
    }

    public void setDocumentIssuer(String documentIssuer) {
        this.documentIssuer = documentIssuer;
    }

    public String getDocumentIssuerCode() {
        return documentIssuerCode;
    }

    public void setDocumentIssuerCode(String documentIssuerCode) {
        this.documentIssuerCode = documentIssuerCode;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public int getUsaCitizen() {
        return usaCitizen;
    }

    public void setUsaCitizen(int usaCitizen) {
        this.usaCitizen = usaCitizen;
    }


    @Override
    public String toString() {
        return "SSInvestorBean{" +
                "investorId='" + investorId + '\'' +
                ", loginId='" + loginId + '\'' +
                ", userId='" + userId + '\'' +
                ", login='" + login + '\'' +
                ", name='" + name + '\'' +
                ", birthDate=" + birthDate +
                ", overridedName='" + overridedName + '\'' +
                ", passHash='" + passHash + '\'' +
                ", managerFirstName='" + managerFirstName + '\'' +
                ", managerLastName='" + managerLastName + '\'' +
                ", managerName='" + managerName + '\'' +
                ", managerMobile='" + managerMobile + '\'' +
                ", managerMail='" + managerMail + '\'' +
                ", fundsCount=" + fundsCount +
                ", assetsCount=" + assetsCount +
                ", legalEntity=" + legalEntity +
                ", documentSeries='" + documentSeries + '\'' +
                ", documentNumber='" + documentNumber + '\'' +
                ", documentSeriesNumber='" + documentSeriesNumber + '\'' +
                ", docDate=" + docDate +
                ", inn='" + inn + '\'' +
                ", kpp='" + kpp + '\'' +
                ", realAddress='" + realAddress + '\'' +
                ", jureAddress='" + jureAddress + '\'' +
                ", mailCount=" + mailCount +
                ", maxReportDate=" + maxReportDate +
                ", maxReportDateDQ=" + maxReportDateDQ +
                ", investorMail='" + investorMail + '\'' +
                ", investorCellPhone='" + investorCellPhone + '\'' +
                ", showManagerPhone=" + showManagerPhone +
                ", blockDate=" + blockDate +
                ", blocked=" + blocked +
                ", rulesAcceptDate=" + rulesAcceptDate +
                ", serviceClass='" + serviceClass + '\'' +
                ", reportCurrencyId='" + reportCurrencyId + '\'' +
                ", birthplace='" + birthplace + '\'' +
                ", gender='" + gender + '\'' +
                ", documentIssuer='" + documentIssuer + '\'' +
                ", documentIssuerCode='" + documentIssuerCode + '\'' +
                ", documentType='" + documentType + '\'' +
                ", usaCitizen=" + usaCitizen +
                '}';
    }
}
