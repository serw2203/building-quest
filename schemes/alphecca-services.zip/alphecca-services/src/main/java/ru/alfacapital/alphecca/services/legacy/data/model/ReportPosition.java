package ru.alfacapital.alphecca.services.legacy.data.model;

import ru.alfacapital.alphecca.services.legacy.utils.adapters.CurrencyAdapter;
import ru.alfacapital.alphecca.services.legacy.utils.adapters.DateAdapter;
import ru.alfacapital.alphecca.services.legacy.utils.adapters.SizeAdapter;

import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Deprecated
@XmlRootElement(name = "position")
@XmlAccessorType(XmlAccessType.NONE)
public class ReportPosition {

    @XmlAttribute
    String description;

    String stdDescription;

    @XmlAttribute
    @XmlJavaTypeAdapter(DateAdapter.class)
    Date maturityDate;

    @XmlAttribute
    @XmlJavaTypeAdapter(DateAdapter.class)
    Date buyDate;

    @XmlAttribute
    @XmlJavaTypeAdapter(SizeAdapter.class)
    BigDecimal qty;

    @XmlAttribute
    @XmlJavaTypeAdapter(CurrencyAdapter.class)
    BigDecimal buyPrice;

    @XmlAttribute
    @XmlJavaTypeAdapter(CurrencyAdapter.class)
    BigDecimal buyValue;

    @XmlAttribute
    @XmlJavaTypeAdapter(CurrencyAdapter.class)
    BigDecimal currentPrice;

    @XmlAttribute
    @XmlJavaTypeAdapter(CurrencyAdapter.class)
    BigDecimal currentValue;

    @XmlElement
    FinancialResult totalResult;

    @XmlElement
    FinancialResult yearResult;

    @XmlElement
    FinancialResult periodResult;

    String currency;

    String assetClass;

    @XmlElement
    List<ReportPosition> subPositions = new ArrayList<>();

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStdDescription() {
        return stdDescription;
    }

    public void setStdDescription(String stdDescription) {
        this.stdDescription = stdDescription;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    public Date getBuyDate() {
        return buyDate;
    }

    public void setBuyDate(Date buyDate) {
        this.buyDate = buyDate;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    public BigDecimal getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(BigDecimal buyPrice) {
        this.buyPrice = buyPrice;
    }

    public BigDecimal getBuyValue() {
        return buyValue;
    }

    public void setBuyValue(BigDecimal buyValue) {
        this.buyValue = buyValue;
    }

    public BigDecimal getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(BigDecimal currentPrice) {
        this.currentPrice = currentPrice;
    }

    public BigDecimal getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(BigDecimal currentValue) {
        this.currentValue = currentValue;
    }

    public FinancialResult getTotalResult() {
        return totalResult;
    }

    public void setTotalResult(FinancialResult totalResult) {
        this.totalResult = totalResult;
    }

    public FinancialResult getYearResult() {
        return yearResult;
    }

    public void setYearResult(FinancialResult yearResult) {
        this.yearResult = yearResult;
    }

    public FinancialResult getPeriodResult() {
        return periodResult;
    }

    public void setPeriodResult(FinancialResult periodResult) {
        this.periodResult = periodResult;
    }

    public List<ReportPosition> getSubPositions() {
        return subPositions;
    }

    public void setSubPositions(List<ReportPosition> subPositions) {
        this.subPositions = subPositions;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAssetClass() {
        return assetClass;
    }

    public void setAssetClass(String assetClass) {
        this.assetClass = assetClass;
    }
}
