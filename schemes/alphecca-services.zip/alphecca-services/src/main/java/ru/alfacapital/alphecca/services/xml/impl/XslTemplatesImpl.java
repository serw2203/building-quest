package ru.alfacapital.alphecca.services.xml.impl;

import org.springframework.core.io.Resource;
import ru.alfacapital.alphecca.services.xml.XslTemplates;


import java.io.IOException;
import java.io.InputStream;

public class XslTemplatesImpl implements XslTemplates {

    private Resource xslPortfolioReport;

    public void setXslPortfolioReport(Resource xslPortfolioReport) {
        this.xslPortfolioReport = xslPortfolioReport;
    }

    @Override
    public InputStream getXslPortfolioReportAsStream() throws IOException {
        return xslPortfolioReport.getInputStream();
    }

}
