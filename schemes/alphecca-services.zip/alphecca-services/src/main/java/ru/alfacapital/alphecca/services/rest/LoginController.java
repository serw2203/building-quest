package ru.alfacapital.alphecca.services.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class LoginController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String str = "<html>\n" +
                "<head></head>\n" +
                "<body>\n" +
                "   <h1>Login is " + req.getUserPrincipal() + "</h1>\n" +
                "   <form name='f' action=\"j_spring_security_check\" method='POST'>\n" +
                "      <table>\n" +
                "         <tr>\n" +
                "            <td>User:</td>\n" +
                "            <td><input type='text' name='j_username' value=''></td>\n" +
                "         </tr>\n" +
                "         <tr>\n" +
                "            <td>Password:</td>\n" +
                "            <td><input type='password' name='j_password' /></td>\n" +
                "         </tr>\n" +
                "         <tr>\n" +
                "            <td><input name=\"submit\" type=\"submit\" value=\"submit\" /></td>\n" +
                "         </tr>\n" +
                "      </table>\n" +
                "  </form>\n" +
                "</body>\n" +
                "</html>";
        resp.getOutputStream().print(str);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

}
