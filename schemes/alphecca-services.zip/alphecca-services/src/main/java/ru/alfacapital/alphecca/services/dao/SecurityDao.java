package ru.alfacapital.alphecca.services.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.math.BigDecimal;

@Repository
public class SecurityDao {

    private JdbcTemplate jdbc;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        jdbc = new JdbcTemplate(dataSource);
    }

    public String getInvestorIdByLogin(String login) {
        String sql = "select max(investor_id) from ss.vie_ss_investor where login = ?";
        return jdbc.queryForObject(sql, new Object[] { login }, String.class);
    }

    public boolean haveRights(String login, String investorId) {
        String sql = "select count(*) incount from ss.vie_ss_investor where investor_id = ? and user_id in (" +
                " select u.user_id from ss_datalink.mv_user u start with u.user_id in (select user_id from ss.tab_user_subst where (cancel_date is null or cancel_date > sysdate) and subst_id in (select user_id from ss_datalink.mv_user where lower(samaccountname) = lower(?))) connect by prior u.user_id = u.parent_user_id " +
                " union all " +
                " select user_id from ss_datalink.mv_user start with lower(samaccountname) = lower(?) connect by prior user_id = parent_user_id)";
        BigDecimal incount = jdbc.queryForObject(sql, new Object[]{investorId, login, login}, BigDecimal.class);
        return BigDecimal.ONE.compareTo(incount) == 0;
    }

    public String getInvestorIdByCus(String alfaBankClientId) {
        String sql = "select max(investor_id) from ss_datalink.mv_investor where alfabank_client_id = ?";
        return jdbc.queryForObject(sql, new Object[] { alfaBankClientId }, String.class);
    }

    public String getInvestorIdByDocument(String series, String number) {
        String sql = "select max(investor_id) from ss_datalink.mv_investor where replace(document_series, ' ', '') = ? and replace(document_number, ' ', '') = ?";
        return jdbc.queryForObject(sql, new Object[] { series, number }, String.class);
    }


}
