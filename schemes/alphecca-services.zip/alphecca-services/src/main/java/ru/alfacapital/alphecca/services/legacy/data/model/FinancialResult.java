package ru.alfacapital.alphecca.services.legacy.data.model;

import ru.alfacapital.alphecca.services.legacy.utils.adapters.CurrencyAdapter;
import ru.alfacapital.alphecca.services.legacy.utils.adapters.PercentAdapter;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.math.BigDecimal;

@Deprecated
@XmlAccessorType(XmlAccessType.FIELD)
public class FinancialResult {

    @XmlAttribute
    @XmlJavaTypeAdapter(CurrencyAdapter.class)
    private BigDecimal financialResult;

    @XmlAttribute
    @XmlJavaTypeAdapter(PercentAdapter.class)
    private BigDecimal yield;

    public BigDecimal getFinancialResult() {
        return financialResult;
    }

    public void setFinancialResult(BigDecimal financialResult) {
        this.financialResult = financialResult;
    }

    public BigDecimal getYield() {
        return yield;
    }

    public void setYield(BigDecimal yield) {
        this.yield = yield;
    }
}
