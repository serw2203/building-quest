package ru.alfacapital.alphecca.services.legacy.utils;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by y.bocharov on 02.10.14.
 */
public class Common {

    // регулярка из ЭДО для проверки почты, пока никто не жаловался, что нельзя ввести email
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._-]+@[A-Z0-9.-]+\\.[A-Z]{1,6}$", Pattern.CASE_INSENSITIVE);

    public static String nvl(String str) {
        return (str == null) ?"" : str;
    }



    public static HashMap<String, String> REGIONS_TYPE = new HashMap<String, String>();
    static {
        REGIONS_TYPE.put("001","АОБЛ");  //АВТОНОМНАЯ ОБЛАСТЬ
        REGIONS_TYPE.put("002","АО");  //АВТОНОМНЫЙ ОКРУГ
        REGIONS_TYPE.put("003","ВОЛ");  //ВОЛОСТЬ
        REGIONS_TYPE.put("004","КРАЙ");  //КРАЙ
        REGIONS_TYPE.put("005","МО");  //МУНИЦИПАЛЬНЫЙ ОКРУГ
        REGIONS_TYPE.put("006","МЫС");  //МЫС
        REGIONS_TYPE.put("007","ОБЛ");  //ОБЛАСТЬ
        REGIONS_TYPE.put("008","ОСТРОВ");  //ОСТРОВ
        REGIONS_TYPE.put("009","П-ОВ");  //ПОЛУОСТРОВ
        REGIONS_TYPE.put("010","Р-Н");  //РАЙОН
        REGIONS_TYPE.put("011","РЕСП");  //РЕСПУБЛИКА
        REGIONS_TYPE.put("012","ТЕР");  //ТЕРРИТОРИЯ
        REGIONS_TYPE.put("013","ЦО");  //ЦЕНТРАЛЬНЫЙ ОКРУГ
        REGIONS_TYPE.put("015","Г");  //ГОРОД
    }

    public static HashMap<String, String> SETTELMENT_TYPE = new HashMap<String, String>();
    static {
        SETTELMENT_TYPE.put("001","АУЛ");  //АУЛ      
        SETTELMENT_TYPE.put("002","А/П");  //АЭРОПОРТ 
        SETTELMENT_TYPE.put("003","Б/О");  //БАЗА ОТДЫХА           
        SETTELMENT_TYPE.put("004","БРИГАДА");  //БРИГАДА  
        SETTELMENT_TYPE.put("005","БУГОР");  //БУГОР    
        SETTELMENT_TYPE.put("006","БУХТА");  //БУХТА    
        SETTELMENT_TYPE.put("007","ВЛД");  //ВЛАДЕНИЕ 
        SETTELMENT_TYPE.put("008","ВЫСЕЛ");  //ВЫСЕЛКИ(ОК)           
        SETTELMENT_TYPE.put("009","Г");  //ГОРОД    
        SETTELMENT_TYPE.put("010","ГОРОДОК");  //ГОРОДОК  
        SETTELMENT_TYPE.put("011","ДСК");  //ДАЧНО-СТРОИТ. КООПЕРАТИВ           
        SETTELMENT_TYPE.put("012","ДП");  //ДАЧНЫЙ ПОСЕЛОК        
        SETTELMENT_TYPE.put("013","ДВОР");  //ДВОР(ИКИ)
        SETTELMENT_TYPE.put("014","ДЕПО");  //ДЕПО     
        SETTELMENT_TYPE.put("015","Д");  //ДЕРЕВНЯ  
        SETTELMENT_TYPE.put("016","ДД");  //ДЕТСКИЙ ДОМ           
        SETTELMENT_TYPE.put("017","Д/О");  //ДОМ ОТДЫХА            
        SETTELMENT_TYPE.put("018","Д/ИНТЕР");  //ДОМ-ИНТЕРНАТ (ИНТЕРНАТ)            
        SETTELMENT_TYPE.put("019","ДОР");  //ДОРОГА   
        SETTELMENT_TYPE.put("020","ЕРИК");  //ЕРИК     
        SETTELMENT_TYPE.put("021","Ж/Д-ОБП");  //Ж/Д ОБГОННЫЙ ПУНКТ    
        SETTELMENT_TYPE.put("022","Ж/Д-ОП");  //Ж/Д ОСТАНОВОЧНЫЙ ПУНКТ
        SETTELMENT_TYPE.put("023","Ж/Д-БУДКА");  //ЖЕЛЕЗНОДОРОЖНАЯ БУДКА 
        SETTELMENT_TYPE.put("024","Ж/Д-КАЗАРМ");  //ЖЕЛЕЗНОДОРОЖНАЯ КАЗАРМА            
        SETTELMENT_TYPE.put("025","Ж/Д-СТ");  //ЖЕЛЕЗНОДОРОЖНАЯ СТАНЦИЯ            
        SETTELMENT_TYPE.put("026","Ж/Д-РЗД");  //ЖЕЛЕЗНОДОРОЖНЫЙ РАЗЪЕЗД            
        SETTELMENT_TYPE.put("027","ЖТ");  //ЖИВОТНОВОДЧЕСКАЯ ТОЧКА
        SETTELMENT_TYPE.put("028","З-Д");  //ЗАВОД    
        SETTELMENT_TYPE.put("029","ЗАИМ");  //ЗАИМКА   
        SETTELMENT_TYPE.put("030","ЗАСТ");  //ЗАСТАВА  
        SETTELMENT_TYPE.put("031","П/Л");  //ПИОНЕРСКИЙ ЛАГЕРЬ     
        SETTELMENT_TYPE.put("032","ЗО");  //ЗОНА ОТДЫХА           
        SETTELMENT_TYPE.put("033","И/З");  //ИНДИВИДУАЛЬНАЯ ЗАСТРОЙКА           
        SETTELMENT_TYPE.put("034","КАНАЛ");  //КАНАЛ    
        SETTELMENT_TYPE.put("035","КАРЬЕР");  //КАРЬЕР   
        SETTELMENT_TYPE.put("036","КМ");  //КИЛОМЕТР 
        SETTELMENT_TYPE.put("037","КИШЛАК");  //КИШЛАК   
        SETTELMENT_TYPE.put("038","КЛХ");  //КОЛХОЗ   
        SETTELMENT_TYPE.put("039","КОЛЬЦО");  //КОЛЬЦО   
        SETTELMENT_TYPE.put("040","КОРДОН");  //КОРДОН   
        SETTELMENT_TYPE.put("041","КОШАРА");  //КОШАРА   
        SETTELMENT_TYPE.put("042","КРАЙ");  //КРАЙ     
        SETTELMENT_TYPE.put("043","КП");  //КУРОРТНЫЙ ПОСЕЛОК     
        SETTELMENT_TYPE.put("044","ЛЕСН-ВО");  //ЛЕСНИЧЕСТВО           
        SETTELMENT_TYPE.put("045","ЛЕСХОЗ");  //ЛЕСХОЗ   
        SETTELMENT_TYPE.put("046","ЛОГ");  //ЛОГ      
        SETTELMENT_TYPE.put("047","МАССИВ");  //МАССИВ   
        SETTELMENT_TYPE.put("048","МАЯК");  //МАЯК     
        SETTELMENT_TYPE.put("049","М");  //МЕСТЕЧКО 
        SETTELMENT_TYPE.put("050","М/С");  //МЕТЕОСТАНЦИЯ          
        SETTELMENT_TYPE.put("051","МКР");  //МИКРОРАЙОН            
        SETTELMENT_TYPE.put("052","МЫС");  //МЫС      
        SETTELMENT_TYPE.put("053","НП");  //НАСЕЛЕННЫЙ ПУНКТ      
        SETTELMENT_TYPE.put("054","ОБЩ");  //ОБЩЕЖИТИЕ
        SETTELMENT_TYPE.put("055","ОВРАГ");  //ОВРАГ    
        SETTELMENT_TYPE.put("056","ОЗЕРО");  //ОЗЕРО    
        SETTELMENT_TYPE.put("057","ОСТРОВ");  //ОСТРОВ   
        SETTELMENT_TYPE.put("058","ОТАРА");  //ОТАРА    
        SETTELMENT_TYPE.put("059","ОТД");  //ОТДЕЛЕНИЕ
        SETTELMENT_TYPE.put("060","ПАДЬ");  //ПАДЬ     
        SETTELMENT_TYPE.put("061","ПАНС");  //ПАНСИОНАТ
        SETTELMENT_TYPE.put("062","ПАРК");  //ПАРК     
        SETTELMENT_TYPE.put("063","ПЕРЕЕЗД");  //ПЕРЕЕЗД  
        SETTELMENT_TYPE.put("064","ПИКЕТ");  //ПИКЕТ    
        SETTELMENT_TYPE.put("065","РЫНОК");  //РЫНОК    
        SETTELMENT_TYPE.put("066","ПИТ");  //ПИТОМНИК 
        SETTELMENT_TYPE.put("067","П/Р");  //ПЛАНИРОВОЧНЫЙ РАЙОН   
        SETTELMENT_TYPE.put("068","ПЛАТФ");  //ПЛАТФОРМА
        SETTELMENT_TYPE.put("069","П/СВХ");  //ПЛОДООВОЩНОЙ СОВХОЗ   
        SETTELMENT_TYPE.put("070","ПХ");  //ПОДСОБНОЕ ХОЗЯЙСТВО   
        SETTELMENT_TYPE.put("071","ПОДЪЕМ");  //ПОДЪЕМ   
        SETTELMENT_TYPE.put("072","ПОЙМА");  //ПОЙМА    
        SETTELMENT_TYPE.put("073","ПОЛЕ");  //ПОЛЕ     
        SETTELMENT_TYPE.put("074","П-ОВ");  //ПОЛУОСТРОВ            
        SETTELMENT_TYPE.put("075","П/СТАНОК");  //ПОЛУСТАНОК            
        SETTELMENT_TYPE.put("076","ПОРТ");  //ПОРТ     
        SETTELMENT_TYPE.put("077","П");  //ПОСЕЛОК  
        SETTELMENT_TYPE.put("078","ПГТ");  //ПОСЕЛОК ГОРОДСКОГО ТИПА            
        SETTELMENT_TYPE.put("079","ПЗ");  //ПОСЕЛОК ЗАВОДСКОЙ     
        SETTELMENT_TYPE.put("080","П/СТ");  //ПОСЕЛОК ПРИ СТАНЦИИ   
        SETTELMENT_TYPE.put("081","ПОСТ");  //ПОСТ     
        SETTELMENT_TYPE.put("082","ПОЧИНОК");  //ПОЧИНОК  
        SETTELMENT_TYPE.put("083","П/О");  //ПОЧТОВОЕ ОТДЕЛЕНИЕ    
        SETTELMENT_TYPE.put("084","ПРИИСК");  //ПРИИСК   
        SETTELMENT_TYPE.put("085","ПРОСЕЛОК");  //ПРОСЕЛОК 
        SETTELMENT_TYPE.put("086","ПРОФ");  //ПРОФИЛАКТОРИЙ         
        SETTELMENT_TYPE.put("087","РП");  //РАБОЧИЙ ПОСЕЛОК       
        SETTELMENT_TYPE.put("088","РАЗРЕЗ");  //РАЗРЕЗ   
        SETTELMENT_TYPE.put("089","РЗД");  //РАЗЪЕЗД  
        SETTELMENT_TYPE.put("090","РЕКА");  //РЕКА     
        SETTELMENT_TYPE.put("091","РЕМБАЗА");  //РЕМОНТНАЯ БАЗА        
        SETTELMENT_TYPE.put("092","РЕЧКА");  //РЕЧКА    
        SETTELMENT_TYPE.put("093","РОВ");  //РОВ      
        SETTELMENT_TYPE.put("094","РУДНИК");  //РУДНИК   
        SETTELMENT_TYPE.put("095","САД");  //САД      
        SETTELMENT_TYPE.put("096","СДТ");  //САДОВОДЧЕСКОЕ ТОВАРИЩЕСТВО         
        SETTELMENT_TYPE.put("097","САН");  //САНАТОРИЙ
        SETTELMENT_TYPE.put("098","САН-ПРОФ");  //САНАТОРИЙ-ПРОФИЛАКТОРИЙ            
        SETTELMENT_TYPE.put("099","С");  //СЕЛО     
        SETTELMENT_TYPE.put("100","СЛ");  //СЛОБОДА  
        SETTELMENT_TYPE.put("101","СВХ");  //СОВХОЗ   
        SETTELMENT_TYPE.put("102","СООРУЖ");  //СООРУЖЕНИЕ            
        SETTELMENT_TYPE.put("103","СТ-ЦА");  //СТАНИЦА  
        SETTELMENT_TYPE.put("104","СТ");  //СТАНЦИЯ  
        SETTELMENT_TYPE.put("105","СТОРОЖКА");  //СТОРОЖКА 
        SETTELMENT_TYPE.put("106","СТР");  //СТРОЕНИЕ 
        SETTELMENT_TYPE.put("107","ТЕР");  //ТЕРРИТОРИЯ            
        SETTELMENT_TYPE.put("108","Т/Б");  //ТУРИСТИЧЕСКАЯ БАЗА    
        SETTELMENT_TYPE.put("109","У");  //УЛУС     
        SETTELMENT_TYPE.put("110","УР-ЩЕ");  //УРОЧИЩЕ  
        SETTELMENT_TYPE.put("111","УСАДЬБА");  //УСАДЬБА  
        SETTELMENT_TYPE.put("112","УЧ-К");  //УЧАСТОК  
        SETTELMENT_TYPE.put("113","УЧХОЗ");  //УЧЕБНОЕ ХОЗЯЙСТВО     
        SETTELMENT_TYPE.put("114","ФАКТОРИЯ");  //ФАКТОРИЯ 
        SETTELMENT_TYPE.put("115","ФЕРМА");  //ФЕРМА    
        SETTELMENT_TYPE.put("116","Х-ВО");  //ХОЗЯЙСТВО
        SETTELMENT_TYPE.put("117","Х");  //ХУТОР    
        SETTELMENT_TYPE.put("118","ЦУ-ПХ");  //ЦЕНТР. УСАДЬБА ПОДС. ХОЗЯЙСТВА     
        SETTELMENT_TYPE.put("119","ЦУ");  //ЦЕНТРАЛЬНАЯ УСАДЬБА   
        SETTELMENT_TYPE.put("120","ЦУ-СВХ");  //ЦЕНТРАЛЬНАЯ УСАДЬБА СОВХОЗА        
        SETTELMENT_TYPE.put("121","ЦУ-ТОО");  //ЦЕНТРАЛЬНАЯ УСАДЬБА ТОО            
        SETTELMENT_TYPE.put("122","ЦО");  //ЦЕНТРАЛЬНЫЙ ОКРУГ     
        SETTELMENT_TYPE.put("123","ШАХТА");  //ШАХТА    
        SETTELMENT_TYPE.put("124","ААЛ");  //ААЛ      
        SETTELMENT_TYPE.put("125","ВОЛОСТЬ");  //ВОЛОСТЬ  
        SETTELMENT_TYPE.put("126","Ж/Д_ПОСТ");  //ЖЕЛЕЗНОДОРОЖНЫЙ ПОСТ  
        SETTELMENT_TYPE.put("127","Ж/Д_ПЛАТФ");  //ЖЕЛЕЗНОДОРОЖНАЯ ПЛАТФОРМА          
        SETTELMENT_TYPE.put("128","КАЗАРМА");  //КАЗАРМА  
        SETTELMENT_TYPE.put("129","ПРОМЗОНА");  //ПРОМЫШЛЕННАЯ ЗОНА     
        SETTELMENT_TYPE.put("130","КВ-Л");  //КВАРТАЛ  
        SETTELMENT_TYPE.put("131","АРБАН");  //АРБАН    
        SETTELMENT_TYPE.put("441","СНТ");  //Садовое неком-е товарищество       
        SETTELMENT_TYPE.put("442","ЛПХ");  //Леспромхоз            
        SETTELMENT_TYPE.put("443","ПОГОСТ");  //Погост   
        SETTELMENT_TYPE.put("445","АВТОДОРОГА");  //Автодорога            
        SETTELMENT_TYPE.put("446","ЖИЛРАЙОН");  //Жилой район           
        SETTELMENT_TYPE.put("447","ЖИЛЗОНА");  //Жилая зона
    }

    public static HashMap<String, String> STREET_TYPE = new HashMap<String, String>();
    static {
        STREET_TYPE.put("001","АЛ");  //АЛЛЕЯ
        STREET_TYPE.put("002","АУЛ");  //АУЛ
        STREET_TYPE.put("003","А/П");  //АЭРОПОРТ
        STREET_TYPE.put("004","Б/О");  //БАЗА ОТДЫХА
        STREET_TYPE.put("005","БРИГАДА");  //БРИГАДА
        STREET_TYPE.put("006","БУГОР");  //БУГОР
        STREET_TYPE.put("007","БУДКА");  //БУДКА
        STREET_TYPE.put("008","Б-Р");  //БУЛЬВАР
        STREET_TYPE.put("009","БУХТА");  //БУХТА
        STREET_TYPE.put("010","ВАГОН");  //ВАГОН
        STREET_TYPE.put("011","ВАЛ");  //ВАЛ
        STREET_TYPE.put("012","ВЛД");  //ВЛАДЕНИЕ
        STREET_TYPE.put("013","ВЪЕЗД");  //ВЪЕЗД
        STREET_TYPE.put("014","ВЫСЕЛ");  //ВЫСЕЛКИ(ОК)
        STREET_TYPE.put("015","ГАРАЖ");  //ГАРАЖ
        STREET_TYPE.put("016","ГК");  //ГАРАЖНЫЙ КООПЕРАТИВ
        STREET_TYPE.put("017","Г");  //ГОРОД
        STREET_TYPE.put("018","ГОРОДОК");  //ГОРОДОК
        STREET_TYPE.put("019","ДСК");  //ДАЧНО-СТРОИТ. КООПЕРАТИВ
        STREET_TYPE.put("020","ДП");  //ДАЧНЫЙ ПОСЕЛОК
        STREET_TYPE.put("021","ДВОР");  //ДВОР(ИКИ)
        STREET_TYPE.put("022","ДЕПО");  //ДЕПО
        STREET_TYPE.put("023","Д/О");  //ДОМ ОТДЫХА
        STREET_TYPE.put("024","ДОР");  //ДОРОГА
        STREET_TYPE.put("025","ЕРИК");  //ЕРИК
        STREET_TYPE.put("026","ЖТ");  //ЖИВОТНОВОДЧЕСКАЯ ТОЧКА
        STREET_TYPE.put("027","З-Д");  //ЗАВОД
        STREET_TYPE.put("028","ЗАЕЗД");  //ЗАЕЗД
        STREET_TYPE.put("029","ЗАСТ");  //ЗАСТАВА
        STREET_TYPE.put("030","П/Л");  //ПИОНЕРСКИЙ ЛАГЕРЬ
        STREET_TYPE.put("031","ЗАУЛОК");  //ЗАУЛОК
        STREET_TYPE.put("032","ЗО");  //ЗОНА ОТДЫХА
        STREET_TYPE.put("033","И/З");  //ИНДИВИДУАЛЬНАЯ ЗАСТРОЙКА
        STREET_TYPE.put("034","КАЗАРМА");  //КАЗАРМА
        STREET_TYPE.put("035","КАНАЛ");  //КАНАЛ
        STREET_TYPE.put("036","КАРЬЕР");  //КАРЬЕР
        STREET_TYPE.put("037","КВ-Л");  //КВАРТАЛ
        STREET_TYPE.put("038","КМ");  //КИЛОМЕТР
        STREET_TYPE.put("039","КИШЛАК");  //КИШЛАК
        STREET_TYPE.put("040","КЛХ");  //КОЛХОЗ
        STREET_TYPE.put("041","КОЛЬЦО");  //КОЛЬЦО
        STREET_TYPE.put("042","КОРДОН");  //КОРДОН
        STREET_TYPE.put("043","КП");  //КУРОРТНЫЙ ПОСЕЛОК
        STREET_TYPE.put("044","ЛЕСХОЗ");  //ЛЕСХОЗ
        STREET_TYPE.put("045","ЛИНИЯ");  //ЛИНИЯ
        STREET_TYPE.put("046","МАССИВ");  //МАССИВ
        STREET_TYPE.put("047","М");  //МЕСТЕЧКО
        STREET_TYPE.put("048","М/С");  //МЕТЕОСТАНЦИЯ
        STREET_TYPE.put("049","МКР");  //МИКРОРАЙОН
        STREET_TYPE.put("050","МОСТ");  //МОСТ
        STREET_TYPE.put("051","МО");  //МУНИЦИПАЛЬНЫЙ ОКРУГ
        STREET_TYPE.put("052","НАБ");  //НАБЕРЕЖНАЯ
        STREET_TYPE.put("053","ОБЩ");  //ОБЩЕЖИТИЕ
        STREET_TYPE.put("054","ОВРАГ");  //ОВРАГ
        STREET_TYPE.put("055","ОСТРОВ");  //ОСТРОВ
        STREET_TYPE.put("056","ОТД");  //ОТДЕЛЕНИЕ
        STREET_TYPE.put("057","ПАНС");  //ПАНСИОНАТ
        STREET_TYPE.put("058","ПАРК");  //ПАРК
        STREET_TYPE.put("059","ПЕРЕЕЗД");  //ПЕРЕЕЗД
        STREET_TYPE.put("060","ПЕР");  //ПЕРЕУЛОК
        STREET_TYPE.put("061","ПИКЕТ");  //ПИКЕТ
        STREET_TYPE.put("062","РЫНОК");  //РЫНОК
        STREET_TYPE.put("063","ПИТ");  //ПИТОМНИК
        STREET_TYPE.put("064","П/Р");  //ПЛАНИРОВОЧНЫЙ РАЙОН
        STREET_TYPE.put("065","ПЛАТФ");  //ПЛАТФОРМА
        STREET_TYPE.put("066","ПЛ-КА");  //ПЛОЩАДКА
        STREET_TYPE.put("067","ПЛ");  //ПЛОЩАДЬ
        STREET_TYPE.put("068","ПХ");  //ПОДСОБНОЕ ХОЗЯЙСТВО
        STREET_TYPE.put("069","ПОДСТ");  //ПОДСТАНЦИЯ
        STREET_TYPE.put("070","ПОДЪЕМ");  //ПОДЪЕМ
        STREET_TYPE.put("071","ПОЛЕ");  //ПОЛЕ
        STREET_TYPE.put("072","П-ОВ");  //ПОЛУОСТРОВ
        STREET_TYPE.put("073","П/СТАНОК");  //ПОЛУСТАНОК
        STREET_TYPE.put("074","ПОРТ");  //ПОРТ
        STREET_TYPE.put("075","П");  //ПОСЕЛОК
        STREET_TYPE.put("076","П/СТ");  //ПОСЕЛОК ПРИ СТАНЦИИ
        STREET_TYPE.put("077","ПОСТ");  //ПОСТ
        STREET_TYPE.put("078","П/О");  //ПОЧТОВОЕ ОТДЕЛЕНИЕ
        STREET_TYPE.put("079","ПРИИСК");  //ПРИИСК
        STREET_TYPE.put("080","ПРОЕЗД");  //ПРОЕЗД
        STREET_TYPE.put("081","ПРОСЕК");  //ПРОСЕК
        STREET_TYPE.put("082","ПРОСЕЛОК");  //ПРОСЕЛОК
        STREET_TYPE.put("083","ПР-КТ");  //ПРОСПЕКТ
        STREET_TYPE.put("084","ПРОУЛОК");  //ПРОУЛОК
        STREET_TYPE.put("085","ПУТЬ");  //ПУТЬ
        STREET_TYPE.put("086","РП");  //РАБОЧИЙ ПОСЕЛОК
        STREET_TYPE.put("087","РЗД");  //РАЗЪЕЗД
        STREET_TYPE.put("088","РЕКА");  //РЕКА
        STREET_TYPE.put("089","РЕМБАЗА");  //РЕМОНТНАЯ БАЗА
        STREET_TYPE.put("090","РЕЧКА");  //РЕЧКА
        STREET_TYPE.put("091","РОВ");  //РОВ
        STREET_TYPE.put("092","РЯД");  //РЯД
        STREET_TYPE.put("093","САД");  //САД
        STREET_TYPE.put("094","СДТ");  //САДОВОДЧЕСКОЕ ТОВАРИЩЕСТВО
        STREET_TYPE.put("095","СКВЕР");  //СКВЕР
        STREET_TYPE.put("096","СООРУЖ");  //СООРУЖЕНИЕ
        STREET_TYPE.put("097","СПУСК");  //СПУСК
        STREET_TYPE.put("098","СТАДИОН");  //СТАДИОН
        STREET_TYPE.put("099","СТ");  //СТАНЦИЯ
        STREET_TYPE.put("100","СЪЕЗД");  //СЪЕЗД
        STREET_TYPE.put("101","ТЕР");  //ТЕРРИТОРИЯ
        STREET_TYPE.put("102","РЯДЫ");  //ТОРГОВЫЕ РЯДЫ
        STREET_TYPE.put("103","ТРАКТ");  //ТРАКТ
        STREET_TYPE.put("104","ТУП");  //ТУПИК
        STREET_TYPE.put("105","Т/Б");  //ТУРИСТИЧЕСКАЯ БАЗА
        STREET_TYPE.put("106","УЛ");  //УЛИЦА
        STREET_TYPE.put("107","УСАДЬБА");  //УСАДЬБА
        STREET_TYPE.put("108","УЧ-К");  //УЧАСТОК
        STREET_TYPE.put("109","УЧХОЗ");  //УЧЕБНОЕ ХОЗЯЙСТВО
        STREET_TYPE.put("110","ФАКТОРИЯ");  //ФАКТОРИЯ
        STREET_TYPE.put("111","Х");  //ХУТОР
        STREET_TYPE.put("112","ЦУ-ПХ");  //ЦЕНТР. УСАДЬБА ПОДС. ХОЗЯЙСТВА
        STREET_TYPE.put("113","ЦУ");  //ЦЕНТРАЛЬНАЯ УСАДЬБА
        STREET_TYPE.put("114","ЦУ-СВХ");  //ЦЕНТРАЛЬНАЯ УСАДЬБА СОВХОЗА
        STREET_TYPE.put("115","ЦУ-ТОО");  //ЦЕНТРАЛЬНАЯ УСАДЬБА ТОО
        STREET_TYPE.put("116","Ш");  //ШОССЕ
        STREET_TYPE.put("117","ААЛ");  //ААЛ
        STREET_TYPE.put("118","Д");  //ДЕРЕВНЯ
        STREET_TYPE.put("119","Ж/Д_БУДКА");  //ЖЕЛЕЗНОДОРОЖНАЯ БУДКА
        STREET_TYPE.put("120","Ж/Д_КАЗАРМ");  //ЖЕЛЕЗНОДОРОЖНАЯ КАЗАРМА
        STREET_TYPE.put("121","Ж/Д_ОП");  //Ж/Д ОСТАНОВ. (ОБГОННЫЙ) ПУНКТ
        STREET_TYPE.put("122","Ж/Д_ПОСТ");  //ЖЕЛЕЗНОДОРОЖНЫЙ ПОСТ
        STREET_TYPE.put("123","Ж/Д_РЗД");  //ЖЕЛЕЗНОДОРОЖНЫЙ РАЗЪЕЗД
        STREET_TYPE.put("124","Ж/Д_СТ");  //ЖЕЛЕЗНОДОРОЖНАЯ СТАНЦИЯ
        STREET_TYPE.put("125","НП");  //НАСЕЛЕННЫЙ ПУНКТ
        STREET_TYPE.put("126","ПОЧИНОК");  //ПОЧИНОК
        STREET_TYPE.put("127","С");  //СЕЛО
        STREET_TYPE.put("128","СТР");  //СТРОЕНИЕ
        STREET_TYPE.put("129","АРБАН");  //АРБАН
        STREET_TYPE.put("130","АЛЛЕЯ");  //Аллея
        STREET_TYPE.put("131","ДНП");  //Дачное неком-е партнерство
        STREET_TYPE.put("132","Н/П");  //Некоммерческое партнерство
        STREET_TYPE.put("133","Ф/Х");  //Фермерское хозяйство
        STREET_TYPE.put("134","МЕСТНОСТЬ");  //Местность
        STREET_TYPE.put("135","БАЛКА");  //БАЛКА
        STREET_TYPE.put("136","ПРИЧАЛ");  //ПРИЧАЛ
        STREET_TYPE.put("137","МЫС");  //МЫС
        STREET_TYPE.put("138","МАЯК");  //МАЯК
        STREET_TYPE.put("139","ГОРКА");  //ГОРКА
        STREET_TYPE.put("140","ТОННЕЛЬ");  //ТОННЕЛЬ
        STREET_TYPE.put("552","ПОЛУСТАНОК");  //Полустанок
        STREET_TYPE.put("556","СЛ");  //Слобода
        STREET_TYPE.put("559","Ж/Д_ПЛАТФ");  //Железнодорожная платформа
        STREET_TYPE.put("563","ГСК");  //Гаражно-строительный кооперат
        STREET_TYPE.put("564","СНТ");  //Садовое неком-е товарищество
        STREET_TYPE.put("565","ЛПХ");  //Леспромхоз
        STREET_TYPE.put("566","ПРОТОК");  //Проток
        STREET_TYPE.put("567","КОСА");  //Коса
        STREET_TYPE.put("572","А/Я");  //Абонентский ящик
        STREET_TYPE.put("573","БЕРЕГ");  //Берег
        STREET_TYPE.put("574","ПРОСЕКА");  //Просека
        STREET_TYPE.put("575","ПРОТОКА");  //Протока
        STREET_TYPE.put("577","ЗОНА");  //Зона

    }



    public static HashMap<String, String> REGIONS = new HashMap<String, String>();
    static {
        REGIONS.put("1","Республика Адыгея");
        REGIONS.put("4","Республика Алтай");
        REGIONS.put("2","Республика Башкортостан");
        REGIONS.put("3","Республика Бурятия");
        REGIONS.put("5","Республика Дагестан");
        REGIONS.put("6","Республика Ингушетия");
        REGIONS.put("7","Кабардино-Балкарская республика");
        REGIONS.put("8","Республика Калмыкия");
        REGIONS.put("9","Карачаево-Черкесская республика");
        REGIONS.put("10","Республика Карелия");
        REGIONS.put("11","Республика Коми");
        REGIONS.put("91","Республика Крым");
        REGIONS.put("12","Республика Марий Эл");
        REGIONS.put("13","Республика Мордовия");
        REGIONS.put("14","Республика Саха (Якутия)");
        REGIONS.put("15","Республика Северная Осетия — Алания");
        REGIONS.put("16","Республика Татарстан");
        REGIONS.put("17","Республика Тыва");
        REGIONS.put("18","Удмуртская республика");
        REGIONS.put("19","Республика Хакасия");
        REGIONS.put("20","Чеченская республика");
        REGIONS.put("21","Чувашская республика");
        REGIONS.put("22","Алтайский край");
        REGIONS.put("75","Забайкальский край");
        REGIONS.put("41","Камчатский край");
        REGIONS.put("23","Краснодарский край");
        REGIONS.put("24","Красноярский край");
        REGIONS.put("59","Пермский край");
        REGIONS.put("25","Приморский край");
        REGIONS.put("26","Ставропольский край");
        REGIONS.put("27","Хабаровский край");
        REGIONS.put("28","Амурская область");
        REGIONS.put("29","Архангельская область");
        REGIONS.put("30","Астраханская область");
        REGIONS.put("31","Белгородская область");
        REGIONS.put("32","Брянская область");
        REGIONS.put("33","Владимирская область");
        REGIONS.put("34","Волгоградская область");
        REGIONS.put("35","Вологодская область");
        REGIONS.put("36","Воронежская область");
        REGIONS.put("37","Ивановская область");
        REGIONS.put("38","Иркутская область");
        REGIONS.put("39","Калининградская область");
        REGIONS.put("40","Калужская область");
        REGIONS.put("42","Кемеровская область");
        REGIONS.put("43","Кировская область");
        REGIONS.put("44","Костромская область");
        REGIONS.put("45","Курганская область");
        REGIONS.put("46","Курская область");
        REGIONS.put("47","Ленинградская область");
        REGIONS.put("48","Липецкая область");
        REGIONS.put("49","Магаданская область");
        REGIONS.put("50","Московская область");
        REGIONS.put("51","Мурманская область");
        REGIONS.put("52","Нижегородская область");
        REGIONS.put("53","Новгородская область");
        REGIONS.put("54","Новосибирская область");
        REGIONS.put("55","Омская область");
        REGIONS.put("56","Оренбургская область");
        REGIONS.put("57","Орловская область");
        REGIONS.put("58","Пензенская область");
        REGIONS.put("60","Псковская область");
        REGIONS.put("61","Ростовская область");
        REGIONS.put("62","Рязанская область");
        REGIONS.put("63","Самарская область");
        REGIONS.put("64","Саратовская область");
        REGIONS.put("65","Сахалинская область");
        REGIONS.put("66","Свердловская область");
        REGIONS.put("67","Смоленская область");
        REGIONS.put("68","Тамбовская область");
        REGIONS.put("69","Тверская область");
        REGIONS.put("70","Томская область");
        REGIONS.put("71","Тульская область");
        REGIONS.put("72","Тюменская область");
        REGIONS.put("73","Ульяновская область");
        REGIONS.put("74","Челябинская область");
        REGIONS.put("76","Ярославская область");
        REGIONS.put("77","Москва");
        REGIONS.put("78","Санкт-Петербург");
        REGIONS.put("92","Севастополь");
        REGIONS.put("79","Еврейская автономная область");
        REGIONS.put("83","Ненецкий автономный округ");
        REGIONS.put("86","Ханты-Мансийский автономный округ - Югра");
        REGIONS.put("87","Чукотский автономный округ");
        REGIONS.put("89","Ямало-Ненецкий автономный округ");
    }

    public static boolean isId(String id) {
        if (id == null) return false;
        return ((id.matches("[0-9]+") && id.length() > 0));
    }

    public static PdfFile readPdfFile(String fileName) throws RuntimeException {
        byte[] b = readFile(fileName);
        PdfFile pdf = new PdfFile("", b, fileName);
        return pdf;
    }

    public static byte[] readFile(String fileName) {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream(fileName);
        byte[] b;
        try {
            b = IOUtils.toByteArray(is);
        } catch (IOException e) {
            throw new RuntimeException("error read reources fileName = " + fileName, e);
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                throw new RuntimeException("error close reources file fileName = " + fileName, e);
            }
        }
        return b;
    }

    public static boolean emailTest(String email) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(email);
        return matcher.find();
    }
}
