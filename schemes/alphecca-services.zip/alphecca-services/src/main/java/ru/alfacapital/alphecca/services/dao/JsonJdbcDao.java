package ru.alfacapital.alphecca.services.dao;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Repository
public class JsonJdbcDao {

    private static final Logger log = LoggerFactory.getLogger(JsonJdbcDao.class);

    private NamedParameterJdbcTemplate jdbc;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        jdbc = new NamedParameterJdbcTemplate(dataSource);
    }

    /**
     * Универсальный вызов для изменения данных.<br/>
     * <br/>
     * Примеры:<br/>
     * { request: { param1: "", param2: 0 }, response: {errorCode:{0|1}, rows:"количество строк которые изменил запрос"}}<br/>
     *
     * @param sql SQL-запрос
     * @param params параметры SQL-запроса
     * @return JSONObject
     */
    public JSONObject queryModify(String sql, Map<String, Object> params) {
        JSONObject json = new JSONObject();
        json.put("request", new JSONObject(params));
        JSONObject response = new JSONObject();
        json.put("response", response);
        log.trace("SQL: {}", sql);
        try {
            int rows = jdbc.update(sql, params);
            log.trace("Query complete");
            response.put("errorCode", 0);
            response.put("rows", rows);
        }
        catch (DataAccessException ex) {
            log.error("DataAccessException: {}", ex.getMessage());
            response.put("errorCode", 1);
            response.put("errorMessage", "Ошибка при выполненнии запроса");
        }
        return json;
    }

    /**
     * Универсальный вызов для превращения результатов запроса в JSON.<br/>
     * <br/>
     * Примеры:<br/>
     * { request: { param1: "", param2: 0 },
     * response: [{ column1: "", column2: 0 }, ... ]}<br/>
     * или
     * response: [[ , ], ... ]}<br/>
     *
     * @param sql SQL-запрос
     * @param params параметры SQL-запроса
     * @return JSONObject
     */
    public JSONObject queryForArray(String sql, Map<String, Object> params, boolean blobAsBase64, boolean asObject) {
        JSONObject json = new JSONObject();
        json.put("request", new JSONObject(params));
        json.put("response", convertToJSONArray(sql, params, blobAsBase64, asObject));
        return json;
    }

    public JSONObject queryForArray(String sql, Map<String, Object> params, boolean blobAsBase64) {
        return queryForArray(sql, params, blobAsBase64, true);
    }

    public JSONObject queryForArray(String sql, Map<String, Object> params) {
        return queryForArray(sql, params, true);
    }

    /**
     * SQL должен иметь 2 столбца - dq и val.
     * Запрос обязан возвращать отсортированный непрерывный набор измерений.
     * Ведущие нули отрезаются.
     *
     * <br/>
     * Результат:<br/>
     * { start: DQ, continuous: [val1, val2, ...]}<br/>
     *
     * @param sql SQL-запрос
     * @param params параметры SQL-запроса
     * @return JSONObject
     */
    public JSONObject queryForContinuous(String sql, Map<String, Object> params) {
        JSONObject json = new JSONObject();
        final Integer[] start = { null };
        final JSONArray cont = new JSONArray();
        jdbc.query(sql, params, new RowCallbackHandler() {
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                int dq = rs.getInt("dq");
                BigDecimal val = rs.getBigDecimal("val");
                if (start[0] == null) {
                    if (val.compareTo(BigDecimal.ZERO) != 0) {
                        start[0] = dq;
                        cont.put(val);
                    }
                }
                else {
                    cont.put(val);
                }
            }
        });
        json.put("start", start[0]);
        json.put("continuous", cont);
        return json;
    }

    public JSONArray convertToJSONArray(String sql, Map<String, Object> params, final boolean blobAsBase64, final boolean asObject) {
        log.trace("SQL: {}", sql);
        final JSONArray jsonArray = new JSONArray();
        try {

            jdbc.query(sql, params, new RowCallbackHandler() {
                @Override
                public void processRow(ResultSet rs) throws SQLException {
                    jsonArray.put(asObject ? getJsonObject(rs, blobAsBase64) : getJsonArray(rs, blobAsBase64));
                }
            });
            log.trace("Query complete. {} rows fetched", jsonArray.length());
        }
        catch (DataAccessException ex) {
            log.error("DataAccessException: {}", ex.getMessage());
        }
        return jsonArray;
    }

    private JSONObject getJsonObject(ResultSet rs, boolean blobAsBase64) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columns = rsmd.getColumnCount();
        JSONObject obj = new JSONObject();
        for (int i = 1; i <= columns; i++) {
            obj.put(rsmd.getColumnLabel(i).toLowerCase(), getRow(rs, blobAsBase64, rsmd, i));
        }
        return obj;
    }

    private JSONArray getJsonArray(ResultSet rs, boolean blobAsBase64) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columns = rsmd.getColumnCount();
        JSONArray obj = new JSONArray();
        for (int i = 1; i <= columns; i++) {
            obj.put(getRow(rs, blobAsBase64, rsmd, i));
        }
        return obj;
    }

    private Object getRow(ResultSet rs, boolean blobAsBase64, ResultSetMetaData rsmd, int i) throws SQLException {
        Object o;
        if (rsmd.getColumnType(i) == Types.CLOB) {
            Clob clob = rs.getClob(i);
            o = clobToString(clob);
            if (clob != null) {
                clob.free();
            }
        } else if (rsmd.getColumnType(i) == Types.BLOB) {
            Blob blob = rs.getBlob(i);
            if (blobAsBase64) {
                o = blobToString(blob);
            }
            else {
                o = blobToBytes(blob);
            }
            if (blob != null) {
                blob.free();
            }
        } else {
            o = rs.getObject(i);
        }
        return o;
    }

    private static String clobToString(Clob value) throws SQLException {
        return value == null ? null : value.getSubString(1, (int) value.length());
    }

    private static String blobToString(Blob value) throws SQLException {
        return value == null ? null : Base64.getEncoder().encodeToString(value.getBytes(1, (int) value.length()));
    }

    private static byte[] blobToBytes(Blob value) throws SQLException {
        return value == null ? new byte[0] : value.getBytes(1, (int) value.length());
    }

    public String getLoginIdByInvestorId(String investorId) {
        if (StringUtils.isEmpty(investorId)) {
            return null;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("id", investorId);
        return jdbc.queryForObject("select login_id from ss.vie_ss_investor where investor_id = :id", params, String.class);
    }

    // старый код который подставлял левый номер для смс
    /*public String getPhoneByInvestorId(String investorId) {
        boolean isTest = System.getProperty("ss.deployment.profile").contains("test");
        String magicPhoneNumber = System.getProperty("alphecca.magicPhoneNumber");
        if ( isTest && StringUtils.hasText(magicPhoneNumber)) {
            return  magicPhoneNumber;
        } else {
            Map<String, Object> params = new HashMap<>();
            params.put("id", investorId);
            return jdbc.queryForObject("select investor_cell_phone from ss.vie_ss_investor where investor_id = :id", params, String.class);
        }
    }*/

    public String getPhoneByInvestorId(String investorId) {

        if (StringUtils.isEmpty(investorId)) {
            return null;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("id", investorId);
        return jdbc.queryForObject("select investor_cell_phone from ss.vie_ss_investor where investor_id = :id", params, String.class);
    }

    public String getLoginByInvestorId(String investorId) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", investorId);
        return jdbc.queryForObject("select login from ss.vie_ss_investor where investor_id = :id", params, String.class);
    }

    @Transactional
    public void setPassword(String loginId, String passHash) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", loginId);
        params.put("pass", passHash);
        jdbc.update("update ss.tab_login set passhash = :pass where login_id = :id", params);
    }

    @Transactional
    public void setBlockDate(String loginId, Timestamp time) {
        Map<String, Object> params = new HashMap<>();
        params.put("id", loginId);
        params.put("time", time);
        jdbc.update("update ss.tab_login set block_date = :time where login_id = :id", params);
    }

    @Transactional
    public void registerClient(String investorId) {
        String login = jdbc.queryForObject("select ss.login_sequence.nextval login from sys.dual", new HashMap<String, Object>(), String.class);
        String sql = "insert into ss.tab_login (login_id, login_type, login, creation_date, password_change_date, block_date, investor_id, passhash) " +
                "values (ss.hibernate_sequence.nextval, 'INVESTOR', :login, sysdate, sysdate + 10000, sysdate + 10000, :id, 'Unbelivable')";
        Map<String, Object> params = new HashMap<>();
        params.put("id", investorId);
        params.put("login", login);
        jdbc.update(sql, params);

        params = new HashMap<>();
        String msql = "insert into ss.tab_mail_box_entry (mail_box_entry_id, login_id, information_message_id, message_type, new_message) values" +
                "(ss.hibernate_sequence.nextval, :id, 170123, 0, 1)";
        params.put("id", getLoginIdByInvestorId(investorId));
        jdbc.update(msql, params);
    }

}
