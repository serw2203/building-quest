package ru.alfacapital.alphecca.services.legacy;

import org.apache.commons.lang.StringUtils;

/**
 * Created by Y.Bocharov on 20.05.2015.
 */
public class ProjectProperty {

/**
 *
 * M - magic number/email
 *
 *
 *              SMS     RULE    BUY_SIGNED      BUY_OPEN
 * mobile       X       X       X               -
 * aclick       X       X       X               -
 * employee     -       -       -               -
 * client       X       X       X               -
 *
 * test
 * employee     -       -       -               -
 * client       M       X       -               M
  */

    public final static String prop = System.getProperty("alphecca.deployment.profile");
    //public final static String prop = "test";


    /**
     *
     * разрешить подменять номер телефона для отсылки СМС
     *
     * @return
     */
    public static boolean allowMasterSms() {
        if (prop.contains("test")) {
            return true;
        }
        return false;
    }

    /**
     * разрешить отправлять запрос к ДУ на покупку
     * если действие не разрешено то будет брошена ошибка
     * @return
     */
    public static boolean buyAccept() {
        return buyAndOpen() || buyAndSign();
    }

    /**
     * при покупке оставлять заявку/договор в статусе начальный ввод
     * только в тесте
      * @return
     */
    public static boolean buyAndOpen() {
        if (prop.contains("test")) {
            return true;
        }
        return false;
    }

    /**
     * при покупке переводить зявку/договор в статус подписана
     * только в бою
     * @return
     */
    public static boolean buyAndSign() {
        if (prop.contains("test")) {
            return false;
        }
        if (prop.contains("client") ||
            prop.contains("aclick"))
        {
            return true;
        }
        return false;
    }

    /**
     * при запросе правил возвращаем значение из базы или заглушку о том что правила приняты
     * в тесте правила показывать ненужно
     * @return
     */
    public static boolean showRule() {
        if (prop.contains("test") ||
            prop.contains("employee"))
        {
            return false;
        }
        return true;
    }

    /**
     * отправлять СМС на реальный номер или на "волшебный" (в зависимости от sendMagicSms)
     * @return
     */
    public static boolean sendSms() {
        if (prop.contains("test") ||
            prop.contains("client") ||
            prop.contains("aclick"))
        {
            return true;
        }
        return false;
    }

    public static boolean sendConsulNotification() {
        if (prop.contains("client"))
        {
            return true;
        }
        return false;
    }

    /**
     * отправлять СМС на волшебный номер?
     * @return
     */
    public static boolean sendMagicSms() {
        if (prop.contains("test")) {
            return true;
        }
        return false;
    }

    /**
     * возвращает подмену номера телефона для отправки смс
     * @return
     */
    public static String getMagicPhoneNumber() {
        if (prop.contains("test")) {
            return System.getProperty("alphecca.magicPhoneNumber");
        }
        return "";
    }

    /**
     * подмена email для отправки почты
     * @return
     */
    public static boolean sendMagicEmail() {
        if (prop.contains("test")) {
            return true;
        }
        return false;
    }

    /**
     * возвращает адрес почты для подмены
     * @return
     */
    public static String getMagicEmail() {
        String email = System.getProperty("alphecca.magicEmail");
        if (StringUtils.isEmpty(email)) {
            return "dev@alfacapital.ru";
        } else {
            return email;
        }
    }


    /**
     * проверять ли СМС при логине
     * @return
     */
    public static boolean checkWelcomeSms() {
        if (prop.contains("client"))
        {
            return true;
        }
        return false;
    }

}
