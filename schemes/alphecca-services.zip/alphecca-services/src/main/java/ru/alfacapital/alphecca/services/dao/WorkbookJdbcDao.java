package ru.alfacapital.alphecca.services.dao;


import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Map;

@Repository
public class WorkbookJdbcDao {

    private static final Logger log = LoggerFactory.getLogger(WorkbookJdbcDao.class);

    private NamedParameterJdbcTemplate jdbc;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        jdbc = new NamedParameterJdbcTemplate(dataSource);
    }

    public byte[] queryForWorkbook(String sql, Map<String, Object> params, byte[] template) {

        Workbook wb;
        ByteArrayInputStream bsTemplate = new ByteArrayInputStream(template);
        try {
            wb = new HSSFWorkbook(new POIFSFileSystem(bsTemplate), true);
        } catch (IOException e) {
            log.error("Error open excel file {}", e.toString());
            return new byte[0];
        }
        fillWorkbook(wb, sql, params);
        ByteArrayOutputStream bsResult = new ByteArrayOutputStream();
        try {
            wb.write(bsResult);
        } catch (IOException e) {
            log.error("Error during generate excel file {}", e.toString());
            return new byte[0];
        }
        return bsResult.toByteArray();
    }

    private void fillWorkbook(final Workbook wb, String sql, Map<String, Object> params) {
        try {
            jdbc.query(sql, params, new RowCallbackHandler() {
                @Override
                public void processRow(ResultSet rs) throws SQLException {
                    ResultSetMetaData resultSetMetaData = rs.getMetaData();
                    do {
                        int latRowNum = wb.getSheetAt(0).getLastRowNum();
                        Row row = wb.getSheetAt(wb.getActiveSheetIndex()).createRow(latRowNum + 1);
                        for (int i = 0; i < resultSetMetaData.getColumnCount(); i++) {
                            Cell cell = row.createCell(i);
                            switch (resultSetMetaData.getColumnType(i + 1)) {
                                case Types.NUMERIC:
                                case Types.DOUBLE:
                                case Types.FLOAT:
                                case Types.INTEGER:
                                case Types.REAL:
                                    cell.setCellValue(rs.getDouble(i + 1));
                                    break;
                                case Types.DATE:
                                    cell.setCellValue(rs.getDate(i + 1));
                                    break;
                                default:
                                    cell.setCellValue(rs.getString(i + 1));
                            }
                        }
                    } while (rs.next());

                }
            });
        }
        catch (DataAccessException ex) {
            log.error("DataAccessException: {}", ex.getMessage());
        }
    }

}
