package ru.alfacapital.alphecca.services.rest;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.dao.PasswordDao;
import ru.alfacapital.alphecca.services.legacy.utils.HashUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * 10.12.2014
 *
 * @author y.bocharov
 */

@Controller
public class PasswordController extends GenericController {

    @Autowired
    private PasswordDao dao;

    private static final Logger log = LoggerFactory.getLogger(PasswordController.class);

    public final static String ATTR_COUNT_ATTEMPT_CHANGE_PASSWORD = "ATTR_COUNT_ATTEMPT_CHANGE_PASSWORD";
    public final static Integer MAX_COUNT_ATTEMPT = 3;


    @RequestMapping(value = "/investor/settings/passwordchange")
    public ResponseEntity<String> changePassword(HttpServletRequest request,
                                                 @RequestParam(value = "investorId", required = false)  String investorId,
                                                 @RequestParam(value = "oldPassword", required = false) String oldPassword,
                                                 @RequestParam(value = "newPassword", required = false) String newPassword,
                                                 @RequestParam(value = "repeatPassword", required = false) String repeatPassword) {


        JSONObject json = new JSONObject();
        JSONObject requestJson = new JSONObject();
        requestJson.put("investorId", investorId);
        JSONObject responseJson = new JSONObject();
        json.put("request", requestJson);
        json.put("response", responseJson);
        Object countAttempt = request.getSession(false).getAttribute(ATTR_COUNT_ATTEMPT_CHANGE_PASSWORD);
        if (countAttempt == null) {
            countAttempt = 0;
        }
        log.trace("Attempt {} change password. login {}, investor {}",countAttempt, request.getUserPrincipal().getName(), investorId);
        if ((Integer) countAttempt > MAX_COUNT_ATTEMPT) {
            responseJson.put("errorCode", 1);
            responseJson.put("errorMessage", "Зафиксированы 3 неудачные попытки. Изменить пароль можно будет после повторного входа в систему.");
            log.info("too many attempts to change the password. login {}, investor", request.getUserPrincipal().getName(), investorId);
        }
        else {
            investorId = checkRights(request, investorId);
            try {
                if (changePassword(investorId, oldPassword, newPassword, repeatPassword)) {
                    responseJson.put("errorCode", 0);
                } else {
                    responseJson.put("errorCode", 1);
                    responseJson.put("errorMessage", "Ошибка изменения пароля");
                    log.trace("Internal error during change password");
                }
            } catch (RuntimeException ex) {
                request.getSession(false).setAttribute(ATTR_COUNT_ATTEMPT_CHANGE_PASSWORD,((Integer)countAttempt + 1));
                responseJson.put("errorCode", 1);
                responseJson.put("errorMessage", ex.getMessage());
                log.trace("Error change password {}", ex.getMessage());
            }
        }
        return new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK);
    }

    /**
     * Смена пароля пользователю личного кабинета.
     *
     * @param investorId логин
     * @param oldPasswordValue старый пароль
     * @param newPasswordValue новый пароль
     * @param repeatPasswordValue новый пароль второй раз
     * @return результат смены
     */
    @Transactional( readOnly = false )
    private boolean changePassword(String investorId, String oldPasswordValue, String newPasswordValue, String repeatPasswordValue) {
        if (oldPasswordValue == null || newPasswordValue == null || repeatPasswordValue == null || newPasswordValue.isEmpty()) throw new RuntimeException("Пароль не может быть пустым");
        if (newPasswordValue.contains(" ")) throw new RuntimeException("Пароль не может содержать пробелов");
        if (newPasswordValue.length() < 8) throw new RuntimeException("Пароль не может быть короче 8 символов");
        if (isDigitsOnly(newPasswordValue)) throw new RuntimeException("Пароль не может содержать только цифры");
        if (!newPasswordValue.equals(repeatPasswordValue)) throw new RuntimeException("Пароли не совпадают");
        if (newPasswordValue.trim().equals(oldPasswordValue.trim())) throw new RuntimeException("Новый пароль должен отличаться от прежнего");
        // проверка старого пароля
        if (!dao.getPassword(investorId).trim().equals(HashUtils.hashPassword(oldPasswordValue.trim()))) throw new RuntimeException("Неверный старый пароль");
        return dao.modifyPassword(investorId, HashUtils.hashPassword(oldPasswordValue.trim()), HashUtils.hashPassword(newPasswordValue.trim()), new Date());
    }

    private static boolean isDigitsOnly(String str) {
        for(int i = 0; i < str.length(); ++i) {
            char ch = str.charAt(i);
            if(ch < 48 || ch > 57) {
                return false;
            }
        }
        return true;
    }


}
