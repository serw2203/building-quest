package ru.alfacapital.alphecca.services.legacy.reports.model;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * Позиция.
 * Любой из перечисленных видов позиций: Позиция по одному инструменту, позиция по одной сделке, позиция НКД отдельно, DMT-позиция, и т.д.
 */
public class PrimitivePosition {

    /**
     * Валюта позиции.
     */
    public String valuationCurrency;

    /**
     * Класс инструмента.
     */
    public String assetClass;

    /**
     * Наименование позиции.
     */
    public String positionName;

    /**
     * Идентификатор инструмента
     */
    public String assetId;

    /**
     * ISIN
     */
    public String isin;

    /**
     * Идентификатор DMT.
     */
    public String dmtId;

    /**
     * Дата погашения.
     */
    public Date maturityDate;

    /**
     * Валюта учёта.
     */
    public String accountingCurrency;

    /**
     * Размер позиции.
     */
    public BigDecimal positionSize;

    /**
     * Объём позиции в валюте позиции.
     */
    public BigDecimal positionValue;

    /**
     * Объём позиции в рублях.
     */
    public BigDecimal positionValueRub;

    /**
     * НКД в валюте позиции.
     */
    public BigDecimal sciValue;

    /**
     * НКД в рублях.
     */
    public BigDecimal sciValueRub;

    /**
     * Стоимость покупки.
     */
    public BigDecimal buyValue;

    /**
     * Размер депозита в рублях (для DMT-позиций).
     */
    public BigDecimal depositValueRub;

    /**
     * Размер займа в рублях (для DMT-позиций).
     */
    public BigDecimal debtValueRub;

    /**
     * Размер актива позиции в рублях (для DMT-позиций).
     */
    public BigDecimal bodyValueRub;

    /**
     * Признак того, что это позиция по ЦБ.
     */
    public boolean isSecurity;

    /**
     * Признак того, что это позиция - чистое НКД.
     */
    public boolean isSCI;

}
