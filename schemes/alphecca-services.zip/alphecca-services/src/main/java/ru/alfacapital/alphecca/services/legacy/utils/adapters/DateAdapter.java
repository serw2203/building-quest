package ru.alfacapital.alphecca.services.legacy.utils.adapters;


import ru.alfacapital.alphecca.services.legacy.utils.XMLUtils;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.util.Date;

public class DateAdapter extends XmlAdapter<String, Date> {

    @Override
    public Date unmarshal(String v) throws Exception {
        // Пока не реализовано, и не понадобиться если использовать этот адаптер только для отчетов
        return null;
    }

    @Override
    public String marshal(Date v) throws Exception {
        if (v == null) {
            return null;
        } else {
            return XMLUtils.xmlFormatDate(v);
        }
    }
}
