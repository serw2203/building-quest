package ru.alfacapital.alphecca.services.rest

import org.json.JSONArray
import org.json.JSONObject
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.servlet.HandlerMapping
import ru.alfacapital.alphecca.services.dao.JsonJdbcDao
import ru.alfacapital.alphecca.services.dao.WorkbookJdbcDao
import ru.alfacapital.alphecca.services.legacy.SmsService
import ru.alfacapital.alphecca.services.legacy.utils.HashUtils
import ru.alfacapital.alphecca.services.legacy.utils.JasperUtils

import javax.servlet.ServletContext
import javax.servlet.http.HttpServletRequest
import java.security.SecureRandom
import java.sql.Timestamp
import java.text.SimpleDateFormat

@Controller
public class DefaultController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(DefaultController.class);

    private SecureRandom random = new SecureRandom(("Fuck you all дважды, ребятки " + System.currentTimeMillis()).getBytes());

    static BASE_DIR = "/WEB-INF/rest-sql/"

    @Autowired
    private JsonJdbcDao dao;

    @Autowired
    private WorkbookJdbcDao excelDao;

    @Autowired
    private SmsService sms;

    @RequestMapping([
            "/investor/portfolio/type/{type}/id/{id}"
    ])
    public ResponseEntity<byte[]> main(HttpServletRequest request,
                                       @PathVariable(value = "type") String type,
                                       @PathVariable(value = "id") String id,
                                       @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId))
        JSONObject json = new JSONObject()
        JSONObject response = new JSONObject()
        json.put("request", params)
        JSONObject aums;
        JSONArray flow;
        if ("MF".equals(type)) {
            String sql = getResource("/investor/main/aum-fund", request.getServletContext(), params, ".sql")
            aums = dao.queryForContinuous(sql, params)
            sql = getResource("/investor/main/flow-fund", request.getServletContext(), params, ".sql")
            flow = dao.convertToJSONArray(sql, params, false, false)
        } else if ("PE".equals(type)) {
            aums = new JSONObject()
            flow = new JSONArray()
        } else {
            String sql = getResource("/investor/main/aum-contract", request.getServletContext(), params, ".sql")
            aums = dao.queryForContinuous(sql, params)
            sql = getResource("/investor/main/flow-contract", request.getServletContext(), params, ".sql")
            flow = dao.convertToJSONArray(sql, params, false, false)
        }
        response.put("aums", aums)
        response.put("flow", flow)
        json.put("response", response)
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    @RequestMapping ([
            "/news/latest",
            "/ad/best/startDate/{startDate}/stopDate/{stopDate}/currency/{currency}",
            "/ad/bestAk/startDate/{startDate}/stopDate/{stopDate}/currency/{currency}",
            "/ad/all",
            "/currency/all",
            "/currency/rate/currency/{currency}/dateDQ/{dateDQ}",
            "/bank/info/{bic}",
            "/asset-class/all",
            "/country/all",
            "/industry/all",
            "/territory/all",
            "/product/all",
            "/product/info/productId/{productId}",
            "/product/benchmark/productId/{productId}/startDateDQ/{startDateDQ}",
            "/fund/info/fundId/{fundId}",
            "/fund/infoAll",
            "/fund/swapAll",
            "/mservice/manager/{param}"
    ])
    public ResponseEntity<String> json(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        //params.put("investorId", checkRights(request, investorId));
        String sql = getResource(request, params, ".sql");
        defaultResponse(sql, params)
    }



    @RequestMapping ([
            "/investor/manager",
            "/investor/status",
            "/investor/portfolios",
            "/investor/portfoliosAk",
            "/investor/portfoliosEd",
            "/investor/summary",
            "/investor/details",
            "/investor/exposed/dateDQ/{dateDQ}",
            "/investor/operations/am",
            "/investor/operations/fund",
            "/investor/operations/accounts",
            "/investor/reports",
            "/investor/actions/funds/rebuylist",
            "/investor/messages/all",
            "/investor/messages/one/id/{id}",
            "/investor/settings/currentcurrency",
            "/alfaprofit/pool/contractId/{contractId}",
            "/portfolio/info/contractId/{contractId}",
            "/admin/clients/one"
    ])
    public ResponseEntity<String> jsonRequireLoginAndSms(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        String sql = getResource(request, params, ".sql");
        defaultResponse(sql, params)
    }

    @RequestMapping([
            "/currency/rates/currency/{currency}/minDateDQ/{minDateDQ}/maxDateDQ/{maxDateDQ}"
    ])
    public ResponseEntity<String> jsonArray(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        String sql = getResource(request, params, ".sql");
        defaultResponse(sql, params, false)
    }

    @RequestMapping([
            "/investor/settings/updatecurrency/currency/{currency}"
    ])
    public ResponseEntity<String> modify(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        String sql = getResource(request, params, ".sql");
        editResponse(sql, params)
    }

    @RequestMapping([
            "/ad/img/ideaId/{ideaId}",
            "/ad/imgbig/ideaId/{ideaId}",
            "/ad/pdf/ideaId/{ideaId}",
            "/investor/report/reportId/{reportId}",
            "/resources/download/{resName}"
    ])
    public ResponseEntity<byte[]> bytes(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        String sql = getResource(request, params, ".sql");
        bytesResponse(sql, params)
    }

    @RequestMapping([
            "/investor/operations/excel/am/startDate/{startDate}/endDate/{endDate}/export_am.xls",
            "/investor/operations/excel/fund/startDate/{startDate}/endDate/{endDate}/export_fund.xls"
    ])
    public ResponseEntity<byte[]> excel(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        byte[] template = (byte[]) getResource(request, params, ".xlt");
        String sql = getResource(request, params, ".sql");
        excelResponse(sql, params, template)
    }

    @RequestMapping([
            "/product/info/usd/productId/{productId}/number/{number}/amount/{amount}",
            "/product/info/rub/productId/{productId}/number/{number}/amount/{amount}",
            "/fund/info/bill/{fundId}/number/{number}/amount/{amount}"
    ])
    public ResponseEntity<byte[]> jasper(HttpServletRequest request, @RequestParam(value = "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        params.put("investorId", checkRights(request, investorId));
        byte[] template = (byte[]) getResource(request, params, ".jrxml");
        String sql = getResource(request, params, ".sql");
        jasperResponse(sql, params, template)
    }

    // todo: здесь дыра в безопасности. 1. Эти сервисы требуется закрывать 2. Неясно что делать с горизонтальными ограничениями
    @RequestMapping([
            "/admin/clients/all",
            "/admin/sms/all"
    ])
    public ResponseEntity<String> dataTables(HttpServletRequest request,
                                                 @RequestParam(value = "draw", required = true) int draw,
                                                 @RequestParam(value = "start", required = true) int start,
                                                 @RequestParam(value = "length", required = true) int length,
                                                 @RequestParam(value = "search[value]", required = true) String search,
                                                 @RequestParam(value= "investorId", required = false) String investorId) {
        Map<String, Object> params = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE) as Map<String, Object>
        if (investorId != null) {
            // запросы админки могут быть без идентификатора клиента
            params.put("investorId", checkRights(request, investorId))
        }
        else {
            // в этом случае для горизонтальных ограничений используется логин
            params.put("login", request.getUserPrincipal().getName())
            params.put("noFilters", request.isUserInRole("ROLE_SS-NOFILTERS") ? "1" : "0");
        }
        params.put("start", start)
        params.put("length", length)
        params.put("search", search)
        String sql = getResource(request, params, ".sql")
        def json = new JSONObject()
        json.put("draw", draw)
//        json.put("recordsTotal", 1000000)
//        json.put("recordsFiltered", 1000)
        //json.put("error", "CRITICAL")
        json.put("data", dao.convertToJSONArray(sql, params, true, false))
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    @RequestMapping([
            "/admin/clients/generate-password"
    ])
    public ResponseEntity<String> generateInvestorPassword(HttpServletRequest request, @RequestParam(value= "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        byte[] pass = random.generateSeed(6);
        String strPass = ""
        for (byte b : pass) {
            strPass += (Math.abs(b) % 10);
        }
        def passHash = HashUtils.hashPassword(strPass)
        def loginId = dao.getLoginIdByInvestorId(investorId)
        dao.setPassword(loginId, passHash)
        sms.sendMainPassword(loginId, dao.getPhoneByInvestorId(investorId), dao.getLoginByInvestorId(investorId), strPass)
        def json = new JSONObject()
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    @RequestMapping([
            "/admin/clients/register"
    ])
    public ResponseEntity<String> register(HttpServletRequest request, @RequestParam(value= "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        dao.registerClient(investorId);
        def json = new JSONObject()
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    @RequestMapping([
            "/admin/clients/block"
    ])
    public ResponseEntity<String> block(HttpServletRequest request, @RequestParam(value= "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        def loginId = dao.getLoginIdByInvestorId(investorId)
        dao.setBlockDate(loginId, new Timestamp(System.currentTimeMillis()))
        def json = new JSONObject()
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    @RequestMapping([
            "/admin/clients/unblock"
    ])
    public ResponseEntity<String> unblock(HttpServletRequest request, @RequestParam(value= "investorId", required = false) String investorId) {
        investorId = checkRights(request, investorId);
        def loginId = dao.getLoginIdByInvestorId(investorId)
        dao.setBlockDate(loginId, new Timestamp(new SimpleDateFormat("ddMMyyyy").parse("01013001").getTime()))
        def json = new JSONObject()
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    protected static String path(String pattern) {
        pattern.split("/").grep{ !it.startsWith("{") }.join("/")
    }

    static def cache = new HashMap()

    protected static getResource(HttpServletRequest request, params, String extension) {
        String pattern = request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE)
        ServletContext context = request.getServletContext();
        getResource(pattern, context, params, extension);
    }

    protected static getResource(String pattern, ServletContext context, params, String extension) {
        def cachePath = path(pattern);
        log.debug("Requested {} with params {} with extension {}", pattern, params, extension)
        def obj = cache.get(cachePath + extension)
        if (obj == null) {
            log.debug("Missing resource for {}", cachePath)
            obj = loadResource(cachePath, context.getRealPath(BASE_DIR), extension)
            log.debug("resource for {} loaded", cachePath)
            cache.put(cachePath + extension, obj)
        }
        obj
    }

    private static Object loadResource(String cachePath, String baseDir, String extension) {
        def path = recursiveFindFile(baseDir, cachePath, extension)
        if (".sql".equals(extension)) {
            return (path == null) ? "NOT FOUND" : new File(path).getText('UTF-8')
        }
        else {
            return (path == null) ? new byte[0] : new File(path).getBytes()
        }
    }

    private static String recursiveFindFile(String curDir, String rest, String extension) {
        def pret = rest.split("/")[0]
        def file = new File(curDir + "/" + pret + extension);
        if (file.exists()) {
            return curDir + "/" + pret + extension;
        }
        def dir = new File(curDir + "/" + pret);
        if (dir.exists() && dir.isDirectory()) {
            return recursiveFindFile(curDir + "/" + pret, rest.substring(pret.length() + 1), extension);
        }
        return null;
    }

    protected ResponseEntity<String> defaultResponse(String sql, Map<String, Object> params, boolean asObject = true) {
        def json = dao.queryForArray(sql, params, true, asObject)
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    protected ResponseEntity<String> editResponse(String sql, Map<String, Object> params) {
        def json = dao.queryModify(sql, params)
        new ResponseEntity<>(json.toString(), defaultHeaders(), HttpStatus.OK)
    }

    protected ResponseEntity<byte[]> bytesResponse(String sql, Map<String, Object> params) {
        HttpHeaders headers = new HttpHeaders()
        def json = dao.queryForArray(sql, params, false)
        def response = json.get("response") as JSONArray
        if (response == null || response.length() == 0) {
            return new ResponseEntity<>([], headers, HttpStatus.OK)
        }
        headers.add("Content-Type", response.get(0).get("mime_type") as String)
        headers.add("Content-filename", response.get(0).get("file_name") as String)
        new ResponseEntity<>(response.get(0).get("bytes"), headers, HttpStatus.OK)
    }

    protected ResponseEntity<byte[]> excelResponse(String sql, Map<String, Object> params, byte[] template) {
        HttpHeaders headers = new HttpHeaders()
        headers.add("Content-Type", "application/vnd.ms-excel")
        headers.add("Content-filename", "")
        new ResponseEntity<>(excelDao.queryForWorkbook(sql, params, template), headers, HttpStatus.OK)
    }

    protected ResponseEntity<byte[]> jasperResponse(String sql, Map<String, Object> params, byte[] template) {
        HttpHeaders headers = new HttpHeaders()
        headers.add("Content-Type", "application/pdf")
        headers.add("Content-filename", "")
        def json = dao.queryForArray(sql, params, false)
        byte[] result = JasperUtils.generate(json, template)
        new ResponseEntity<>(result, headers, HttpStatus.OK)
    }

}
