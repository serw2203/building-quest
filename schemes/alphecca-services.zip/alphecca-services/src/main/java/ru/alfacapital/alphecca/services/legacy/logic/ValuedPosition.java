package ru.alfacapital.alphecca.services.legacy.logic;
import java.math.BigDecimal;
import java.util.Map;

public class ValuedPosition {

    private BigDecimal positionValueNC;
    private String positionCurrencyCode;
    private Map<String, BigDecimal> valuesByCurrency;

    public ValuedPosition(BigDecimal positionValueNC, String positionCurrencyCode, Map<String, BigDecimal> valuesByCurrency) {
        this.positionValueNC = positionValueNC;
        this.positionCurrencyCode = positionCurrencyCode;
        this.valuesByCurrency = valuesByCurrency;
    }

    /**
     * Оценка в валюте по умолчанию.
     *
     * @return оценка в валюте по умолчанию
     */
    public BigDecimal getPositionValueNC() {
        return positionValueNC;
    }

    /**
     * Код валюты позиции.
     *
     * @return код валюты позиции
     */
    public String getPositionCurrencyCode(){
        return positionCurrencyCode;
    }

    public Map<String, BigDecimal> getValuesByCurrency() {
        return valuesByCurrency;
    }
}
