package ru.alfacapital.alphecca.services.legacy.data.dao;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import ru.alfacapital.alphecca.services.legacy.reports.model.PositionResponse2;
import ru.alfacapital.alphecca.services.legacy.reports.model.PrimitivePosition;


import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

@Repository
public class PositionDao {

    private static final Logger log = LoggerFactory.getLogger(PositionDao.class);

    private DataSource dataSource;

    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        setJdbcTemplate(new JdbcTemplate(this.dataSource));
    }

    private List<Object[]> queryToListObjects(String sql, Object[] params) {
        return getJdbcTemplate().query(sql, params, new RowMapper<Object[]>() {
            @Override
            public Object[] mapRow(ResultSet rs, int i) throws SQLException {
                int columnCount = rs.getMetaData().getColumnCount();
                Object[] returned = new Object[columnCount];
                for (int j = 1; j <= columnCount; j++) {
                    returned[j - 1] = rs.getObject(j);
                }
                return returned;
            }
        });
    }

    /**
     * Возвращает полностью выплаченные купоны имевшие место быть в периоде.
     */
    public BigDecimal getAccuiredCouponIncome(String assetId, java.util.Date startDate, java.util.Date stopDate) {
        BigDecimal result = BigDecimal.ZERO;

        String sql = "select period_start, period_stop, is_pay, coupon_amount, yearly_percent, delta_amount from SS_DATALINK.MV_ASSET_COUPON where asset_id = ? order by period_start";

        List<Object[]> list = queryToListObjects(sql, new Object[]{assetId});

        for (Object[] row : list) {
            boolean isDefault = 0 != ((BigDecimal) row[2]).intValue();
            if (isDefault) continue; // дефолтный купон не был выплачен
            java.util.Date periodStop = (java.util.Date) row[1];
            if (periodStop.compareTo(startDate) >= 0 && periodStop.compareTo(stopDate) < 0) {
                // купон целиком уже достался нам вместе с амортизированным телом
                result = result.add((BigDecimal) row[3]).add((BigDecimal) row[5]);
            }
        }
        return result;
    }

    private static class DMT {
        public String dmtId;
        public String assetId;
        public String assetValuationCurrency;
        public BigDecimal size;
        public BigDecimal debtRub;
        public BigDecimal depositRub;

        public PrimitivePosition debtPosition;
        public PrimitivePosition depositPosition;
    }

    /**
     * С одной стороны мы располагаем позицией из Спектра. Ей и только ей мы можем верить. С другой стороны в этой позиции многое потеряно,
     * здесь предпринимается попытка восстановить информацию, оставив СА инвариантом, из:
     * 1. Позиции Спектра
     * 2. Стеку ЦБ по проводкам Спектра
     * 3. Информации о частях DMT сделок из кубиков
     *
     * @param investorId UK клиента
     * @param contractId UK договора
     * @param date       дата оценки
     * @return позиция
     */
    public PositionResponse2 getContractPosition2(String investorId, String contractId, Date date) {
        log.debug("Calculating investor {} contract {} on {}", investorId, contractId, date);
        Map<String, DMT> dmts = new HashMap<String, DMT>();
        @SuppressWarnings({"unchecked"})

        String sql = "select valuation_currency, accounting_currency, asset_class, position_name, position_size, position_value, position_value_rub, " +
                "maturity_date, asset_id, is_sci, is_security, isin, dmt_id from ss.mv_contract_position_r3 where investor_id = ? and contract_id = ? " +
                "and aum_date = ? order by valuation_currency asc, ss_priority asc, position_value_rub desc";

        List<Object[]> list = queryToListObjects(sql, new Object[]{investorId, contractId, date});

        PositionResponse2 result = new PositionResponse2();
        for (Object[] line : list) {
            PrimitivePosition a = new PrimitivePosition();
            int col = 0;

            a.valuationCurrency = (String) line[col++];
            a.accountingCurrency = (String) line[col++];
            a.assetClass = (String) line[col++];
            a.positionName = (String) line[col++];
            a.positionSize = (BigDecimal) line[col++];
            a.positionValue = (BigDecimal) line[col++];
            a.positionValueRub = (BigDecimal) line[col++];

            Object maturityDate = line[col++];
            if (maturityDate != null) {
                a.maturityDate = maturityDate instanceof Timestamp ? new java.sql.Date(((Timestamp) maturityDate).getTime()) : (java.sql.Date) maturityDate;
            }

            Object assetId = line[col++];
            a.assetId = assetId != null ? assetId.toString() : null;

            Object isSCI = line[col++];
            a.isSCI = isSCI == null ? isSCI.equals(BigDecimal.ONE) : false;

            Object isSecurity = line[col++];
            a.isSecurity = isSecurity == null ? isSecurity.equals(BigDecimal.ONE) : false;

            a.isin = (String) line[col++];

            Object dmtId = line[col++];
            a.dmtId = isSecurity == null ? dmtId.toString() : null;


            log.trace("Position fetched: {} qty: {} value: {} rub {} asset {}", a.positionName, a.positionSize, a.positionValue, a.positionValueRub, a.assetId);
            result.positions.add(a);
            if (a.dmtId != null && !a.dmtId.equals("")) {
                DMT dmt = dmts.get(a.dmtId);
                if (dmt == null) {
                    dmt = new DMT();
                    dmt.dmtId = a.dmtId;
                    dmts.put(a.dmtId, dmt);
                    log.trace("Created DMT object for dmt {}", a.dmtId);
                }
                if (a.isSecurity) {
                    dmt.assetId = a.assetId;
                    dmt.size = a.positionSize;
                    dmt.assetValuationCurrency = a.valuationCurrency;
                } else if (a.isSCI) {
                    // информация о купоне попадает в инструмент позже (на следующем шаге)
                } else if ("Депозиты".equals(a.assetClass)) {
                    dmt.depositRub = a.positionValueRub;
                    dmt.depositPosition = a;
                } else {
                    dmt.debtRub = a.positionValueRub;
                    dmt.debtPosition = a;
                }
            }
        }
        logDMTStat(dmts);
        // необходимо объединить НКД с облигациями
        {
            Map<String, List<PrimitivePosition>> bonds = new HashMap<String, List<PrimitivePosition>>();
            Map<String, PrimitivePosition> scis = new HashMap<String, PrimitivePosition>();
            for (PrimitivePosition p : result.positions) {
                if (p.isSCI) {
                    // учитывая сложности в работе механизма компенсаторов DMT здесь скорее всего будет несколько записей по НКД,
                    // учитывая характер расчёта НКД, можно утверждать, что не зависимо от того сколько раз облигация будет в позиции
                    // НКД в расчёте на одну облигацию будет одним и тем же, поэтому соберём их сумму, с целью далее аллоцировать.
                    PrimitivePosition sci = scis.get(p.assetId);
                    if (sci == null) {
                        sci = p;
                        scis.put(p.assetId, sci);
                    } else {
                        log.trace("Multiple SCI for asset {}", p.assetId);
                        sci.positionValue = sci.positionValue.add(p.positionValue);
                        sci.positionValueRub = sci.positionValueRub.add(p.positionValueRub);
                    }
                }
                if (p.isSecurity) {
                    List<PrimitivePosition> l = bonds.get(p.assetId);
                    if (l == null) {
                        l = new ArrayList<PrimitivePosition>();
                        bonds.put(p.assetId, l);
                    } else {
                        log.trace("Multiple asset {} in position", p.assetId);
                    }
                    l.add(p);
                }
            }
            for (Map.Entry<String, PrimitivePosition> e : scis.entrySet()) {
                String assetId = e.getKey();
                List<PrimitivePosition> sameBonds = bonds.get(assetId);
                if (sameBonds != null) {
                    BigDecimal totalSCIValue = e.getValue().positionValue;
                    BigDecimal totalSCIValueRub = e.getValue().positionValueRub;
                    BigDecimal totalQty = BigDecimal.ZERO;
                    for (PrimitivePosition b : sameBonds) {
                        totalQty = totalQty.add(b.positionSize);
                    }
                    log.trace("Accumutaled qty for asset {} = {}", assetId, totalQty);
                    if (totalQty.compareTo(BigDecimal.ZERO) != 0) {
                        for (PrimitivePosition b : sameBonds) {
                            b.sciValue = totalSCIValue.multiply(b.positionSize).divide(totalQty, 20, BigDecimal.ROUND_HALF_UP);
                            b.sciValueRub = totalSCIValueRub.multiply(b.positionSize).divide(totalQty, 20, BigDecimal.ROUND_HALF_UP);
                        }
                    } else {
                        log.warn("Zero total asset qty for asset {}", assetId);
                    }
                } else {
                    log.error("SCI w/o bond for asset {}", assetId);
                }
            }
            // после таких манипуляций все НКД можно удалять из позиции
            Iterator<PrimitivePosition> i = result.positions.iterator();
            while (i.hasNext()) {
                PrimitivePosition p = i.next();
                if (p.isSCI) {
                    i.remove();
                    log.trace("Standalone SCI for asset {} dropped", p.assetId);
                }
            }
        }
        // построить стек в валюте номинала инструмента и узнать из него среднюю стоимости покупки в валюте номинала инструмента
        {
            Map<String, BigDecimal> qtys = new HashMap<>(); // asset_id -> qty
            Map<String, BigDecimal> costs = new HashMap<>(); // asset_id -> cost
            @SuppressWarnings("unchecked")

            String sql1 = "select asset_id, dol, fifo_qty, price\n" +
                    "  from (\n" +
                    "select contract_id, asset_id, dol, currency_id, wiring_day, \n" +
                    "       least(case when total_qty + sold_after_qty > 0 then total_qty + sold_after_qty else 0 end, positive_qty) fifo_qty,\n" +
                    "       price\n" +
                    "  from (\n" +
                    "    select contract_id, asset_id, dol, currency_id, value / qty price, wiring_day, qty,\n" +
                    "           case when qty > 0 then qty else 0 end positive_qty,\n" +
                    "           sum(qty) over (partition by contract_id, asset_id, currency_id order by wiring_day, dol) total_qty, \n" +
                    "           sum(case when qty < 0 then qty else 0 end) over (partition by contract_id, asset_id, currency_id order by wiring_day desc, dol desc) sold_after_qty\n" +
                    "      from ss_datalink.mv_daily_turn where wiring_day <= ?\n" +
                    "  )\n" +
                    ")\n" +
                    "where fifo_qty <> 0 and contract_id = ?\n";


            List<Object[]> fifo = queryToListObjects(sql1, new Object[]{date, contractId});


            for (Object[] line : fifo) {
                int col = 0;

                Object oAssetId = line[col++];
                String assetId = oAssetId != null ? oAssetId.toString() : null ;


                Object oDol = line[col++];
                String dol = oDol != null ? oDol.toString() : null ;

                BigDecimal qty = (BigDecimal) line[col++];
                BigDecimal price = (BigDecimal) line[col++];
                price = price.abs();
                BigDecimal wasQty = qtys.get(assetId);
                if (wasQty == null) {
                    wasQty = BigDecimal.ZERO;
                }
                qtys.put(assetId, wasQty.add(qty));
                BigDecimal cost = qty.multiply(price);
                BigDecimal wasCost = costs.get(assetId);
                if (wasCost == null) {
                    wasCost = BigDecimal.ZERO;
                }
                costs.put(assetId, wasCost.add(cost));
            }
            Map<String, BigDecimal> avgCosts = new HashMap<String, BigDecimal>();
            for (String assetId : qtys.keySet()) {
                BigDecimal qty = qtys.get(assetId);
                BigDecimal cost = costs.get(assetId);
                BigDecimal avg = cost.divide(qty, 20, BigDecimal.ROUND_HALF_UP);
                avgCosts.put(assetId, avg);
                log.trace("avg buy for asset {} = {}, qty = {}", assetId, avg, qty);
            }

            // Далее используется мощное и неправдоподобное допущение о том, что если у нас есть DMT остаток из Спектра с dmt_id,
            // то обязательно найдётся позиция с тем же размером среди построенных самостоятельно,
            // в этом случае происходит подмена.
            List<PrimitivePosition> toRemove = new ArrayList<PrimitivePosition>();
            // Собираем отдельно специальные случаи, для которых подстановка не удалась. (SpecialCase)
            Map<String, List<PrimitivePosition>> scAssetsToPositions = new HashMap<String, List<PrimitivePosition>>();
            for (PrimitivePosition p : result.positions) {
                String assetId = p.assetId;
                if (assetId != null) {
                    BigDecimal qty = qtys.get(assetId);
                    if (qty != null) {
                        if (qty.compareTo(p.positionSize) != 0) {
                            // это тот случай когда мы не можем ничего свернуть, потому что позиции очевидно разные.
                            log.debug("For contract_id {} asset_id {} quantity {} != {}", contractId, assetId, qty, p.positionSize);
                            List<PrimitivePosition> list1 = scAssetsToPositions.get(assetId);
                            if (list1 == null) {
                                list1 = new ArrayList<>();
                                scAssetsToPositions.put(assetId, list1);
                            }
                            list1.add(p);
                        } else {
                            // находим по инструменту DMT если она есть, и если DMT одна мы можем сделать подмену.
                            int counter = 0;
                            Map.Entry<String, DMT> foundedEntry = null;
                            for (Map.Entry<String, DMT> e : dmts.entrySet()) {
                                if (assetId.equals(e.getValue().assetId)) {
                                    counter++;
                                    foundedEntry = e;
                                }
                            }
                            BigDecimal avg = avgCosts.get(assetId);
                            if (avg != null) {
                                p.buyValue = avg.multiply(qty);
                            }
                            if (counter == 1) {
                                p.debtValueRub = foundedEntry.getValue().debtRub;
                                p.depositValueRub = foundedEntry.getValue().depositRub;
                                toRemove.add(foundedEntry.getValue().debtPosition);
                                toRemove.add(foundedEntry.getValue().depositPosition);
                                dmts.remove(foundedEntry.getKey());
                                log.debug("Asset {} of size {} matched with DMT {}", assetId, p.positionSize, foundedEntry.getValue().dmtId);
                            }
                        }
                    } else {
                        log.error("No FIFO qty for asset {}", assetId);
                    }
                }
            }
            result.positions.removeAll(toRemove);
            Map<String, List<DMT>> scAssetsToDMTs = new HashMap<String, List<DMT>>();
            for (DMT dmt : dmts.values()) {
                List<DMT> list1 = scAssetsToDMTs.get(dmt.assetId);
                if (list1 == null) {
                    list1 = new ArrayList<DMT>();
                    scAssetsToDMTs.put(dmt.assetId, list1);
                }
                list1.add(dmt);
            }

            {
                // При этом нужно учесть, что раз одна позиция скомпроментирована, то все позиции, с этим инструментом - скомпроментированы.
                for (PrimitivePosition p : result.positions) {
                    if (p.isSecurity && scAssetsToPositions.keySet().contains(p.assetId)) {
                        List<PrimitivePosition> l = scAssetsToPositions.get(p.assetId);
                        if (!l.contains(p)) {
                            l.add(p);
                        }
                    }
                }
                log.debug("Detected {} assets with several DMT", scAssetsToPositions.size());
                List<String> aidToRemove = new ArrayList<String>();
                for (String aid : scAssetsToPositions.keySet()) {
                    BigDecimal psize = BigDecimal.ZERO;
                    for (PrimitivePosition p : scAssetsToPositions.get(aid)) {
                        if (p.isSecurity) psize = psize.add(p.positionSize);
                    }
                    log.trace("Asset with several DMT: {} size {}", aid, psize);
                    if (psize.compareTo(BigDecimal.ZERO) == 0) {
                        aidToRemove.add(aid);
                    }
                }
                for (String aid : aidToRemove) {
                    scAssetsToPositions.remove(aid);
                    log.trace("DMT positions for asset {} dropped", aid);
                }
            }
            // Обратным сравнением отталкиваясь от оставшихся DMT ищем нужные позиции
            for (Map.Entry<String, List<DMT>> e : scAssetsToDMTs.entrySet()) {
                String assetId = e.getKey();
                List<DMT> scDmts = e.getValue();
                List<PrimitivePosition> poses = scAssetsToPositions.get(assetId);
                for (DMT d : scDmts) {
                    PrimitivePosition founded = null;
                    for (PrimitivePosition p : poses) {
                        if (p.dmtId != null && !p.dmtId.isEmpty()) {
                            if (d.size.compareTo(p.positionSize) == 0) {
                                founded = p;
                                break;
                            }
                        }
                    }
                    if (founded != null) {
                        founded.debtValueRub = d.debtRub;
                        founded.depositValueRub = d.depositRub;
                        toRemove.add(d.debtPosition);
                        toRemove.add(d.depositPosition);
                        dmts.remove(d.dmtId);
                        log.debug("Asset {} of size {} matched with DMT {}", assetId, founded.positionSize, d.dmtId);
                        poses.remove(founded);
                    }
                }
            }
            result.positions.removeAll(toRemove);
            // Сложить все оставшиеся позиции по инструменту
            {
                // Попытка убедиться в том, что размер позиции = 0
                List<String> aidToRemove = new ArrayList<String>();
                for (String aid : scAssetsToPositions.keySet()) {
                    BigDecimal psize = BigDecimal.ZERO;
                    for (PrimitivePosition p : scAssetsToPositions.get(aid)) {
                        if (p.isSecurity) psize = psize.add(p.positionSize);
                    }
                    log.trace("Asset {} size {}", aid, psize);
                    if (psize.compareTo(BigDecimal.ZERO) == 0) {
                        aidToRemove.add(aid);
                    }
                }
                for (String aid : aidToRemove) {
                    List<PrimitivePosition> poses = scAssetsToPositions.get(aid);
                    result.positions.removeAll(poses);
                    scAssetsToPositions.remove(aid);
                    log.trace("Positions for asset {} dropped", aid);
                }
            }
            // Далее следует патч, сделанный наспех. По каким-то причинам в отчёте остаются прямо-противоположные позиции, видимо от сделок DMT которые имели место быть в прошлом - убрать.
            {
                List<PrimitivePosition> toRemove2 = new ArrayList<PrimitivePosition>();
                for (PrimitivePosition p1 : result.positions) {
                    for (PrimitivePosition p2 : result.positions) {
                        if (p1.positionSize != null && p2.positionSize != null && p1.positionSize.compareTo(p2.positionSize.negate()) == 0) {
                            if (p1.assetId != null && p2.assetId != null && p1.assetId.equals(p2.assetId)) {
                                if (p1 != p2) {
                                    toRemove2.add(p1);
                                    toRemove2.add(p2);
                                    log.debug("2 positions on asset {} dropped", p1.assetId);
                                }
                            }
                        }
                    }
                }
                result.positions.removeAll(toRemove2);
            }
            // И наконец, на самом деле вся задолженность в договоре должна быть 1 раз в той валюте в которой происходит учёт договора.
            {
                List<PrimitivePosition> debts = new ArrayList<PrimitivePosition>();
                PrimitivePosition debtUSD = null;
                for (PrimitivePosition p : result.positions) {
                    if (p.positionName != null && p.positionName.startsWith("Расчёты")) {
                        debts.add(p);
                        if (p.valuationCurrency.equals("USD")) {
                            if (debtUSD != null) {
                                log.error("Multiple USD debt position");
                            }
                            debtUSD = p;
                        }
                    }
                }
                log.debug("Founded {} debts", debts.size());
                if (debtUSD != null && debtUSD.positionValue.compareTo(BigDecimal.ZERO) != 0) {
                    BigDecimal usdRate = debtUSD.positionValueRub.divide(debtUSD.positionValue, 20, BigDecimal.ROUND_HALF_UP);
                    for (PrimitivePosition p : debts) {
                        if (p != debtUSD) {
                            debtUSD.positionValueRub = debtUSD.positionValueRub.add(p.positionValueRub);
                            debtUSD.positionValue = debtUSD.positionValue.add(p.positionValueRub.divide(usdRate, 20, BigDecimal.ROUND_HALF_UP));
                            result.positions.remove(p);
                        }
                    }
                } else {
                    log.debug("No USD debt");
                }
            }
        }
        return result;
    }

    private void logDMTStat(Map<String, DMT> dmts) {
        Map<String, Integer> counters = new HashMap<String, Integer>();
        for (Map.Entry<String, DMT> e : dmts.entrySet()) {
            DMT dmt = e.getValue();
            Integer c = counters.get(dmt.assetId);
            if (c == null) c = 0;
            c++;
            counters.put(dmt.assetId, c);
        }
        for (Map.Entry<String, Integer> e : counters.entrySet()) {
            log.trace("DMT counter for asset {} = {}", e.getKey(), e.getValue());
        }
    }
}
