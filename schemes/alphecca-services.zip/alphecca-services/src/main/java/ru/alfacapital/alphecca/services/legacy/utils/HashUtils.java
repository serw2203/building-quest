package ru.alfacapital.alphecca.services.legacy.utils;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

public class HashUtils {

    private static byte[] SALT = new byte[] { 5, 100, -5, 4, 3, 89, -16, 57, 68, -14, -1, 0, 0, -60, 7, 101 };

    public static String hashPassword(String password) {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), SALT, 2048, 160);
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            byte[] hash = f.generateSecret(spec).getEncoded();
            return new BigInteger(hash).toString(15);
        }
        catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
        catch (InvalidKeySpecException ex) {
            throw new RuntimeException(ex);
        }
    }

}
