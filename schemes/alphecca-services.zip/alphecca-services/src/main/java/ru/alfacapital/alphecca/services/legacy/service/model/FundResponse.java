package ru.alfacapital.alphecca.services.legacy.service.model;

import ru.alfacapital.alphecca.services.legacy.CurrencyRater;
import ru.alfacapital.alphecca.services.legacy.Returns;
import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;
import ru.alfacapital.alphecca.services.legacy.logic.InvestmentResult;
import ru.alfacapital.alphecca.services.legacy.logic.InvestmentResultGenerator;
import ru.alfacapital.alphecca.services.legacy.logic.MFOperationValue;
import ru.ingie.commons.BigDecimals;
import ru.ingie.commons.DateUtils2;

import java.math.BigDecimal;
import java.util.*;

/**
 * Ответ на запрос об истории владения паями и их исторической стоимости.<br/>
 * <br/>
 * Данный объект инкапсулирует всю информацию необходимую для того чтобы построить любую
 * отчетность по истории владения паями для одного пайшика.
 *
 * Все даты определяются количеством дней прошедших с 01.01.2000.
 */
public class FundResponse {

    /** Названия фондов */
    public Map<String, String> names = new HashMap<String, String>();

    /** Лицевые счета в фонде */
    public Map<String, String> paccounts = new HashMap<String, String>();

    /** Даты начала владения */
    public Map<String, Long> minDates = new HashMap<String, Long>();

    /** Последние дни владения (или сегодня) */
    public Map<String, Long> maxDates = new HashMap<String, Long>();

    /** Исторические стоимости паёв (от начала даты владения до окончания владения) */
    public Map<String, TreeMap<Long, BigDecimal>> navs = new HashMap<String, TreeMap<Long, BigDecimal>>(); // fund_id -> date_dq -> nav

    /** Все операции по фондам. */
    public Map<String, Map<Long, MFOperationValue>> opers = new HashMap<String, Map<Long, MFOperationValue>>(); // fund_id -> date -> oper (amount (signed), cash (signed))

    /** Все операции по фондам в валюте. */
    public Map<String, Map<Long, MFOperationValue>> opersval = new HashMap<String, Map<Long, MFOperationValue>>(); // fund_id -> date -> oper (amount (signed), cash (signed))

    /** Потенциальная скидка при погашении паёв на последний расчётный день */
    public Map<String, BigDecimal> discounts = new HashMap<String, BigDecimal>(); // fund_id -> discount value

    /**
     * Полная очистка.
     */
    public void clear() {
        names.clear();
        paccounts.clear();
        navs.clear();
        opers.clear();
        minDates.clear();
        maxDates.clear();
        discounts.clear();
    }

    /**
     * Конвертор имеющихся исторических данных в нечто для чего возможен расчет результата инвестирования.
     *
     * @return портфель пифов как объект расчета результатов инвестиования
     */
    public InvestmentResultGenerator asInvestmentResultGenerator() {
        return asInvestmentResultGeneratorInCurrency("RUB", null);
    }

    /**
     * Конвертор имеющихся исторических данных в нечто для чего возможен расчет результата инвестирования.
     *
     * @param fundId идентификатор фонда, для которого происходит конвертация
     * @return фонд как объект расчета результатов инвестиования
     */
    public InvestmentResultGenerator asInvestmentResultGenerator(final String fundId, final String currencyCode, final CurrencyRater currencyRater) {
        return new InvestmentResultGenerator() {
            @Override
            public InvestmentResult getInvestmentResultForPeriod(Date start, Date stop) {
                Date yearStart = DateUtils2.truncateToYear(stop);
                Long yearStartDQ = SSConstants.toDQ(yearStart);
                Long startDQ = SSConstants.toDQ(start);
                Long stopDQ = SSConstants.toDQ(stop);
                Map<Long, MFOperationValue> opers = FundResponse.this.opers.get(fundId);
                TreeMap<Long, BigDecimal> navs = FundResponse.this.navs.get(fundId);

                Long minDate = FundResponse.this.minDates.get(fundId);
                if (minDate == null) {
                    minDate = startDQ;
                }

                if (minDate >= yearStartDQ) {
                    yearStartDQ = minDate;
                }

                Map<Long, BigDecimal> solidNavs = new HashMap<Long, BigDecimal>();
                solidNavs.put(minDate - 1, BigDecimal.ZERO);
                solidNavs.put(startDQ - 1, BigDecimal.ZERO);

                BigDecimal qty = BigDecimal.ZERO;
                BigDecimal sharesQtyAtStart = BigDecimal.ZERO;
                BigDecimal sharesQtyAtYearStart = BigDecimal.ZERO;
                BigDecimal sharesQtyAtStop = BigDecimal.ZERO;
                BigDecimal inflow = BigDecimal.ZERO;
                BigDecimal outflow = BigDecimal.ZERO;
                BigDecimal yearInflow = BigDecimal.ZERO;
                BigDecimal yearOutflow = BigDecimal.ZERO;
                BigDecimal totalInflow = BigDecimal.ZERO;
                BigDecimal totalOutflow = BigDecimal.ZERO;

                Map<Long, BigDecimal> opersByDates = new HashMap<>();

                List<BigDecimal> periodOperations = new ArrayList<>();
                List<BigDecimal> yearOperations = new ArrayList<>();

                List<Long> operDatesDQ = new ArrayList<Long>(opers.keySet());
                Collections.sort(operDatesDQ);
                Long lastDay = null;
                for (Long dateDQ : operDatesDQ) {
                    MFOperationValue operationValue = opers.get(dateDQ);
                    // до первой операции оценка нулевая, после первой операции до второй она меняется только из-за изменения стоимости пая.
                    {
                        if (lastDay != null) {
                            for (long d = lastDay; d < dateDQ; d++) {
                                Map.Entry<Long, BigDecimal> test = navs.floorEntry(d);
                                if (test == null) {
                                    throw new NullPointerException("No share cost for fund " + fundId + " on (" + d + ")");
                                }
                                BigDecimal nav = qty.multiply(test.getValue()).setScale(2, BigDecimal.ROUND_HALF_UP);
                                BigDecimal value = SSConstants.rate(currencyRater, nav, currencyCode, d);
                                solidNavs.put(d, value);
                            }
                        }
                        qty = qty.add(operationValue.getQty());
                        lastDay = dateDQ;
                    }
                    if (dateDQ <= stopDQ) {
                        BigDecimal cash = SSConstants.rate(currencyRater, operationValue.getCash(), currencyCode, dateDQ);
                        if (dateDQ < startDQ) {
                            // операция случившаяся в первый день периода считается операцией внутри периода
                            // оценка на начало периода это оценка на начало дня, т.е. оценка на конец дня предшествующего началу периода
                            sharesQtyAtStart = sharesQtyAtStart.add(operationValue.getQty());
                        }
                        else {
                            // операция случившаяся в первый день периода участвует в расчете доходности.
                            periodOperations.add(cash);
                        }
                        if (dateDQ < yearStartDQ) {
                            // операция случившаяся в первый день периода считается операцией внутри периода
                            // оценка на начало периода это оценка на начало дня, т.е. оценка на конец дня предшествующего началу периода
                            sharesQtyAtYearStart = sharesQtyAtYearStart.add(operationValue.getQty());
                        }
                        else {
                            // операция случившаяся в первый день периода участвует в расчете доходности.
                            yearOperations.add(cash);
                        }

                        // операция случившаяся в последний день периода считается операцией внутри периода
                        // оценка на конец периода это оценка на конец дня
                        sharesQtyAtStop = sharesQtyAtStop.add(operationValue.getQty());
                        opersByDates.put(dateDQ, cash);

                        if (operationValue.getQty().compareTo(BigDecimal.ZERO) > 0) {
                            // выдача
                            totalInflow = totalInflow.add(cash);
                            if (dateDQ >= yearStartDQ) {
                                yearInflow = yearInflow.add(cash);
                            }
                            if (dateDQ >= startDQ) {
                                inflow = inflow.add(cash);
                            }
                        }
                        else {
                            // погашение
                            totalOutflow = totalOutflow.add(cash.negate());
                            if (dateDQ >= yearStartDQ) {
                                yearOutflow = yearOutflow.add(cash.negate());
                            }
                            if (dateDQ >= startDQ) {
                                outflow = outflow.add(cash.negate());
                            }
                        }
                    }
                    else {
                        break;
                    }
                }

                // необходима инициализация оценки после последней оценки до последней отчётной даты
                if (lastDay != null) {
                    for (long d = lastDay; d < stopDQ; d++) {
                        Map.Entry<Long, BigDecimal> test = navs.floorEntry(d);
                        if (test == null) {
                            throw new NullPointerException("No share cost for fund " + fundId + " on (" + d + ")");
                        }
                        BigDecimal nav = qty.multiply(test.getValue()).setScale(2, BigDecimal.ROUND_HALF_UP);
                        BigDecimal value = SSConstants.rate(currencyRater, nav, currencyCode, d);
                        solidNavs.put(d, value);
                    }
                }


                BigDecimal firstAum = BigDecimal.ZERO;
                if (sharesQtyAtStart.compareTo(BigDecimal.ZERO) != 0) {
                    // количество и оценка на начало это оценки на начало дня, т.е. на конец предыдущего
                    Map.Entry<Long, BigDecimal> test = navs.floorEntry(startDQ - 1);
                    if (test == null) {
                        throw new NullPointerException("No share cost for fund " + fundId + " on " + start + " (" + startDQ + ") - 1");
                    }
                    firstAum = SSConstants.rate(currencyRater, sharesQtyAtStart.multiply(test.getValue()).setScale(2, BigDecimal.ROUND_HALF_UP), currencyCode, startDQ - 1);
                }

                BigDecimal yearFirstAum = BigDecimal.ZERO;
                if (sharesQtyAtYearStart.compareTo(BigDecimal.ZERO) != 0) {
                    // количество и оценка на начало это оценки на начало дня, т.е. на конец предыдущего
                    Map.Entry<Long, BigDecimal> test = navs.floorEntry(yearStartDQ - 1);
                    if (test == null) {
                        throw new NullPointerException("No share cost for fund " + fundId + " on " + yearStart + " (" + yearStartDQ + ") - 1");
                    }
                    yearFirstAum = SSConstants.rate(currencyRater, sharesQtyAtYearStart.multiply(test.getValue()).setScale(2, BigDecimal.ROUND_HALF_UP), currencyCode, yearStartDQ - 1);
                }

                BigDecimal lastAum = BigDecimal.ZERO;
                BigDecimal shareCostAtStop = null;
                if (sharesQtyAtStop.compareTo(BigDecimal.ZERO) != 0) {
                    Map.Entry<Long, BigDecimal> test = navs.floorEntry(stopDQ);
                    if (test == null) {
                        throw new NullPointerException("No share cost for fund " + fundId + " on " + stop + " (" + stopDQ + ")");
                    }
                    shareCostAtStop = SSConstants.rate(currencyRater, test.getValue(), currencyCode, stopDQ);
                    lastAum = SSConstants.rate(currencyRater, sharesQtyAtStop.multiply(test.getValue()).setScale(2, BigDecimal.ROUND_HALF_UP), currencyCode, stopDQ);
                }

                solidNavs.put(stopDQ, lastAum);
                Returns.fillGaps(solidNavs);

                BigDecimal yield;
                {   // за период
                    yield = Returns.modifiedDietz(startDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yield != null) {
                        yield = yield.multiply(BigDecimals.BD100);
                        if (yield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yield = null;
                        }
                    }
                }

                BigDecimal yearYield;
                {   // с начала инвестирования
                    yearYield = Returns.modifiedDietz(yearStartDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yearYield != null) {
                        yearYield = yearYield.multiply(BigDecimals.BD100);
                        if (yearYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yearYield = null;
                        }
                    }
                }

                BigDecimal totalYield;
                {   // с начала инвестирования
                    totalYield = Returns.modifiedDietz(minDate, stopDQ, opersByDates, solidNavs, 4);
                    if (totalYield != null) {
                        totalYield = totalYield.multiply(BigDecimals.BD100);
                        if (totalYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            totalYield = null;
                        }
                    }
                }

                // проверка на активность
                if (firstAum.compareTo(BigDecimal.ZERO) == 0
                        && yearFirstAum.compareTo(BigDecimal.ZERO) == 0
                        && lastAum.compareTo(BigDecimal.ZERO) == 0
                        && periodOperations.isEmpty()
                        && yearOperations.isEmpty()) {
                    return null;
                }
                else {
                    return new InvestmentResult("RUB", firstAum, yearFirstAum, sharesQtyAtStop, shareCostAtStop, lastAum, inflow, outflow, yield, yearInflow, yearOutflow, yearYield, totalInflow, totalOutflow, totalYield, minDate, opersByDates, solidNavs);
                }
            }
        };
    }

    public InvestmentResultGenerator asInvestmentResultGeneratorInCurrency(final String currencyCode, final CurrencyRater currencyRater) {
        return new InvestmentResultGenerator() {
            @Override
            public InvestmentResult getInvestmentResultForPeriod(Date start, Date stop) {
                Date yearStart = DateUtils2.truncateToYear(stop);
                Long startDQ = SSConstants.toDQ(start);
                Long yearStartDQ = SSConstants.toDQ(yearStart);
                Long stopDQ = SSConstants.toDQ(stop);
                Long minDate = null;
                Set<String> fundIds = FundResponse.this.opers.keySet();
                Map<String, InvestmentResult> results = new HashMap<String, InvestmentResult>();
                for (String fundId : fundIds) {
                    InvestmentResult ir = asInvestmentResultGenerator(fundId, currencyCode, currencyRater).getInvestmentResultForPeriod(start, stop);
                    if (ir != null) {
                        results.put(fundId, ir);
                        Long d = ir.getMinDate();
                        if (d != null && (minDate == null || minDate > d)) {
                            minDate = d;
                        }
                    }
                }

                if (minDate == null) {
                    minDate = startDQ;
                }

                if (minDate >= yearStartDQ) {
                    yearStartDQ = minDate;
                }

                BigDecimal firstAum = BigDecimal.ZERO;
                BigDecimal yearFirstAum = BigDecimal.ZERO;
                BigDecimal lastAum = BigDecimal.ZERO;
                BigDecimal inflow = BigDecimal.ZERO;
                BigDecimal outflow = BigDecimal.ZERO;
                BigDecimal yearInflow = BigDecimal.ZERO;
                BigDecimal yearOutflow = BigDecimal.ZERO;
                BigDecimal totalInflow = BigDecimal.ZERO;
                BigDecimal totalOutflow = BigDecimal.ZERO;

                Map<Long, BigDecimal> solidNavs = new HashMap<Long, BigDecimal>();
                solidNavs.put(minDate - 1, BigDecimal.ZERO);
                solidNavs.put(startDQ - 1, BigDecimal.ZERO);

                for (InvestmentResult ir : results.values()) {
                    firstAum = firstAum.add(ir.getFirstAum());
                    yearFirstAum = yearFirstAum.add(ir.getYearFirstAum());
                    lastAum = lastAum.add(ir.getLastAum());
                    inflow = inflow.add(ir.getInflow());
                    outflow = outflow.add(ir.getOutflow());
                    yearInflow = yearInflow.add(ir.getYearInflow());
                    yearOutflow = yearOutflow.add(ir.getYearOutflow());
                    totalInflow = totalInflow.add(ir.getTotalInflow());
                    totalOutflow = totalOutflow.add(ir.getTotalOutflow());
                    Map<Long, BigDecimal> map = ir.getAllAums();
                    if (map != null) {
                        for (Map.Entry<Long, BigDecimal> e : map.entrySet()) {
                            Long d = e.getKey();
                            BigDecimal was = solidNavs.get(d);
                            if (was == null) {
                                was = BigDecimal.ZERO;
                            }
                            was = was.add(e.getValue());
                            solidNavs.put(d, was);
                        }
                    }
                }

                Returns.fillGaps(solidNavs);

                Map<Long, BigDecimal> opersByDates = new HashMap<Long, BigDecimal>();

                Map<Long, MFOperationValue> opers = new HashMap<Long, MFOperationValue>();
                for (String fundId : results.keySet()) {
                    MFOperationValue.populate(opers, FundResponse.this.opers.get(fundId));
                }

                List<Long> operDatesDQ = new ArrayList<Long>(opers.keySet());
                Collections.sort(operDatesDQ);
                for (Long dateDQ : operDatesDQ) {
                    if (dateDQ <= stopDQ) {
                        MFOperationValue operationValue = opers.get(dateDQ);
                        BigDecimal cash = SSConstants.rate(currencyRater, operationValue.getCash(), currencyCode, dateDQ);
                        opersByDates.put(dateDQ, cash);
                    }
                }

                BigDecimal yield = null;
                if (results.size() > 0) {   // за период
                    yield = Returns.modifiedDietz(startDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yield != null) {
                        yield = yield.multiply(BigDecimals.BD100);
                        if (yield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yield = null;
                        }
                    }
                }

                BigDecimal yearYield = null;
                if (results.size() > 0) {   // с начала года
                    yearYield = Returns.modifiedDietz(yearStartDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yearYield != null) {
                        yearYield = yearYield.multiply(BigDecimals.BD100);
                        if (yearYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yearYield = null;
                        }
                    }
                }

                BigDecimal totalYield = null;
                if (results.size() > 0) {   // с начала инвестирования
                    totalYield = Returns.modifiedDietz(minDate, stopDQ, opersByDates, solidNavs, 4);
                    if (totalYield != null) {
                        totalYield = totalYield.multiply(BigDecimals.BD100);
                        if (totalYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            totalYield = null;
                        }
                    }
                }

                return new InvestmentResult(currencyCode, firstAum, yearFirstAum, null, null, lastAum, inflow, outflow, yield, yearInflow, yearOutflow, yearYield, totalInflow, totalOutflow, totalYield, minDate, opersByDates, solidNavs);
            }
        };
    }

}
