package ru.alfacapital.alphecca.services;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;

import java.util.ArrayList;
import java.util.List;

public class TestingAuthenticationProvider implements AuthenticationProvider {

    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new GrantedAuthority() {
            @Override
            public String getAuthority() {
                return "ROLE_SS-NOFILTERS";
//                return "ROLE_SS-MANAGER";
            }
        });
        return new UsernamePasswordAuthenticationToken(authentication.getPrincipal(), "password", authorities);
    }

    public boolean supports(Class<?> authentication) {
        return true;
    }
}
