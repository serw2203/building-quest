package ru.alfacapital.alphecca.services.legacy.reports

import groovy.json.JsonBuilder
import groovy.xml.DOMBuilder
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Scope
import org.springframework.context.annotation.ScopedProxyMode
import org.springframework.stereotype.Component
import org.springframework.transaction.annotation.Transactional
import org.w3c.dom.Document
import org.w3c.dom.Element
import ru.alfacapital.alphecca.services.legacy.reports.dao.PrintableReportDao
import ru.alfacapital.alphecca.services.legacy.reports.model.Balance
import ru.alfacapital.alphecca.services.legacy.reports.model.ReportPosition
import ru.alfacapital.alphecca.services.legacy.reports.model.Turnover
import ru.alfacapital.alphecca.services.legacy.utils.adapters.CurrencyAdapter

import javax.xml.bind.JAXBContext
import javax.xml.bind.Marshaller
import java.text.Format
import java.text.SimpleDateFormat

@Component
public class ReportBuilder{

    @Autowired
    private PrintableReportDao reportDao;

    @Autowired
    private ReportPositionAggregator reportPositionAggregator;

    @Transactional
    public buildPositionsXML(Document doc, Element reportElement, String investorId, String contractId, java.sql.Date reportDate) {
        List<ReportPosition> reportPositions = buildPositions(investorId, contractId, reportDate)
        JAXBContext jc = JAXBContext.newInstance(ReportPosition.class);
        Marshaller marshaller = jc.createMarshaller();
        DOMBuilder dom = new DOMBuilder(doc);
        reportElement.appendChild dom.contract("contract-id": contractId ) {
            reportPositions.groupBy({ it.currency }, { it.assetClass }).each { currency, currencyGroup ->
                dom.group(currency: currency, total: sumOfCurrentValues(currencyGroup)) {
                    currencyGroup.each { assetClass, assetClassGroup ->
                        def placeForMarshalling = dom.group(assetClass: assetClass, total: sumOfCurrentValues2(assetClassGroup))
                        assetClassGroup.each { reportPosition ->
                            marshaller.marshal ( reportPosition, placeForMarshalling )
                        }
                        placeForMarshalling
                    }
                }
            }
        }
    }

    private static sumOfCurrentValues(currencyGroup) {
        BigDecimal res = 0
        currencyGroup.each { assetClass, assetClassGroup ->
            assetClassGroup.each { reportPosition -> res += reportPosition.currentValue }
        }
        new CurrencyAdapter().marshal(res)
    }

    private static sumOfCurrentValues2(assetClassGroup) {
        BigDecimal res = 0
        assetClassGroup.each { reportPosition -> res += reportPosition.currentValue }
        new CurrencyAdapter().marshal(res)
    }

    @Transactional
    public String buildPositionsJSON(String investorId, String contractId, java.sql.Date reportDate) {
        List<ReportPosition> reportPositions = buildPositions(investorId, contractId, reportDate)
        JsonBuilder json = new JsonBuilder()
        Format formatter = new SimpleDateFormat("dd.MM.yyyy")
        json.contract("reportDate": formatter.format(reportDate),
                       "contract-id": contractId,
                groups: reportPositions.groupBy({ it.currency }, { it.assetClass }).collect {
                    json(currency: it.key, groups: it.value.collect {
                        json(assetClass: it.key, positions: it.value.sort { -it.currentValue })
                    })
                })
        String string = json.toPrettyString();
        string
    }

    public List<ReportPosition> buildPositions(String investorId, String contractId, java.sql.Date reportDate) {
        Collection<Balance> balances = reportDao.findBalances(investorId, contractId, reportDate);
        Collection<Turnover> turnovers = reportDao.findTurnovers(contractId, reportDate);
        List<ReportPosition> reportPositions = reportPositionAggregator.aggregate(turnovers, balances, reportDate);
        def sortOrders = reportDao.getAssetClassSortOrders();
        reportPositions.sort { a, b ->
            def cmp = a.currency?.compareTo(b.currency)
            if (cmp != 0) return cmp
            cmp = sortOrders.get(a.assetClass)?.compareTo(sortOrders.get(b.assetClass))
            return cmp != 0 ? cmp : -a.currentValue?.compareTo(b.currentValue)
        }
        reportPositions
    }

}
