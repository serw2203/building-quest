package ru.alfacapital.alphecca.services.legacy.logic;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Тело операции с паями
 */
public class MFOperationValue {

    private final BigDecimal qty;
    private final BigDecimal cash;

    public MFOperationValue() {
        this(BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public MFOperationValue(BigDecimal qty, BigDecimal cash) {
        this.qty = qty;
        this.cash = cash;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public BigDecimal getCash() {
        return cash;
    }

    public MFOperationValue add(MFOperationValue ov) {
        return add(ov.getQty(), ov.getCash());
    }

    public MFOperationValue add(BigDecimal qty, BigDecimal cash) {
        return new MFOperationValue(this.qty.add(qty), this.cash.add(cash));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MFOperationValue that = (MFOperationValue) o;

        if (cash != null ? !cash.equals(that.cash) : that.cash != null) return false;
        if (qty != null ? !qty.equals(that.qty) : that.qty != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = qty != null ? qty.hashCode() : 0;
        result = 31 * result + (cash != null ? cash.hashCode() : 0);
        return result;
    }

    /**
     * Сложить суммы операций в разрезе дат.
     *
     * @param target слагаемое и результат (содержимое будет изменено)
     * @param source слагаемое
     */
    public static void populate(Map<Long, MFOperationValue> target, Map<Long, MFOperationValue> source) {
        for (Map.Entry<Long, MFOperationValue> e : source.entrySet()) {
            Long dq = e.getKey();
            MFOperationValue val = e.getValue();
            MFOperationValue was = target.get(dq);
            if (was != null) {
                val = val.add(was);
            }
            target.put(dq, val);
        }
    }

}
