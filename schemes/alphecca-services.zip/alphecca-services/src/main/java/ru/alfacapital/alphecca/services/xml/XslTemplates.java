package ru.alfacapital.alphecca.services.xml;

import java.io.IOException;
import java.io.InputStream;

public interface XslTemplates {

    InputStream getXslPortfolioReportAsStream() throws IOException;

}
