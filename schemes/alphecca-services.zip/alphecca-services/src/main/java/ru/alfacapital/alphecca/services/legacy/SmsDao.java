package ru.alfacapital.alphecca.services.legacy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

@Repository
public class SmsDao {

    private NamedParameterJdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        setJdbcTemplate(new NamedParameterJdbcTemplate(dataSource));
    }

    @Transactional
    public void smsSended(String loginId, String code, String gate, String phone, String text) {
        if (text == null) text = "";
        text = text.replaceAll("[\\d]", "*");
        String sql = "insert into ss.tab_sms (sms_id, login_id, send_date, status, phone, gate, message) values (" +
                "ss.hibernate_sequence.nextval, :login_id, :send_date, :status, :phone, :gate, :message)";
        Map<String, Object> params = new HashMap<>();
        params.put("login_id", loginId);
        params.put("status", code);
        params.put("send_date", new Timestamp(System.currentTimeMillis()));
        params.put("gate", gate);
        params.put("phone", phone);
        params.put("message", text);
        jdbcTemplate.update(sql, params);
    }

    public Long getNextSmsId() {
        return jdbcTemplate.queryForObject("select ss.seq_sms.nextval from sys.dual", new HashMap<String, Object>(), Long.class);
    }

}
