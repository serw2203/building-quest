package ru.alfacapital.alphecca.services.rest;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.legacy.ProjectProperty;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.util.ByteArrayDataSource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by Y.Bocharov on 15.07.2015.
 *
 * Контроллер реализует звременную заглушку для операции покупки, в случае нажатия кнопки купить клиентом, его инвестконсультанту
 * должно приходить письмо о том что клиент решил чтото купить
 * данные модуль должен быть в скором времяни удален
 *
 *todo удалить после внедрения покупок!!!! этот класс не надо поддерживать его надо удалить!
 *
 *
 */

@Controller
public class BuyDummyController extends GenericController{

    private static final Logger log = LoggerFactory.getLogger(BuyDummyController.class);


    @Autowired
    private SSDaoImpl ssDao;

    private String SMTP_HOST = "10.77.10.42";
    private String SMTP_PORT = "25";
    //private String MAIL_FROM = "customerservices@corp.alfacapital.ru";
    private String USER = "customerservices@corp.alfacapital.ru";
    private String PASS = "Cke;,f01!";
    private boolean USE_TLS = false;

    private class Email {
        private final String emailText;
        private final String emailAddress;

        public Email(String emailText, String emailAddress) {
            this.emailAddress = emailAddress;
            this.emailText = emailText;
        }

        public String getEmailText() {
            return emailText;
        }

        public String getEmailAddress() {
            return emailAddress;
        }
    }



    // producttype = [mf am]
    @RequestMapping(value = "/buy/stubBuy/{producttype}/{productid}")
    public ResponseEntity<String> stubBuyMf(HttpServletRequest request,
                                            @PathVariable(value = "productid") String productId,
                                            @PathVariable(value = "producttype") String productType,
                                            @RequestParam(value = "investorid", required = false) String investorId) {

        JSONObject responseJson = new JSONObject();
        investorId = checkRights(request, null);

        try {
            Email email = compileMail(investorId, productId, productType);
            if ((email== null) || (StringUtils.isEmpty(email.getEmailText()))) {
                responseJson.put("statusEmail", "error");
            } else {
                String emailAddress = email.getEmailAddress();
                if (StringUtils.isEmpty(emailAddress)) {
                    emailAddress = "customerservices@alfacapital.ru";
                }
                if (ProjectProperty.sendConsulNotification()) {
                    sendHTMLMail("customerservices@alfacapital.ru", emailAddress, "уведомление", email.getEmailText(), null, "", "", new HashMap<String, InputStream>());
                } else {
                    sendHTMLMail("customerservices@alfacapital.ru", ProjectProperty.getMagicEmail(), "уведомление " + emailAddress, email.getEmailText(), null, "", "", new HashMap<String, InputStream>());
                }
                responseJson.put("statusEmail", "ok");
            }
        } catch (Exception ex) {
            log.error("Error send buy notification mail", ex);
            responseJson.put("statusEmail", "error");
        }

        responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }

    private Email compileMail(String investorId, String productId, String productType) {
        if (StringUtils.isEmpty(productId)) {
            // идентификатор продукта не передан ничего не делаем
            return null;
        }
        Map<String, Object> product = null;
        if ("am".equals(productType)) {
            product = ssDao.getStrategy(productId);
        }
        if ("mf".equals(productType)) {
            product = ssDao.getFundForBuy(productId);
        }
        if (product == null) {
            // ничего не найдено ничего не делаем
            return null;
        }
        if (StringUtils.isEmpty(investorId)) {
            // идентификатор продукта не передан ничего не делаем
            return null;
        }
        Map<String, Object> investorInfo = ssDao.getInvestorInfo(investorId);
        String emailText = getEmailText((String)investorInfo.get("name"),
                                        (String)product.get("name"),
                                        (String)investorInfo.get("phone"),
                                        (String)investorInfo.get("email"));
        return new Email(emailText, (String)investorInfo.get("consul_email"));
    }

    public String getEmailText(String investorName, String productName, String investorPhones, String investorEmail) {
        return "<html><body>"+
                "Клиент <b>" + investorName + "</b> интересуется продуктом " + productName + "<br/>\n" +
                "тел: " + investorPhones + "<br/>\n" +
                "email " + investorEmail +
                "</body></html>";

    }


    public void sendHTMLMail(String email_from, String email_to, String subj, String html, InputStream attach, String type,
                             String attachName, Map<String, InputStream> cids) throws IOException, MessagingException {

        Properties props = new Properties();
        props.put("mail.smtp.host", SMTP_HOST);
        if (USE_TLS) {
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.auth", "true");
        }
        props.put("mail.smtp.port", SMTP_PORT);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USER, PASS);
            }
        });
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(email_from));
        String[] email_tos = email_to.split(",");
        if (email_tos.length < 1) {
            email_tos = new String[1];
            email_tos[0] = email_to;
        }
        InternetAddress[] address = new InternetAddress[email_tos.length];
        for (int i = 0; i < email_tos.length; i++)
        {
            address[i] = new InternetAddress(email_tos[i]);
        }
        msg.setRecipients(Message.RecipientType.TO, address);
        msg.setSubject(subj, "utf-8");
        msg.setSentDate(new java.util.Date());
        MimeBodyPart mailBody = new MimeBodyPart();
        mailBody.setContent(html, "text/html; charset=utf-8");
        Multipart mp = new MimeMultipart();
        mp.addBodyPart(mailBody);
        if (attach != null) {
            MimeBodyPart mbp = new MimeBodyPart();
            DataSource ds = new ByteArrayDataSource(attach, type);
            mbp.setDataHandler(new DataHandler(ds));
            mbp.setFileName(MimeUtility.encodeText(attachName));
            mp.addBodyPart(mbp);
        }
        for (Map.Entry<String, InputStream> e : cids.entrySet()) {
            MimeBodyPart part = new MimeBodyPart();
            DataSource fds = new ByteArrayDataSource(e.getValue(), "image/png");
            part.setDataHandler(new DataHandler(fds));
            part.setHeader("Content-ID", e.getKey());
            mp.addBodyPart(part);
        }
        msg.setContent(mp);
        Transport transport = session.getTransport("smtp");
        transport.connect();
        transport.sendMessage(msg, msg.getAllRecipients());
        transport.close();

    }


}
