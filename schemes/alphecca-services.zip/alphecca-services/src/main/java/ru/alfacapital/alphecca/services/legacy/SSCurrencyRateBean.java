package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;

public class SSCurrencyRateBean  {
    private long rateDateDQ;
    private BigDecimal rateToRub;

    public long getRateDateDQ() {
        return rateDateDQ;
    }

    public void setRateDateDQ(long rateDateDQ) {
        this.rateDateDQ = rateDateDQ;
    }

    public BigDecimal getRateToRub() {
        return rateToRub;
    }

    public void setRateToRub(BigDecimal rateToRub) {
        this.rateToRub = rateToRub;
    }
}
