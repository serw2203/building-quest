package ru.alfacapital.alphecca.services.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;
import ru.alfacapital.alphecca.services.legacy.reports.ReportBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class PositionController extends GenericController {

    @Autowired
    private ReportBuilder reportBuilder;

    @RequestMapping(value = "/portfolio/position/contractId/{contractId}/dateDQ/{dateDQ}")
    public ResponseEntity<String> getPosition(HttpServletRequest request,
                                              @RequestParam(value = "investorId", required = false) String investorId,
                                              @PathVariable(value = "contractId") String contractId,
                                              @PathVariable(value = "dateDQ") Long dateDQ) {
        investorId = checkRights(request, investorId);
        String json = reportBuilder.buildPositionsJSON(investorId, contractId, SSConstants.toDate(dateDQ));
        return new ResponseEntity<>(json, defaultHeaders(), HttpStatus.OK);
    }

}
