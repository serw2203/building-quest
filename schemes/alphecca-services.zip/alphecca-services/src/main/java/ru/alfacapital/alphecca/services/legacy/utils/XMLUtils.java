package ru.alfacapital.alphecca.services.legacy.utils;

import java.math.BigDecimal;
import java.util.Date;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class XMLUtils {

    private static final SimpleDateFormat xmlDateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.US);
    private static DecimalFormatSymbols decimalFormatSymbols = DecimalFormatSymbols.getInstance(Locale.US);
    static {
        // Был соблазн использовать французскую локаль (Locale.FRENCH), чтобы обойтись без этого блока.
        // Так делать не надо, т.к. в ней разделитель групп не пробел, а nbsp.
        // Мы же хотим, чтобы числа в ячейках таблиц переносились по группам.
        decimalFormatSymbols.setDecimalSeparator(',');
        decimalFormatSymbols.setGroupingSeparator(' ');
    }
    private static DecimalFormat xmlCurrencyFormat = new DecimalFormat("#,##0.00", decimalFormatSymbols);
    private static DecimalFormat xmlSharesFormat = new DecimalFormat("#,##0.00000", decimalFormatSymbols);
    private static DecimalFormat xmlSizeFormat = new DecimalFormat("#,##0.00###", decimalFormatSymbols);
    private static DecimalFormat xmlPercentFormat = new DecimalFormat("#,##0.0", decimalFormatSymbols);

    public static String xmlFormatCurrency(BigDecimal val) {
        if (val == null) {
            return "";
        } else {
            return xmlCurrencyFormat.format(val);
        }
    }

    public static String xmlFormatSize(BigDecimal val) {
        if (val == null) {
            return "-";
        } else {
            return xmlSizeFormat.format(val);
        }
    }

    public static String xmlFormatShares(BigDecimal val) {
        if (val == null) {
            return "-";
        } else {
            return xmlSharesFormat.format(val);
        }
    }

    public static String xmlFormatPercent(BigDecimal val) {
        if (val == null) {
            return "";
        } else {
            return xmlPercentFormat.format(val);
        }
    }

    public static String xmlFormatDate(Date val) {
        if (val == null) {
            return "-";
        }
        return xmlDateFormat.format(val);
    }

}
