package ru.alfacapital.alphecca.services.xml;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamSource;

public class ClasspathURIResolver implements URIResolver {

    Logger logger = LoggerFactory.getLogger(ClasspathURIResolver.class);

    public Source resolve(String href, String base) throws TransformerException {
        Source source = null;
        InputStream inputStream = ClasspathURIResolver.class.getResourceAsStream("../../../" + href);
        if (inputStream != null) {
            source = new StreamSource(inputStream);
        }
        return source;
    }

}