package ru.alfacapital.alphecca.services.rest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.alfacapital.alphecca.services.dao.JsonJdbcDao;
import ru.alfacapital.alphecca.services.legacy.ProjectProperty;
import ru.alfacapital.alphecca.services.legacy.SmsService;

import javax.servlet.http.HttpServletRequest;
import java.util.Random;

/**
 * Created by Y.Bocharov on 20.07.2015.
 */

@Controller
public class WelcomeSmsController extends GenericController {


    @Autowired
    private SmsService sms;

    @Autowired
    private JsonJdbcDao dao;


    public static final String COUNT_ATTEMPT_CHECK_SMS = "countAtemptCheckSms";
    public static int MAX_ATTEMPT = 3;


    /**
     * // return status [incorrectPhone, incorrectCode, isSent, inProgress]
     * @param sms
     * @param request
     */
    @RequestMapping(value = "/sms/welcome/check")
    public ResponseEntity<String> checkWelcomeSms(HttpServletRequest request,
                                                  @RequestParam(value = "sms", required = false) String sms) {
        JSONObject responseJson = new JSONObject();
        if (!ProjectProperty.checkWelcomeSms() ) {
            responseJson.put("status", "ok");
            responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
            responseJson.put("status", "ok");
            return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
        }

        request.getSession().setAttribute(SESSION_HAS_WELCOME_SMS_CODE, false);

        Integer countAttemp = (Integer) request.getSession().getAttribute(COUNT_ATTEMPT_CHECK_SMS);
        countAttemp = countAttemp == null ? 0 : countAttemp;
        if (countAttemp > MAX_ATTEMPT) {
            responseJson.put("status", "maxAttempt");
        } else {
            if (this.sms.checkSmsCode(request, sms, false)) {
                request.getSession().setAttribute(COUNT_ATTEMPT_CHECK_SMS, Integer.valueOf(0));
                request.getSession().setAttribute(SESSION_HAS_WELCOME_SMS_CODE, true);
                responseJson.put("status", "ok");
            } else {
                request.getSession().setAttribute(COUNT_ATTEMPT_CHECK_SMS, Integer.valueOf(countAttemp + 1));
                sendWelcomeSms(request);
                responseJson.put("status", "incorrectCode");

            }
        }
        responseJson = new JSONObject().put("response", (new JSONArray()).put(responseJson));
        responseJson.put("status", "ok");
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }



    @RequestMapping(value = "/sms/welcome/send")
    public ResponseEntity<String> sendWelcomeSms(HttpServletRequest request) {

        JSONObject responseJson = new JSONObject();
        if (!ProjectProperty.sendSms()) {
            responseJson.put("status", "ok");
            return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
        }

        String smsCode = String.valueOf(new Random().nextInt(9000) + 1000);
        String investorId = getInvestorId(request, null);
        String loginId = dao.getLoginIdByInvestorId(investorId);
        String phoneNumber = dao.getPhoneByInvestorId(investorId);
        String smsMessage = "Kod dlya vhoda - " + smsCode;

        boolean isSent = sms.send(loginId, phoneNumber, smsMessage);
        if (isSent) {
            sms.saveSmsCode(request, smsCode);
            responseJson.put("status", "ok");
            responseJson.put("phoneNumber", phoneNumber);
        } else {
            responseJson.put("status", "error");
            responseJson.put("error", "Сбой службы отправки SMS");
        }
        responseJson.put("status", "ok");
        return new ResponseEntity<>(responseJson.toString(), defaultHeaders(), HttpStatus.OK);
    }


}
