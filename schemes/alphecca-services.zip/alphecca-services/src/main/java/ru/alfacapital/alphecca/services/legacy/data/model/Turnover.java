package ru.alfacapital.alphecca.services.legacy.data.model;

import java.math.BigDecimal;
import java.util.Date;

@Deprecated
public class Turnover {
    private String assetId;
    private String dol;
    private BigDecimal remainingQty;
    private BigDecimal price;
    private BigDecimal aciPrice;
    private String currency;
    private Date date;

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    public String getDol() {
        return dol;
    }

    public void setDol(String dol) {
        this.dol = dol;
    }

    public BigDecimal getRemainingQty() {
        return remainingQty;
    }

    public void setRemainingQty(BigDecimal remainingQty) {
        this.remainingQty = remainingQty;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAciPrice() {
        return aciPrice;
    }

    public void setAciPrice(BigDecimal aciPrice) {
        this.aciPrice = aciPrice;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}

