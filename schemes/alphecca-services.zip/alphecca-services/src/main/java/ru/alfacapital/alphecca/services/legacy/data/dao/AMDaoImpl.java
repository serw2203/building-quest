package ru.alfacapital.alphecca.services.legacy.data.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import ru.alfacapital.alphecca.services.legacy.AMResponse;
import ru.alfacapital.alphecca.services.legacy.SSAMOperBean;
import ru.alfacapital.alphecca.services.legacy.SSContractBean;
import ru.alfacapital.alphecca.services.legacy.SSContractSummaryBean;
import ru.alfacapital.alphecca.services.legacy.data.model.SSInvestorBean;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Repository
public class AMDaoImpl {

    public static final String SS = "ss";

    private DataSource dataSource;

    private NamedParameterJdbcTemplate jdbcTemplate;


    /**
     * Возвращает историю инвестирования, в разрезе договоров ДУ с фильтром по типу инвестиций.
     * Ответ содержит оценки и операции вплоть до (включая) максимальной отчетной даты по данному инвестору.
     *
     * @see AMResponse#navs
     * @see AMResponse#infoNavs
     * @see AMResponse#maxDates
     *
     * @param investorId инвестор
     * @return история инвестирования в ДУ
     */
    public AMResponse getAMResponse(String investorId, String filterContractId) {
        Long maxReportDateDQ = Long.MAX_VALUE; // todo: вернуть investor.getMaxReportDateDQ();
        AMResponse result = new AMResponse();
        List<? extends SSContractBean> contracts = getContract(investorId, filterContractId);
        for (SSContractBean c : contracts) {
            String strategyName = c.getStrategyName();
            if (strategyName == null) strategyName = "";
            String contractNumber = c.getContractNumber();
            if (contractNumber == null) contractNumber = "";
            strategyName = strategyName.trim();
            contractNumber = contractNumber.trim();
            String name;
            if (strategyName.isEmpty()) {
                name = contractNumber;
            } else {
                if (strategyName.toLowerCase().startsWith("фолио.")) {
                    name = strategyName.substring(6).trim();
                } else {
                    name = strategyName;
                }
            }
            result.names.put(c.getId(), name);
            result.strategies.put(c.getId(), c.getStrategyName());
            result.strategyids.put(c.getId(),c.getCompositeId());
            result.strategyCurrencies.put(c.getId(), c.getCurrencyCode());
            result.orgs.put(c.getId(), c.getOrgCode());
            result.contractNumbers.put(c.getId(), c.getContractNumber());
            result.contractDates.put(c.getId(), c.getContractDate());

            boolean alfaProfit = strategyName.toLowerCase().startsWith("альфа-профит");
            result.drilldown.put(c.getId(), alfaProfit ? 0 : 1);
            result.alfaprofit.put(c.getId(), alfaProfit ? 1 : 0);
            result.blocked.put(c.getId(), c.getBlocked());
        }

        List<? extends SSContractSummaryBean> data = getAums(investorId, filterContractId);
        for (SSContractSummaryBean s : data) {
            String contractId = s.getContractId();
            TreeMap<Long, BigDecimal> mapNavs = result.navs.get(contractId);
            if (mapNavs == null) {
                mapNavs = new TreeMap<Long, BigDecimal>();
                result.navs.put(contractId, mapNavs);
            }
            TreeMap<Long, BigDecimal> mapInfoNavs = result.infoNavs.get(contractId);
            if (mapInfoNavs == null) {
                mapInfoNavs = new TreeMap<Long, BigDecimal>();
                result.infoNavs.put(contractId, mapInfoNavs);
            }
            Long dateDQ = s.getDateDQ();
            if (dateDQ.compareTo(maxReportDateDQ) <= 0) { // оценка на дату большую максимальной отчетной может появиться, но мы не должны её показывать
                BigDecimal aum = s.getAum();
                if (aum == null) {
                    // этого не должно случаться (запасная проверка)
                    aum = BigDecimal.ZERO;
                }
                mapNavs.put(dateDQ, aum);

                BigDecimal infoAum = s.getClosingAum();
                if (infoAum == null) {
                    // этого не должно случаться (запасная проверка)
                    infoAum = BigDecimal.ZERO;
                }
                mapInfoNavs.put(dateDQ, infoAum);

                if (aum.compareTo(BigDecimal.ZERO) != 0) {
                    Long minDQ = result.minDates.get(contractId);
                    Long maxDQ = result.maxDates.get(contractId);
                    if (minDQ == null || minDQ > dateDQ) {
                        result.minDates.put(contractId, dateDQ);
                    }
                    if (maxDQ == null || maxDQ < dateDQ) {
                        result.maxDates.put(contractId, dateDQ);
                    }
                }
            }
        }

        // Может случиться так, что в портфеле нет ни одной не нулевой оценки, в этом случае нужно чем-нибудь заполнить minDate и maxDate
        for (SSContractBean c : contracts) {
            if (result.maxDates.get(c.getId()) == null) {
                result.maxDates.put(c.getId(), maxReportDateDQ);
            }
            if (result.minDates.get(c.getId()) == null) {
                result.minDates.put(c.getId(), maxReportDateDQ);
            }
        }

        // Приходится ещё раз пройтись по набору здесь на сервере, чтобы объём данных к передаче не был чрезмерным.
        // Удаляем все нули до начала инвестирования и после последней оценки.
        for (String contractId : result.navs.keySet()) {
            removePairsOutside(result.navs.get(contractId), result.minDates.get(contractId), result.maxDates.get(contractId));
        }
        for (String contractId : result.infoNavs.keySet()) {
            removePairsOutside(result.infoNavs.get(contractId), result.minDates.get(contractId), result.maxDates.get(contractId));
        }

        // Внешние финансовые потоки
        // Если у договора несколько потоков за день, мы их суммируем
        List<SSAMOperBean> cashflow = getOpers(investorId, filterContractId);
        for (SSAMOperBean o : cashflow) {
            Map<Long, AMResponse.Oper> opers = result.opers.get(o.getContractId());
            if (opers == null) {
                opers = new HashMap<Long, AMResponse.Oper>();
                result.opers.put(o.getContractId(), opers);
            }
            if (o.getDateDQ().compareTo(maxReportDateDQ) <= 0) { // операции после максимально отчётной даты не должны быть видны
                AMResponse.Oper oper = opers.get(o.getDateDQ());
                if (oper == null) {
                    oper = new AMResponse.Oper();
                    oper.amount = BigDecimal.ZERO;
                    oper.currencyAmount = BigDecimal.ZERO;
                    opers.put(o.getDateDQ(), oper);
                }
                oper.amount = oper.amount.add(o.getAmount());
                oper.currencyAmount = oper.currencyAmount.add(o.getCurrencyAmount());
            }
        }
        return result;
    }



    public List<SSAMOperBean> getOpers(String investorId, String contractId) {
        Map<String, Object> params = new HashMap<String, Object>();
        String query = "select * from " + SS + ".vie_am_cashflow where INVESTOR_ID = :INVESTOR_ID ";
        params.put("INVESTOR_ID", investorId);
        if ((contractId != null) && (!contractId.equals(""))) {
            query += " and CONTRACT_ID = :CONTRACT_ID";
            params.put("CONTRACT_ID", contractId);
        }

        RowMapper<SSAMOperBean> operMapper = new RowMapper<SSAMOperBean>() {
            public SSAMOperBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                SSAMOperBean amOper = new SSAMOperBean();
                amOper.setOperationId(rs.getString("OPERATION_ID"));
                amOper.setInvestorId(rs.getString("INVESTOR_ID"));
                amOper.setContractId(rs.getString("CONTRACT_ID"));
                amOper.setInvestmentType(rs.getInt("INVESTMENT_TYPE"));
                amOper.setDateDQ(rs.getLong("WIRING_DATE_DQ"));
                amOper.setAmount(rs.getBigDecimal("RUB_AMOUNT"));
                amOper.setCurrencyAmount(rs.getBigDecimal("CURRENCY_AMOUNT"));
                return amOper;
            }
        };

        return getJdbcTemplate().query(query, params, operMapper);
    }


    public List<? extends SSContractSummaryBean> getAums(String investorId, String contractId) {
        Map<String, Object> params = new HashMap<String, Object>();

        String query = "select * from " + SS + ".mv_ss_contract_summary2  ";

        if (investorId != null) {
            query +=  "where investor_id = :investor_id";
            params.put("investor_id", investorId);
        }
        if ((contractId != null) && (!contractId.equals(""))) {
            query +=  "where contract_id = :contract_id";
            params.put("contract_id", contractId);
        }

        RowMapper<SSContractSummaryBean> contractMapper = new RowMapper<SSContractSummaryBean>() {
            public SSContractSummaryBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                SSContractSummaryBean contractSummary = new SSContractSummaryBean();
                contractSummary.setInvestorId(rs.getString("INVESTOR_ID"));
                contractSummary.setContractId(rs.getString("CONTRACT_ID"));
                contractSummary.setInvestmentType(rs.getInt("INVESTMENT_TYPE"));
                contractSummary.setDate(rs.getDate("POSITION_DATE"));
                contractSummary.setDateDQ(rs.getLong("POSITION_DATE_DQ"));
                contractSummary.setAum(rs.getBigDecimal("AMOUNT_RUB"));
                contractSummary.setClosingAum(rs.getBigDecimal("CLOSE_AMOUNT_RUB"));
                return contractSummary;
            }
        };
        return getJdbcTemplate().query(query, params, contractMapper);
    }


    public List<? extends SSContractBean> getContract(String investorId, String contractId) {
        Map<String, Object> params = new HashMap<String, Object>();
        String query = "select contract.*, nvl(compose.blocked, 0) as is_blocked from ss.vie_ss_contract contract, SS_DATALINK.MV_COMPOSITE compose where contract.composite_id = compose.composite_id ";

        if ((investorId != null) && (!investorId.equals(""))) {
            query +=  " and investor_id = :investor_id";
            params.put("investor_id", investorId);
        }
        else
        if ((contractId != null) && (!contractId.equals(""))) {
            query +=  " and contract_id = :contract_id";
            params.put("contract_id", contractId);
        }
        else {
            throw new RuntimeException( "AMDaoImpl.getContract - параметры заданы неверно");
        }

        RowMapper<SSContractBean> contractMapper = new RowMapper<SSContractBean>() {
            public SSContractBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                SSContractBean contract = new SSContractBean();
                contract.setId(rs.getString("ID"));
                contract.setInvestorId(rs.getString("investor_id"));
                contract.setContractId(rs.getString("CONTRACT_ID"));
                contract.setOrgCode(rs.getString("org_code"));
                contract.setContractNumber(rs.getString("CONTRACT_NUMBER"));
                contract.setContractDate(rs.getDate("CONTRACT_DATE"));
                contract.setStrategyName(rs.getString("NAME"));

                contract.setInvestmentType(rs.getInt("investment_type"));
                contract.setAssetId(rs.getString("ASSET_ID"));
                contract.setCompositeId(rs.getString("COMPOSITE_ID"));
                contract.setReportPeriod(rs.getInt("periodicity"));
                contract.setStrategyMonths(rs.getInt("STRATEGY_MONTHS"));
                contract.setStepMonths(rs.getInt("STEP_MONTHS"));
                contract.setCoeffYield(rs.getBigDecimal("COEFF_YIELD"));
                contract.setCancelCondition(rs.getClob("CANCEL_CONDITION"));
                contract.setDisclaimer(rs.getClob("DISCLAIMER"));

                contract.setCurrencyCode(rs.getString("CURRENCY_CODE"));
                contract.setCurrencyName(rs.getString("CURRENCY_NAME"));
                contract.setBlocked(rs.getInt("is_blocked") == 1 ? true : false);
                return contract;
            }
        };

        return getJdbcTemplate().query(query, params, contractMapper);
    }


    public static void removePairsOutside(Map<Long, BigDecimal> pairs, Long min, Long max) {
        if (min == null || max == null) return;
        Set<Map.Entry<Long, BigDecimal>> set = pairs.entrySet();
        Iterator<Map.Entry<Long, BigDecimal>> i = set.iterator();
        while (i.hasNext()) {
            Map.Entry<Long, BigDecimal> e = i.next();
            if (e.getKey() < min - 1 || e.getKey() > max + 1) i.remove();
        }
    }


    public NamedParameterJdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        setJdbcTemplate(new NamedParameterJdbcTemplate(this.dataSource));
    }







}
