package ru.alfacapital.alphecca.services.legacy.data.dao;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import ru.alfacapital.alphecca.services.legacy.data.model.*;
import ru.alfacapital.alphecca.services.legacy.utils.Common;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;
import java.util.Date;

@Repository
public class SSDaoImpl {

    public static final String SS_DATALINK = "ss_datalink";

    private final static String QUERY13 = "insert into ss.tab_pending_contract (id, investor_id, application_number, composite_id, amount, status_name, PC_DATE) \n" +
            "values (ss.login_sequence.nextval, :investor_id, :application_number, :composite_id, :amount, :status_name, :date) ";

    private final static String QUERY14 = "insert into ss.TAB_PENDING_REQUEST (id, investor_id, application_number, fund_id, amount, status_name, PC_DATE) \n" +
            "values (ss.login_sequence.nextval, :investor_id, :application_number, :fund_id, :amount, :status_name, :date) ";

    private NamedParameterJdbcTemplate jdbcTemplate;

    public NamedParameterJdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        setJdbcTemplate(new NamedParameterJdbcTemplate(dataSource));
    }


    // todo удалить после внедрения покупок
    // возврящает информацию о клиенете необходимую для отправки уведомления инвестконсультанту о интересе клиента к какому либо продукту
    // используется в заглушке при покупке
    public Map<String, Object> getInvestorInfo(String investorId) {
        String sql = "select i.name, trim(i.CELL_PHONE) || '  ' || trim(i.CELL_PHONE_CRM) || '  ' || trim(i.CELL_PHONE_SS) as phone, i.EMAIL as email, u.FIRST_NAME || ' ' || u.LAST_NAME as consul_name, u.MAIL as consul_email from " +
                     "SS_DATALINK.MV_INVESTOR i join SS_DATALINK.MV_USER u on i.USER_ID = u.USER_ID " +
                     "where i.INVESTOR_ID = :investorId ";
        Map<String, Object> params = new HashMap<>();
        params.put("investorId", investorId);
        return jdbcTemplate.queryForMap(sql, params);
    }


    /**
     * Возвращает стоимость пая ПИФ на дату за период.
     * Даты определяются количеством дней прошедших с 01.01.2000.
     * Стоимости паев округлены до второго знака.
     *
     * @param fundId идентификатор фонда
     * @param min    первая дата периода
     * @param max    последняя дата периода
     * @return стоимости паёв ПИФ за период
     */

    public TreeMap<Long, BigDecimal> getShareValue(String fundId, long min, long max) {
        String query = "select NAV_DATE_DQ, SHARE_VALUE from ss.mv_fund_nav where FUND_ID = :FUND_ID and :min <= NAV_DATE_DQ and NAV_DATE_DQ <= :max";

        Map<String, Object> params = new HashMap<>();
        params.put("FUND_ID", fundId);
        params.put("min", min);
        params.put("max", max);

        final TreeMap<Long, BigDecimal> shareValues = new TreeMap<Long, BigDecimal>();

        RowMapper<String> mapper = new RowMapper<String>() {
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                BigDecimal sv = rs.getBigDecimal("SHARE_VALUE");
                if (sv == null) {
                    sv = BigDecimal.ZERO;
                } else {
                    sv = sv.setScale(2, BigDecimal.ROUND_HALF_UP);
                }
                shareValues.put(rs.getLong("NAV_DATE_DQ"), sv);
                return "";
            }
        };
        jdbcTemplate.query(query, params, mapper);
        return shareValues;
    }

    public SSInvestorBean getInvestor(String investorId) {
        Map<String, Object> params = new HashMap<>();
        params.put("investorId", investorId);
        String query = "select * from ss.vie_ss_investor where investor_id = :investorId";
        RowMapper<SSInvestorBean> investorMapper = new RowMapper<SSInvestorBean>() {
            public SSInvestorBean mapRow(ResultSet rs, int rowNum) throws SQLException {

                SSInvestorBean investor = new SSInvestorBean();
                investor.setInvestorId(rs.getString("INVESTOR_ID"));
                investor.setLoginId(rs.getString("LOGIN_ID"));
                investor.setUserId(rs.getString("USER_ID"));
                investor.setLogin(rs.getString("LOGIN"));
                investor.setName(rs.getString("NAME"));
                investor.setOverridedName(rs.getString("OVERRIDE_NAME"));
                investor.setLegalEntity(rs.getBoolean("LEGAL_ENTITY"));
                investor.setDocumentSeries(rs.getString("DOCUMENT_SERIES"));
                investor.setDocumentNumber(rs.getString("DOCUMENT_NUMBER"));

                investor.setBirthDate(rs.getDate("BIRTHDAY"));
                investor.setBirthplace(Common.nvl(rs.getString("BIRTHPLACE")).replace("\"", "\\\""));
                investor.setDocumentIssuer(Common.nvl(rs.getString("DOCUMENT_ISSUER")).replace("\"", "\\\""));
                investor.setDocumentIssuerCode(Common.nvl(rs.getString("DOCUMENT_ISSUER_CODE")).replace("\"", "\\\""));
                investor.setDocDate(rs.getDate("DOCUMENT_DATE"));
                investor.setInn(rs.getString("INN"));
                investor.setKpp(rs.getString("KPP"));
                investor.setRealAddress(Common.nvl(rs.getString("REAL_ADDRESS")).replace("\"", "\\\""));
                investor.setJureAddress(Common.nvl(rs.getString("JURE_ADDRESS")).replace("\"", "\\\""));

                investor.setGender(rs.getString("GENDER"));
                investor.setDocumentType(rs.getString("DOCUMENT_TYPE"));
                investor.setUsaCitizen(rs.getInt("USA_CITIZEN"));

                investor.setFundsCount(rs.getInt("NC_FUNDS"));
                investor.setAssetsCount(rs.getInt("NC_ASSETS"));
                investor.setMaxReportDate(rs.getDate("MAX_REPORT_DATE"));
                investor.setDocumentSeriesNumber(rs.getString("DOCUMENT_SERIES_NUMBER"));
                investor.setInvestorMail(rs.getString("INVESTOR_EMAIL"));
                investor.setInvestorCellPhone(rs.getString("INVESTOR_CELL_PHONE"));
                investor.setBlockDate(rs.getDate("BLOCK_DATE"));
                investor.setBlocked(rs.getBoolean("IS_BLOCKED"));
                investor.setRulesAcceptDate(rs.getDate("RULES_ACCEPT_DATE"));
                investor.setServiceClass(rs.getString("SERVICE_CLASS"));
                investor.setReportCurrencyId(rs.getString("REPORT_CURRENCY_ID"));
                investor.setMaxReportDateDQ(rs.getLong("MAX_REPORT_DATE_DQ"));
                return investor;
            }
        };
        return getJdbcTemplate().queryForObject(query, params, investorMapper);
    }

    public String getNextOrderNumber() {
        String query = "select ss.LOGIN_SEQUENCE.nextval as n from dual";
        Map<String, Object> params = new HashMap<>();
        RowMapper<String> mapper = new RowMapper<String>() {
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("n");
            }
        };
        return getJdbcTemplate().queryForObject(query, params, mapper);
    }

    public SSFundBean getFund(String fundId) {
        String query = "select f.fund_id, f.name, f.full_name, f.reg_number, f.reg_date, f.discount_id, f.alfabank_code, f.owner_recipient, f.bank_inn, \n" +
                "       f.bank_kpp, f.bank_recipient, f.bank_k_account, f.bank_bic, f.bank_r_account, f.recipient_okpo, f.recipient_ogrn, f.recipient_okato, \n" +
                "       f.recipient_okogu, f.recipient_okfs, f.recipient_okopf, f.recipient_okved from ss_datalink.mv_fund f where f.fund_id = :fund_id";

        Map<String, Object> params = new HashMap<>();
        params.put("fund_id", fundId);

        RowMapper<SSFundBean> mapper = new RowMapper<SSFundBean>() {
            public SSFundBean mapRow(ResultSet rs, int rowNum) throws SQLException {
                SSFundBean ssFundBean = new SSFundBean();
                ssFundBean.setId(rs.getString("fund_id"));
                ssFundBean.setName(rs.getString("name"));
                // эти поля есть в ДУ
                ssFundBean.setCurrencyFund("RUB");

                ssFundBean.setFundName(rs.getString("name"));
                ssFundBean.setFundNameFull(rs.getString("full_name"));
                ssFundBean.setOwnerRecipientFund(rs.getString("owner_recipient"));
                ssFundBean.setBankInnFund(rs.getString("bank_inn"));
                ssFundBean.setBankKppFund(rs.getString("bank_kpp"));
                ssFundBean.setBankRecipientFund(rs.getString("bank_recipient"));
                ssFundBean.setBankKAccountFund(rs.getString("bank_k_account"));
                ssFundBean.setBankRAccountFund(rs.getString("bank_r_account"));
                ssFundBean.setBankBicFund(rs.getString("bank_bic"));
                ssFundBean.setOkpo(rs.getString("recipient_okpo"));
                ssFundBean.setOgrn(rs.getString("recipient_ogrn"));
                ssFundBean.setOkato(rs.getString("recipient_okato"));
                ssFundBean.setOkogu(rs.getString("recipient_okogu"));
                ssFundBean.setOkfs(rs.getString("recipient_okfs"));
                ssFundBean.setOkopf(rs.getString("recipient_okopf"));
                ssFundBean.setOkvd(rs.getString("recipient_okved"));


                // todo: следующих полей вообще нет в БД

                // Р/c  // какойто второй непонятной счет  4070 1810 9027 5000 0386 (вместо счета 40702810100000007490 — закрыт) в ОАО «АЛЬФА-БАНК» г. Москва
                // ssFundBean.setBankRAccountFund2("4070 1810 9027 5000 0386 (вместо счета 40702810100000007490 — закрыт) в ОАО «АЛЬФА-БАНК» г. Москва");
                //код фонда из ЭДО отсутствует в  ss_datalink.mv_fund
                //ssFundBean.setFundCode("ACAR");

                return ssFundBean;
            }
        };
        return getJdbcTemplate().queryForObject(query, params, mapper);
    }

    public BigDecimal getCalcRate(String currencyCode, Long dateDq) {
        String sql = "select cr.rate_to_rub from ss_datalink.mv_currency_rate cr \n" +
                "join ss_datalink.mv_currency c on c.currency_id = cr.currency_id \n" +
                "where c.iso_alpha3 = :currencyCode and  cr.rate_date_dq = :dateDq";

        Map<String, Object> params = new HashMap<>();
        params.put("currencyCode", currencyCode);
        params.put("dateDq", dateDq);
        return getJdbcTemplate().queryForObject(sql, params, BigDecimal.class);
    }

    public void addPendingContract(String investorId, String appNum, String compositeId, String amount, String statusName, Date date) {
        Map<String, Object> params = new HashMap<>();
        params.put("investor_id", investorId);
        params.put("application_number", appNum);
        params.put("composite_id", compositeId);
        params.put("status_name", statusName);
        params.put("amount", amount);
        params.put("date", date);
        jdbcTemplate.update(QUERY13, params);
    }

    public void addPendingRequest(String investorId, String appNum, String fundId, String amount, String statusName, Date date) {
        Map<String, Object> params = new HashMap<>();
        params.put("investor_id", investorId);
        params.put("application_number", appNum);
        params.put("fund_id", fundId);
        params.put("status_name", statusName);
        params.put("amount", amount);
        params.put("date", date);
        jdbcTemplate.update(QUERY14, params);
    }


    public Map<String, Object> getStrategy(String strategyId) {
        String sql = "select c.sys_name, c.name, nvl(c.blocked, 1) is_blocked, " +
                    "CASE NVL(c.min_amount_ak, 0) when 0 then c.min_amount else c.min_amount_ak end as min_amount, " +
                    "cur.iso_alpha3 currency_code, c.strategy_months " +
                    "from ss_datalink.mv_composite c, ss_datalink.mv_currency cur " +
                    "where c.currency_id = cur.currency_id and c.composite_id = :strategyId";
        Map<String, Object> params = new HashMap<>();
        params.put("strategyId", strategyId);
        return jdbcTemplate.queryForMap(sql, params);
    }

    public Map<String, Object> getFundForBuy(String fundId) {
        String sql = "SELECT CODE as sys_name,  NAME, CASE when (ALFABANK_CODE is NULL) then 1 else 0 end as is_blocked, 'RUB' as currency_code, 0 as strategy_months, min_amount_ak as min_amount  FROM SS_DATALINK.MV_FUND where FUND_ID = :fundId";
        Map<String, Object> params = new HashMap<>();
        params.put("fundId", fundId);
        return jdbcTemplate.queryForMap(sql, params);
    }

    public boolean checkRuleAllowed(String investorId) {
        if (StringUtils.isEmpty(investorId)) {
            return false;
        }
        String query = "SELECT count(*) FROM SS.TAB_LOGIN_EXT e, SS.TAB_LOGIN l \n" +
                "where e.RULES_2V_ACCEPT_DATE is not null\n" +
                "and l.LOGIN_ID = e.LOGIN_ID\n" +
                "and l.INVESTOR_ID = :investorId";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("investorId", investorId);
        return getJdbcTemplate().queryForObject(query, params, Integer.class).intValue() == 1;
    }

    public Map<String, Object> getAcceptedRules(String investorId) {
        // если инвестор не передан возвращаем результат с флагом отсутствия правил
        if (StringUtils.isEmpty(investorId)) {
            investorId = "-1";
        }
        String sql = "SELECT rules_edf_code, rules_pers_code, ruleV1, ruleV2, typeResult FROM (\n" +
                    "  SELECT rules_edf_code, rules_pers_code, ruleV1, ruleV2, typeResult  FROM (\n" +
                    "        SELECT e.rules_edf_code as rules_edf_code, e.rules_pers_code as rules_pers_code, TO_CHAR(e.RULES_ACCEPT_DATE, 'DD.MM.YYYY') as ruleV1, TO_CHAR(e.RULES_2V_ACCEPT_DATE, 'DD.MM.YYYY') as ruleV2, 1 as typeResult\n" +
                    "        FROM SS.TAB_LOGIN_EXT e, SS.TAB_LOGIN l\n" +
                    "        WHERE l.LOGIN_ID = e.LOGIN_ID\n" +
                    "        AND l.INVESTOR_ID = :investorId\n" +
                    "      UNION ALL\n" +
                    "        SELECT '' as rules_edf_code,'' as rules_pers_code, '' as ruleV1, '' as ruleV2, 2 as type_result FROM DUAL)\n" +
                    "    order by typeResult \n" +
                    "  )\n" +
                    "WHERE rownum < 2";
        Map<String, Object> params = new HashMap<>();
        params.put("investorId", investorId);
        return jdbcTemplate.queryForMap(sql, params);
    }

    public void setRuleAllowed(String investorId) {
        Map<String, Object> params = new HashMap<>();
        if (StringUtils.isEmpty(investorId)) {
            return;
        }
        String query = "update SS.TAB_LOGIN_EXT\n" +
                       "set RULES_2V_ACCEPT_DATE = sysdate, RULES_ACCEPT_DATE = sysdate \n" +
                       "where RULES_2V_ACCEPT_DATE is null\n" +
                        "and LOGIN_ID = (select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId)";
        params.put("investorId", investorId);
        int cnt = jdbcTemplate.update(query, params);
        if (cnt == 0) {
            query = "INSERT INTO SS.TAB_LOGIN_EXT (LOGIN_ID,RULES_ACCEPT_DATE,RULES_2V_ACCEPT_DATE)\n" +
                            "VALUES\n" +
                            "((select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId),sysdate,sysdate)";
            jdbcTemplate.update(query, params);
        }
    }

    public void acceptRulesEdf(String investorId, String smsCode) {
        if (StringUtils.isEmpty(investorId)) {
            return;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("investorId", investorId);
        params.put("smsCode", smsCode);
        String query = "update SS.TAB_LOGIN_EXT\n" +
                "set RULES_EDF_CODE = :smsCode \n" +
                "where RULES_EDF_CODE is null\n" +
                "and LOGIN_ID = (select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId)";

        int cnt = jdbcTemplate.update(query, params);
        if (cnt == 0) {
            query = "INSERT INTO SS.TAB_LOGIN_EXT (LOGIN_ID,RULES_ACCEPT_DATE,RULES_2V_ACCEPT_DATE,RULES_EDF_CODE)\n" +
                    "VALUES\n" +
                    "((select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId),sysdate,sysdate, :smsCode)";
            jdbcTemplate.update(query, params);
        }
    }

    public void acceptRulesPers(String investorId, String smsCode) {
        if (StringUtils.isEmpty(investorId)) {
            return;
        }
        Map<String, Object> params = new HashMap<>();
        params.put("investorId", investorId);
        params.put("smsCode", smsCode);
        String query = "update SS.TAB_LOGIN_EXT\n" +
                "set RULES_PERS_CODE = :smsCode \n" +
                "where RULES_PERS_CODE is null\n" +
                "and LOGIN_ID = (select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId)";

        int cnt = jdbcTemplate.update(query, params);
        if (cnt == 0) {
            query = "INSERT INTO SS.TAB_LOGIN_EXT (LOGIN_ID,RULES_ACCEPT_DATE,RULES_2V_ACCEPT_DATE,RULES_PERS_CODE)\n" +
                    "VALUES\n" +
                    "((select LOGIN_ID from SS.TAB_LOGIN where INVESTOR_ID = :investorId),sysdate,sysdate, :smsCode)";
            jdbcTemplate.update(query, params);
        }
    }



}
