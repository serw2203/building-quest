package ru.alfacapital.alphecca.services.legacy;

import ru.alfacapital.alphecca.services.legacy.data.model.SSConstants;
import ru.alfacapital.alphecca.services.legacy.logic.InvestmentResult;
import ru.alfacapital.alphecca.services.legacy.logic.InvestmentResultGenerator;
import ru.ingie.commons.BigDecimals;
import ru.ingie.commons.DateUtils2;

import java.math.BigDecimal;
import java.util.*;

/**
 * Ответ на запрос об истории владения портфелями ДУ и их исторической стоимости.<br/>
 * <br/>
 * Фолио так же является портфелем ДУ.
 * Данный объект инкапсулирует всю информацию необходимую для того чтобы построить любую
 * отчетность по истории ДУ для одного пайшика.
 *
 * Все даты определяются количеством дней прошедших с 01.01.2000.
 *
 * Все суммы приводятся в рублях по ЦБ РФ на дату.
 */
public class AMResponse {

    /**
     * Тело операций вводов-выводов
     */
    public static class Oper {
        public BigDecimal amount;
        public BigDecimal currencyAmount;
    }

    /** Названия портфелей */
    public Map<String, String> names = new HashMap<String, String>();

    /** УК в договорах */
    public Map<String, String> orgs = new HashMap<String, String>();

    /** Номера договоров */
    public Map<String, String> contractNumbers = new HashMap<String, String>();

    /** Даты договоров */
    public Map<String, java.sql.Date> contractDates = new HashMap<String, java.sql.Date>();

    /** id стратегий */
    public Map<String, String> strategyids = new HashMap<String, String>();

    /** Названия стратегий */
    public Map<String, String> strategies = new HashMap<String, String>();

    /** Валюты стратегий для АП */
    public Map<String, String> strategyCurrencies = new HashMap<String, String>();

    /** Возможность drill-down до позиций по договору */
    public Map<String, Integer> drilldown = new HashMap<String, Integer>();

    /** Данный договор является портфелем Альфа-Профит, для него требуется специальное отображение */
    public Map<String, Integer> alfaprofit = new HashMap<String, Integer>();

    /** Стратегия данного договора доступна для оформления нового договора */
    public Map<String, Boolean> blocked = new HashMap<String, Boolean>();

    /** Даты начала инвестирования */
    public Map<String, Long> minDates = new HashMap<String, Long>();

    /** Последние дни владения (или сегодня) */
    public Map<String, Long> maxDates = new HashMap<String, Long>();

    /** Исторические стоимости портфелей (от начала даты владения до окончания владения) */
    public Map<String, TreeMap<Long, BigDecimal>> navs = new HashMap<String, TreeMap<Long, BigDecimal>>(); // contract_id -> date_dq -> nav

    /** Исторические (ликвидационные) стоимости портфелей (от начала даты владения до окончания владения) */
    public Map<String, TreeMap<Long, BigDecimal>> infoNavs = new HashMap<String, TreeMap<Long, BigDecimal>>(); // contract_id -> date_dq -> nav

    /** Все операции по портфелям (вводы-выводы). */
    public Map<String, Map<Long, Oper>> opers = new HashMap<String, Map<Long, Oper>>(); // contract_id -> date -> oper (amount (signed))

    /**
     * Полная очистка.
     */
    public void clear() {
        names.clear();
        orgs.clear();
        contractNumbers.clear();
        contractDates.clear();
        strategies.clear();
        strategyCurrencies.clear();
        drilldown.clear();
        alfaprofit.clear();
        blocked.clear();
        navs.clear();
        infoNavs.clear();
        opers.clear();
        minDates.clear();
        maxDates.clear();
    }

    /**
     * Стирание информации о конкретном договоре
     *
     * @param contractId идентификатор договора
     */
    public void clear(String contractId) {
        names.remove(contractId);
        orgs.remove(contractId);
        contractNumbers.remove(contractId);
        contractDates.remove(contractId);
        strategies.remove(contractId);
        strategyCurrencies.remove(contractId);
        drilldown.remove(contractId);
        alfaprofit.remove(contractId);
        blocked.remove(contractId);
        navs.remove(contractId);
        infoNavs.remove(contractId);
        opers.remove(contractId);
        minDates.remove(contractId);
        maxDates.remove(contractId);
    }

    public void clearOrgContracts(String orgCode) {
        List<String> toRemove = new ArrayList<String>();
        for (Map.Entry<String, String> e : orgs.entrySet()) {
            if (e.getValue().equals(orgCode)) {
                toRemove.add(e.getKey());
            }
        }
        for (String cid : toRemove) {
            clear(cid);
        }
    }


    public InvestmentResultGenerator asInvestmentResultGenerator(final String contractId, final String currencyCode, final CurrencyRater currencyRater) {
        return new InvestmentResultGenerator() {
            @Override
            public InvestmentResult getInvestmentResultForPeriod(Date start, Date stop) {
                Date yearStart = DateUtils2.truncateToYear(stop);
                Long yearStartDQ = SSConstants.toDQ(yearStart);
                Long startDQ = SSConstants.toDQ(start);
                Long stopDQ = SSConstants.toDQ(stop);

                Map<Long, Oper> opers = AMResponse.this.opers.get(contractId);
                if (opers == null) {
                    opers = new HashMap<>();
                }

                // Именно navs, содержит скорректированные оценки, например, в случае АП.
                TreeMap<Long, BigDecimal> navs = AMResponse.this.navs.get(contractId);
                if (navs == null) {
                    navs = new TreeMap<>();
                }

                Long minDate = AMResponse.this.minDates.get(contractId);
                if (minDate == null) {
                    minDate = startDQ;
                }

                if (minDate >= yearStartDQ) {
                    yearStartDQ = minDate;
                }

                Map<Long, BigDecimal> solidNavs = new HashMap<>(navs.size());
                solidNavs.put(minDate - 1, BigDecimal.ZERO);
                solidNavs.put(startDQ - 1, BigDecimal.ZERO);
                for (Map.Entry<Long, BigDecimal> e : navs.entrySet()) {
                    solidNavs.put(e.getKey(), SSConstants.rate(currencyRater, e.getValue(), currencyCode, e.getKey()));
                }
                Returns.fillGaps(solidNavs);

                BigDecimal inflow = BigDecimal.ZERO;
                BigDecimal outflow = BigDecimal.ZERO;
                BigDecimal yearInflow = BigDecimal.ZERO;
                BigDecimal yearOutflow = BigDecimal.ZERO;
                BigDecimal totalInflow = BigDecimal.ZERO;
                BigDecimal totalOutflow = BigDecimal.ZERO;

                Map<Long, BigDecimal> opersByDates = new HashMap<Long, BigDecimal>();

                List<BigDecimal> periodOperations = new ArrayList<>();
                List<BigDecimal> yearOperations = new ArrayList<>();

                List<Long> operDatesDQ = new ArrayList<Long>(opers.keySet());
                Collections.sort(operDatesDQ);
                for (Long dateDQ : operDatesDQ) {
                    if (dateDQ <= stopDQ) {
                        Oper operation = opers.get(dateDQ);
                        BigDecimal operationAmount = SSConstants.rate(currencyRater, operation.amount, currencyCode, dateDQ);

                        if (dateDQ >= startDQ) {
                            // операция случившаяся в первый день периода учавствует в расчете доходности.
                            periodOperations.add(operationAmount);
                        }

                        if (dateDQ >= yearStartDQ) {
                            // операция случившаяся в первый день периода учавствует в расчете доходности.
                            yearOperations.add(operationAmount);
                        }

                        // операция случившаяся в последний день периода считается операцией внутри периода
                        // оценка на конец периода это оценка на конец дня
                        opersByDates.put(dateDQ, operationAmount);

                        if (operationAmount.compareTo(BigDecimal.ZERO) > 0) {
                            // ввод
                            totalInflow = totalInflow.add(operationAmount);
                            if (dateDQ >= yearStartDQ) {
                                yearInflow = yearInflow.add(operationAmount);
                            }
                            if (dateDQ >= startDQ) {
                                inflow = inflow.add(operationAmount);
                            }
                        }
                        else {
                            // вывод
                            totalOutflow = totalOutflow.add(operationAmount.negate());
                            if (dateDQ >= yearStartDQ) {
                                yearOutflow = yearOutflow.add(operationAmount.negate());
                            }
                            if (dateDQ >= startDQ) {
                                outflow = outflow.add(operationAmount.negate());
                            }
                        }
                    }
                    else {
                        break;
                    }
                }

                BigDecimal firstAum = BigDecimal.ZERO;
                // количество и оценка на начало это оценки на начало дня, т.е. на конец предыдущего
                Map.Entry<Long, BigDecimal> test = navs.floorEntry(startDQ - 1);
                if (test != null) {
                    firstAum = SSConstants.rate(currencyRater, test.getValue(), currencyCode, startDQ - 1);
                }

                BigDecimal yearFirstAum = BigDecimal.ZERO;
                // количество и оценка на начало это оценки на начало дня, т.е. на конец предыдущего
                test = navs.floorEntry(yearStartDQ - 1);
                if (test != null) {
                    yearFirstAum = SSConstants.rate(currencyRater, test.getValue(), currencyCode, yearStartDQ - 1);
                }

                BigDecimal lastAum = BigDecimal.ZERO;
                test = navs.floorEntry(stopDQ);
                if (test != null) {
                    lastAum = SSConstants.rate(currencyRater, test.getValue(), currencyCode, stopDQ);
                }

                BigDecimal yield;
                {   // за период
                    yield = Returns.modifiedDietz(startDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yield != null) {
                        yield = yield.multiply(BigDecimals.BD100);
                        if (yield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yield = BigDecimal.ZERO;
                        }
                    }
                }

                BigDecimal yearYield;
                {   // с начала инвестирования
                    yearYield = Returns.modifiedDietz(yearStartDQ, stopDQ, opersByDates, solidNavs, 4);
                    if (yearYield != null) {
                        yearYield = yearYield.multiply(BigDecimals.BD100);
                        if (yearYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            yearYield = BigDecimal.ZERO;
                        }
                    }
                }

                BigDecimal totalYield;
                {   // с начала инвестирования
                    totalYield = Returns.modifiedDietz(minDate, stopDQ, opersByDates, solidNavs, 4);
                    if (totalYield != null) {
                        totalYield = totalYield.multiply(BigDecimals.BD100);
                        if (totalYield.abs().compareTo(BigDecimals.BD100) >= 0) {
                            totalYield = BigDecimal.ZERO;
                        }
                    }
                }

                // проверка на активность
                if (firstAum.compareTo(BigDecimal.ZERO) == 0
                        && yearFirstAum.compareTo(BigDecimal.ZERO) == 0
                        && lastAum.compareTo(BigDecimal.ZERO) == 0
                        && periodOperations.isEmpty()
                        && yearOperations.isEmpty()) {
                    return null;
                }
                else {
                    return new InvestmentResult(currencyCode, firstAum, yearFirstAum, BigDecimal.ZERO, BigDecimal.ZERO, lastAum, inflow, outflow, yield, yearInflow, yearOutflow, yearYield, totalInflow, totalOutflow, totalYield, minDate, opersByDates, solidNavs);
                }
            }
        };
    }
    
}
