package ru.alfacapital.alphecca.services.legacy.data.model;

import ru.ingie.commons.Comparators;

import java.math.BigDecimal;
import java.util.*;

/**
 * Позиция.
 *
 * Разложение по всем возможным для выбора размерностям.
 */
public class ExposedPosition {

    private static Comparator<Map.Entry<String, BigDecimal>> entryComparator = Comparators.createNullsLast(new Comparator<Map.Entry<String, BigDecimal>>() {
        @Override
        public int compare(Map.Entry<String, BigDecimal> o1, Map.Entry<String, BigDecimal> o2) {
            return -Comparators.compareToNullsLast(o1.getValue(), o2.getValue());
        }
    });

    /**
     * Относит все позиции по эмитенту в раздел Другие (-1) кроме N топовых.
     *
     * @param count N
     */
    public void maskIssuers(int count) {
        Map<String, BigDecimal> map = new HashMap<String, BigDecimal>();
        for (PositionLine pl : lines) {
            BigDecimal was = map.get(pl.issuerId);
            if (was == null) was = BigDecimal.ZERO;
            map.put(pl.issuerId, was.add(pl.value));
        }
        List<Map.Entry<String, BigDecimal>> list = new ArrayList<Map.Entry<String, BigDecimal>>(map.entrySet());
        Collections.sort(list, entryComparator);
        if (list.size() > count) {
            Set<String> set = new HashSet<String>();
            for (int i = 0; i < count; i++) {
                set.add(list.get(i).getKey());
            }
            for (PositionLine pl : lines) {
                if (!set.contains(pl.issuerId)) {
                    pl.issuerId = "-1";
                }
            }
        }
    }

    public static class PositionLine {
        public String currencyCode;
        public String assetClassId; // класс базового инструмента
        public String topAssetClassId; // класс инструмента в портфеле
        public String territoryId;
        public String countryId;
        public String issuerId;
        public String industryId;
        public BigDecimal value;
    }

    public List<PositionLine> lines = new ArrayList<>();

}
