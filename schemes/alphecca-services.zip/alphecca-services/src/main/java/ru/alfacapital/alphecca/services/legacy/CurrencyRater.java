package ru.alfacapital.alphecca.services.legacy;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Конвертор валюты, в произвольную.
 */
public interface CurrencyRater {

    /**
     * Исключительна ситуация в случае отсутствия курса на дату.
     */
    class NoRateException extends RuntimeException {}

    /**
     * Конвертировать.
     *
     * @param value сумма в валюте конвертере
     * @param currencyCodeToConvert целевая валюта
     * @param date дата
     * @return сумма в целевой валюте
     */
    BigDecimal rate(BigDecimal value, String currencyCodeToConvert, Date date) throws NoRateException;

    BigDecimal rate(BigDecimal value, String sourceCurrency, String targetCurrency, Date date) throws NoRateException;

}
