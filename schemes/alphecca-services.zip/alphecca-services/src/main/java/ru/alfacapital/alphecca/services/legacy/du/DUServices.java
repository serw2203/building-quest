package ru.alfacapital.alphecca.services.legacy.du;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.alfacapital.alphecca.services.legacy.KladrAddress;
import ru.alfacapital.alphecca.services.legacy.ProjectProperty;
import ru.alfacapital.alphecca.services.legacy.data.dao.SSDaoImpl;
import ru.alfacapital.alphecca.services.legacy.data.model.SSInvestorBean;
import ru.alfacapital.alphecca.services.legacy.utils.Common;
import ru.alfacapital.alphecca.services.rest.RuleController;
import ru.alfacapital.definitions.services.ContractRegistrationService;
import ru.alfacapital.definitions.services.ServiceFault;
import ru.alfacapital.schemas.common.AddressType;
import ru.alfacapital.schemas.common.DocumentType;
import ru.alfacapital.schemas.common.PaymentInfoType;
import ru.alfacapital.schemas.survey.SurveyRequest;
import ru.alfacapital.schemas.survey.SurveyResponse;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Map;

@Service
public class DUServices {

    private static Logger logger = LoggerFactory.getLogger(DUServices.class);

    public static final String CODE_BUY = "01";
    public static final String CODE_SELL = "02";
    public static final String CODE_EXCH = "03";   // Обмен
    public static final String CODE_CHANGE = "04"; // ИАД // Заявка на изменение анкетных данных
    public static final String CODE_CONVERT = "05"; // Артефакт - конвертация
    public static final String CODE_CREATE = "06"; // Открытие ЛС

    public static final String FUND_PRODUCT = "mf";
    public static final String AM_PRODUCT = "ap";

    public static final SimpleDateFormat ALFA_CLICK_DATE_FORMATER = new SimpleDateFormat("MMM d, yyyy HH:mm:ss a", Locale.US);
    public static final SimpleDateFormat DATE_FORMATER = new SimpleDateFormat("dd.MM.yyyy", Locale.US);

    public static final String LOGIN_LK = "LK";
    public static final String LOGIN_INTERNET = "INTERNET";

    public enum DUStatus {
        CONTRACT_IN_SYSTEM,         // Введен в систему
        CONTRACT_CHECK_OPP,         // Проверен ОПП
        CONTRACT_EDITING,           // Начальный ввод
        CONTRACT_SIGNED,            // Договор подписан
        ORDER_OUTPUT,               // Распоряжение на вывод
        CONTRACT_CLOSED,            // Закрыт
        REQUEST_INPUTED,            // Редактируется
        REQUEST_CHECKED_UK,         // Проверена УК
        REQUEST_REJECTED_UK,        // Отклонена УК
        REQUEST_SENDED_REGISTRAR,   // Отправлена регистратору
        REQUEST_REJECTED_REGISTRAR, // Отклонена регистратором
        REQUEST_COMPLETED,          // Исполнена
        CONTRACT_REJECTED_OPP,      // Отклонен ОПП
        CONTRACT_REJECTED_BACKOFFICE,   // Отклонен бэк-офисом
        CONTRACT_REJECTED_DVK,      // Отклонен ДВК
        REQUEST_SIGNED,             // Подписана
        CONTRACT_ORIGINAL_RECEIVED, // Оригинал получен
        ORDER_OUTPUT_SIGNED,        // Распоряжение на вывод подписано
        REQUEST_REMOVED,            // Удалена
        CONTRACT_REJECTED_CLIENT,   // Отказ клиента
        REQUEST_FOR_SENDED,         // Для отправки регистратору
        CONTRACT_REJECTED_CALLCENTR,    // Отклонен КЦ
    }

    // todo: Это адрес сервисов, которые не закрыты сертификатом. И мы продолжаем их вызывать, они пишут в боевую БД
    // todo: Вместо этого нужно вызывать боевые сервисы на my.alfacapital.ru
    public static final String SERVICE_URL = "http://bro-ln-srv110:8080/du/services/ContractRegistrationService";

    //public static final String SERVICE_URL = "http://localhost:8081/du/services/ContractRegistrationService";

    public static class DUResponse {
        private String number;
        private java.util.Date date;

        public DUResponse() {}

        public DUResponse(String number, java.util.Date date) {
            this.number = number;
            this.date = date;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public java.util.Date getDate() {
            return date;
        }

        public void setDate(java.util.Date date) {
            this.date = date;
        }
    }

    @Autowired
    private SSDaoImpl investorDao;

    @Autowired
    private SSDaoImpl ssDao;

    @Autowired
    RuleController rule;

    public SurveyResponse sendProductToDU(SurveyRequest request) {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(ContractRegistrationService.class);
        String edfServicesAddress = System.getProperty("alphecca.edf.services");
        if (edfServicesAddress == null) {
            edfServicesAddress = SERVICE_URL;
        }
        factory.setAddress(edfServicesAddress);
        LoggingInInterceptor in = new LoggingInInterceptor();
        in.setPrettyLogging(true);
        LoggingOutInterceptor out = new LoggingOutInterceptor();
        out.setPrettyLogging(true);
        factory.getInInterceptors().add(in);
        factory.getOutInterceptors().add(out);

        ContractRegistrationService port = (ContractRegistrationService) factory.create();
        if (ProjectProperty.sendMagicEmail()) {
            request.setEmail(ProjectProperty.getMagicEmail());
        }
        try {
            SurveyResponse surveyResponse = port.putSurvey(request);
            return surveyResponse;
        } catch (ServiceFault serviceFault) {
            throw new RuntimeException("Ошибка при отправке запроса для регистрации заявки.", serviceFault);
        }
    }


    public String translateCodeFund(String code) {
        try {
            if (Integer.valueOf(code) < 10) {
                return "0" + Integer.valueOf(code).toString();
            }
            return Integer.valueOf(code).toString();
        } catch(Exception e) {
            return code + " номер фонда не распознан";
        }

    }

    public String sendFundToDuAclick(String investorId, String fundId, Map<String, Object> alfaClickUser, String sign) {
        SSInvestorBean investor;
        if (StringUtils.isEmpty(investorId)) {
            investor = new SSInvestorBean();
        } else {
            investor = investorDao.getInvestor(investorId);
        }
        mergeInvestor(investor, alfaClickUser);
        return sendFundToDU(investor,
                fundId,
                sign,
                CODE_BUY,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                "",
                (String)alfaClickUser.get("BIC"),
                (String)alfaClickUser.get("bankName"),
                (String)alfaClickUser.get("ksn"),
                (String)alfaClickUser.get("account"),
                "",
                "",
                LOGIN_LK).number;
    }


    public DUResponse sendFundToDU(String investorId,
                               String fundId,
                               String sign,
                               String actionCode,
                               BigDecimal amount,
                               BigDecimal productAmount,
                               String fundIdSwap,
                               String bic,
                               String bankName,
                               String cr,
                               String pr,
                               String personalAccount,
                               String personalAccountSwap,
                               String loginEmp) {
        SSInvestorBean investor = investorDao.getInvestor(investorId);
        return sendFundToDU(investor, fundId, sign, actionCode, amount, productAmount, fundIdSwap, bic, bankName, cr, pr, personalAccount, personalAccountSwap, loginEmp);
    }

    private DUResponse sendFundToDU(SSInvestorBean investor,
                               String fundId,
                               String sign,
                               String actionCode,
                               BigDecimal amount,
                               BigDecimal productAmount,
                               String fundIdSwap,
                               String bic,
                               String bankName,
                               String cr,
                               String pr,
                               String personalAccount,
                               String personalAccountSwap,
                               String loginEmp) {

        Map<String, Object> fund = investorDao.getFundForBuy(fundId);

        if (!fundId.equals("2867829943")) {
            logger.error("fundId != 2867829943");
            throw new RuntimeException("Операция доступна только для фонда Еврооблигации");
        }

        if (!ProjectProperty.buyAccept()) {
            logger.error("Операция покупки через приложение запрещена");
            throw new RuntimeException("Операция покупки через приложение запрещена");
        }

        if ((fund == null) || (investor == null)) {
            logger.error("Некорректно определен инвестор или фонд");
            throw new RuntimeException("Некорректно определены : " + (fund == null ? "фонд, " : "") +
                    (investor == null ? "инвестор, " : "")
            );
        }
        String fundCode = (String)fund.get("sys_name");
        if ((fundCode == null) || fundCode.isEmpty()) {
            logger.error("Фонд не найден");
            throw new RuntimeException("Фонд не найден");
        }
        String fundSwap = "";
        if ((fundIdSwap != null) && !fundIdSwap.isEmpty()) {
            try {
                fundSwap = (String) investorDao.getFundForBuy(fundIdSwap).get("sys_name");

                // нас не интересует почему не найден фонд, фонд не найден и мы это сообщаем
            } catch(Exception ex) {
                throw new RuntimeException("Фонд для обмена не найден");
            }
            if ((fundCode == null) || fundCode.isEmpty()) {
                throw new RuntimeException("Фонд для обмена не найден");
            }
        }

        boolean isBlocked = ((BigDecimal) fund.get("is_blocked")).compareTo(BigDecimal.ZERO) != 0;
        //BigDecimal minAmount = (BigDecimal) strategy.get("min_amount");
        String currencyCode = (String) fund.get("currency_code");

        if (isBlocked) {
            logger.error("Указанный Вами фонд заблокирован");
            throw new RuntimeException("Указанный Вами фонд заблокирован");
        }
        if ((investor.getName() == null) || (investor.getName().length() == 0)) {
            logger.error("Неверное имя инвестора");
            throw new RuntimeException("Неверное имя");
        }
//        if ((investor.getInvestorMail() == null) || (investor.getInvestorMail().length() == 0)) {
//            throw new RuntimeException("Неверный email");
//        }
        if ((investor.getInvestorCellPhone() == null) || (investor.getInvestorCellPhone().length() < 5)) {
            logger.error("Неверный телефон инвестора");
            throw new RuntimeException("Неверный телефон");
        }
        if ((investor.getDocDate() == null) ||
                (investor.getDocumentSeries() == null) || (investor.getDocumentSeries().length() == 0) ||
                (investor.getDocumentNumber() == null) || (investor.getDocumentNumber().length() == 0) ||
                (investor.getDocumentIssuer() == null) || (investor.getDocumentIssuer().length() == 0) /*||
                (investor.getDocumentIssuerCode() == null) || (investor.getDocumentIssuerCode().length() == 0)*/) {
            logger.error("Неверные паспортные данные:" + investor);
            throw new RuntimeException("Неверные паспортные данные");
        }

        SurveyRequest surveyRequest = new SurveyRequest();
        setInvestorData(surveyRequest, investor);
        // адрес по кладру
        surveyRequest.setPostAddress        (kladrToAddressType(new KladrAddress(investor.getRealAddress())));
        surveyRequest.setRegistrationAddress(kladrToAddressType(new KladrAddress(investor.getJureAddress())));

        surveyRequest.setLogin(loginEmp);
        surveyRequest.setProduct(FUND_PRODUCT);
        surveyRequest.setQuery(actionCode);

        surveyRequest.setCurrencyCode(currencyCode);
        surveyRequest.setAmount(amount.setScale(4, RoundingMode.CEILING));
        // переделать сервис чтобы он работал с BigDecimal
        surveyRequest.setProductAmount(productAmount.setScale(4, RoundingMode.CEILING).doubleValue());
        surveyRequest.setSign(sign);
        surveyRequest.setProductId(translateCodeFund(fundCode));

        if ((fundSwap != null) || (fundIdSwap.isEmpty())) {
            surveyRequest.setProductSwapId(translateCodeFund(fundSwap));
        }

        surveyRequest.setPersonalAccount(personalAccount.replace("empty", "").replace("undefined", ""));
        surveyRequest.setPersonalAccountSwap(personalAccountSwap.replace("empty", "").replace("undefined", ""));

        PaymentInfoType p = new PaymentInfoType();
        p.setBankBik(bic);
        p.setBankName(bankName);
        p.setCorrespondentAccount(cr);
        p.setPersonalAccount(pr);
        surveyRequest.setPaymentInfo(p);

        // установка итогового статуса // только если разрешено подписывать
        if (ProjectProperty.buyAndOpen()) {
            surveyRequest.setStatus(DUStatus.CONTRACT_EDITING.toString());
        } else if (ProjectProperty.buyAndSign()) {
            surveyRequest.setStatus(DUStatus.REQUEST_SIGNED.toString());
        }

        SurveyResponse surveyResponse = sendProductToDU(surveyRequest);
        if (StringUtils.isNotEmpty(investor.getInvestorId())) {
            investorDao.addPendingRequest(investor.getInvestorId(), surveyResponse.getAppNum(), fundId, amount.toString(), actionCode, surveyResponse.getDate().toGregorianCalendar().getTime());
        }
        return new DUResponse(surveyResponse.getAppNum(), surveyResponse.getDate().toGregorianCalendar().getTime());
    }

    public void mergeInvestorHumanize(SSInvestorBean investor, Map<String, Object> alfaClickUser) {
        mergeInvestor(investor, alfaClickUser, true);
    }

    public void mergeInvestor(SSInvestorBean investor, Map<String, Object> alfaClickUser) {
        mergeInvestor(investor, alfaClickUser, false);
    }

    // слияние инвестора данные alfaClickUser приоритетные
    private void mergeInvestor(SSInvestorBean investor, Map<String, Object> alfaClickUser, boolean jsonView) {
        // "lastName"
        // "firstName"
        // "patronymicName"
        if (!StringUtils.isEmpty((String) alfaClickUser.get("lastName")) ||
            !StringUtils.isEmpty((String) alfaClickUser.get("firstName")) ||
            !StringUtils.isEmpty((String)alfaClickUser.get("patronymicName"))) {
            investor.setName((alfaClickUser.get("lastName") + " " + alfaClickUser.get("firstName") + " " + alfaClickUser.get("patronymicName")).trim());
        }

        // "document Series and Number"
        String documentSeriesAndNumber = org.springframework.util.StringUtils.trimAllWhitespace((String) alfaClickUser.get("documentNumber"));
        if (!StringUtils.isEmpty(documentSeriesAndNumber))  {
            investor.setDocumentSeriesNumber(documentSeriesAndNumber);
        }

        // "documentSeries"
        String series = documentSeriesAndNumber.substring(0,4);
        if (!StringUtils.isEmpty(series)) {
            investor.setDocumentSeries(series);
        }

        // "documentNumber"
        String number = documentSeriesAndNumber.substring(4);
        if (!StringUtils.isEmpty(number)) {
            investor.setDocumentNumber(number);
        }


        // "issueDate" 12.07.2013
        //
        String issueDate = (String) alfaClickUser.get("issueDate");
        java.util.Date issueDateParse = parseAKDate(issueDate);
        if ((!StringUtils.isEmpty(issueDate)) && (issueDateParse != null)) {
                investor.setDocDate(new Date(issueDateParse.getTime()));
        }

        // "documentOrganization"
        String documentOrganization = (String) alfaClickUser.get("documentOrganization");
        if (!StringUtils.isEmpty(documentOrganization)) {
            investor.setDocumentIssuer(documentOrganization);
        }
        // "union":"712-512" // код подразделения
        String union = (String)alfaClickUser.get("union");
        if (!StringUtils.isEmpty(union)) {
            investor.setDocumentIssuerCode(union);
        }
        // "dateOfBirth"
        String dateOfBirth = (String) alfaClickUser.get("dateOfBirth");
        java.util.Date dateOfBirthParse = parseAKDate(dateOfBirth);
        if ((!StringUtils.isEmpty(dateOfBirth)) && (dateOfBirthParse != null)) {
            investor.setBirthDate(new Date(dateOfBirthParse.getTime()));

        }

        // "placeOfBirth"
        String placeOfBirth = (String)alfaClickUser.get("placeOfBirth");
        if (!StringUtils.isEmpty(placeOfBirth)) {
            investor.setBirthplace(placeOfBirth);
        }
        // "email"
        String email = (String)alfaClickUser.get("email");
        if (!StringUtils.isEmpty(email)) {
            investor.setInvestorMail(email);
        }
        // phone
        String phone = (String) alfaClickUser.get("mbln");
        if (!StringUtils.isEmpty(phone)) {
            investor.setInvestorCellPhone(phone);
        }


        // тут несовсем понятно что будет в токене если вдруг адрес не пришел, поэтому адрес всега берем из токена
        /*
         Альфа клик перепутал адреса местами, поэтому следующий код закоментирован
        */
        Map<String, Object> registrationAddress = (Map<String, Object>) alfaClickUser.get("registrationAddress");
        Map<String, Object> actualAddress = (Map<String, Object>) alfaClickUser.get("actualAddress");
        /**
         *
         * боольше не закоментирован, вот так должно быть чтобы адреса тянулись как надо
         *
         */
        //Map<String, Object> registrationAddress = (Map<String, Object>) alfaClickUser.get("actualAddress");
        //Map<String, Object> actualAddress = (Map<String, Object>) alfaClickUser.get("registrationAddress");
        if (jsonView) {
            investor.setJureAddress(parseAlfaClickAddressHumanize(registrationAddress));
            investor.setRealAddress(parseAlfaClickAddressHumanize(actualAddress));
        } else {
            investor.setJureAddress(parseAlfaClickAddress(registrationAddress));
            investor.setRealAddress(parseAlfaClickAddress(actualAddress));
        }
    }

    private String parseAlfaClickAddressHumanize(Map<String, Object> address) {

        // Индекс
        StringBuilder sb = new StringBuilder();
        String postalCode =     (String)address.get("postalCode");
        sb.append(postalCode).append(", ");

        // страна
        String resCountry = (String)address.get("resCountry");
        sb.append("RU".equals(resCountry.toUpperCase()) ? "Россия" : resCountry).append(", ");

        // регион
        String regType = (String)address.get("regType");
        regType = Common.REGIONS_TYPE.containsKey(regType) ? Common.REGIONS_TYPE.get(regType).toLowerCase() + ". " : "";
        String regCode = (String)address.get("regCode");
        regCode = Common.REGIONS.containsKey(regCode) ?  Common.REGIONS.get(regCode) : regCode;
        String regName = StringUtils.isEmpty((String)address.get("regName")) ?  regCode : (String)address.get("regName");
        if (!StringUtils.isEmpty(regName)) {
            sb.append(regType).append(regName).append(", ");
        }

        // район
        String districtName =   (String)address.get("districtName");
        if (!StringUtils.isEmpty(districtName)) {
            sb.append("район ").append(districtName).append(", ");
        }

        // город
        String city = (String)address.get("city");
        if (!StringUtils.isEmpty(city)) {
            sb.append("г. ").append(city).append(", ");
        }

        // населенный пункт
        String settlementType = (String)address.get("settlementType");
        settlementType = Common.SETTELMENT_TYPE.containsKey(settlementType) ? Common.SETTELMENT_TYPE.get(settlementType).toLowerCase() + ". " : "";
        String settlementName = (String)address.get("settlementName");
        if (!StringUtils.isEmpty(settlementName)) {
            sb.append(settlementType).append(settlementName).append(", ");
        }

        // улица
        String streetType = (String)address.get("streetType");
        streetType = Common.STREET_TYPE.containsKey(streetType) ? Common.STREET_TYPE.get(streetType).toLowerCase() + ". " : "";
        String streetName = (String)address.get("streetName");
        if (!StringUtils.isEmpty(streetName)) {
            sb.append(streetType).append(streetName).append(", ");
        }

        // номер дома
        if (!StringUtils.isEmpty((String)address.get("houseNumber"))) {
            sb.append("д. ").append((String) address.get("houseNumber")).append(", ");
        }

        // номер корпуса/строения
        if (!StringUtils.isEmpty((String)address.get("buildingNumber"))) {
            sb.append("к. ").append((String) address.get("buildingNumber")).append(", ");
        }

        // квартира
        String flatNumber =  (String)address.get("flatNumber");
        if (!StringUtils.isEmpty(flatNumber)) {
            sb.append("кв. ").append(flatNumber).append(", ");
        }
        // убираем последнюю точку с запятой // так сделано потомучто непонятно чего в адресе небудет
        return sb.replace(sb.length() - 2, sb.length(), "").toString();
    }

    private String parseAlfaClickAddress(Map<String, Object> address) {
        StringBuilder sb = new StringBuilder();
        String postalCode =     (String)address.get("postalCode");
        sb.append(postalCode).append(",");
        String resCountry =     (String)address.get("resCountry");
        sb.append("RU".equals(resCountry.toUpperCase()) ? "Россия" : resCountry).append(",");

        // распознование кода региона
        String regCode = (String)address.get("regCode");
        regCode = Common.REGIONS.containsKey(regCode) ?  Common.REGIONS.get(regCode) : regCode;
        String regName =        StringUtils.isEmpty((String)address.get("regName")) ?  regCode : (String)address.get("regName");
        sb.append(StringUtils.isEmpty(regName) ? "-" : regName).append(",");

        String districtName =   (String)address.get("districtName");
        sb.append(StringUtils.isEmpty(districtName) ? "-" : districtName).append(",");

        String city =           (String)address.get("city");
        sb.append(StringUtils.isEmpty(city) ? "-" : city).append(",");

        String settlementName = (String)address.get("settlementName");
        sb.append(StringUtils.isEmpty(settlementName) ? "-" : settlementName).append(",");

        String streetName =     (String)address.get("streetName");
        sb.append(StringUtils.isEmpty(streetName) ? "-" : streetName).append(",");

        StringBuilder house = new StringBuilder((String)address.get("houseNumber")); //  buildingNumber
        if (StringUtils.isEmpty((String)address.get("buildingNumber"))) {
            house.append(" ").append((String) address.get("buildingNumber"));
        }
        sb.append(StringUtils.isEmpty(house) ? "-" : house).append(",");

        String flatNumber =     (String)address.get("flatNumber");
        sb.append(StringUtils.isEmpty(flatNumber) ? "-" : flatNumber);
        return sb.toString();
    }

    public boolean isNumber(String str) {
        return ((str != null) && str.matches("\\d+(\\.\\d+)?"));
    }

    public AddressType kladrToAddressType(KladrAddress kladrAddress) {
        //AddressType addressType = new AddressType();
        AddressType address = new AddressType();
        address.setCountry(kladrAddress.getCountry());
        address.setIndex(kladrAddress.getIndex());
        address.setRegion(kladrAddress.getRegion());
        address.setDistrict(kladrAddress.getDistrict());
        address.setCity(kladrAddress.getCity());
        address.setStreet(kladrAddress.getStreet());
        address.setHouse(kladrAddress.getBuilding());
        // в кладре нет строения
        address.setBuilding("");
        // зато в кладре есть locality
        //kladrAddress.getLocality()
        address.setFlat(kladrAddress.getFlat());
        address.setComment(kladrAddress.toString());
        return address;
    }

    /*
    @Deprecated
    private SurveyRequest prepareRequest(SSInvestorBean investor,
                                         String strategySysName,
                                         String strategyCurrencyCode,
                                         BigDecimal amount,
                                         KladrAddress kladrRealAddress,
                                         KladrAddress kladrJureAddress) {

        SurveyRequest request = new SurveyRequest();
        String[] fio = investor.getName().trim().split(" ");
        request.setLastName ((fio.length > 0 ? fio[0] : investor.getName()));
        request.setFirstName (fio.length > 1 ? fio[1] : "");
        request.setMiddleName(fio.length > 2 ? fio[2] : "");

        try {
            GregorianCalendar date = new GregorianCalendar();
            date.setTime(investor.getBirthDate());
            request.setBirthday(DatatypeFactory.newInstance().newXMLGregorianCalendar(date));
        } catch (DatatypeConfigurationException e) {
            logger.error("Не указана или указана неверно дата рождения");
        }
        request.setEmail(investor.getInvestorMail());
        request.setCellPhone(investor.getInvestorCellPhone());
//        request.setEmail("dev@alfacapital.ru");
//        request.setCellPhone("телефон");

        request.setProductId(strategySysName);
        request.setCurrencyCode(strategyCurrencyCode);
        request.setAmount(amount);

        request.setBirthplace(investor.getBirthplace());

        request.setUsaCitizen(investor.getUsaCitizen() == 1 ? "Да" : "Нет");

        if (investor.getGender() != null) request.setGender(investor.getGender());

        DocumentType doc = new DocumentType();

        doc.setNumber(investor.getDocumentNumber());
        doc.setSeries(investor.getDocumentSeries());

        doc.setIssuer(investor.getDocumentIssuer());
        doc.setIssuerCode(investor.getDocumentIssuerCode());


        // todo тут всегда будет паспорт !!!
        // todo: А если иностранец ???
        // todo: в ss.mv_investor это текстовое значение, а в du.tab_contract - ссылка на справочник

        doc.setType("1");
        investor.getDocumentType();

        GregorianCalendar date = new GregorianCalendar();
        date.setTime(investor.getDocDate());
        try {
            doc.setIssueDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(date));
        } catch (DatatypeConfigurationException e) {
            logger.error("Не указана или указана неверно дата выдачи документа");
        }

        request.setDocument(doc);
        request.setInn(investor.getInn() == null ? "" : investor.getInn());

        //todo: А если иностранец ???
        request.setRussianResident(true);
        request.setPostAddress(kladrToAddressType(kladrRealAddress));
        request.setRegistrationAddress(kladrToAddressType(kladrJureAddress));
        request.setRulesAccepted(true);
        return request;
    }

    */

    public void setInvestorData(SurveyRequest request, SSInvestorBean investor) {
        String[] fio = investor.getName().trim().split(" ");
        request.setLastName ((fio.length > 0 ? fio[0] : investor.getName()));
        request.setFirstName (fio.length > 1 ? fio[1] : "");
        request.setMiddleName(fio.length > 2 ? fio[2] : "");

        try {
            GregorianCalendar date = new GregorianCalendar();
            date.setTime(investor.getBirthDate());
            request.setBirthday(DatatypeFactory.newInstance().newXMLGregorianCalendar(date));
        } catch (DatatypeConfigurationException e) {
            logger.error("Не указана или указана неверно дата рождения");
        }
        request.setEmail(investor.getInvestorMail());
        request.setCellPhone(investor.getInvestorCellPhone());
//        request.setEmail("dev@alfacapital.ru");
//        request.setCellPhone("телефон");
        request.setBirthplace(investor.getBirthplace());
        request.setUsaCitizen(investor.getUsaCitizen() == 1 ? "Да" : "Нет");
        if (investor.getGender() != null) request.setGender(investor.getGender());
        DocumentType doc = new DocumentType();
        doc.setNumber(investor.getDocumentNumber());
        doc.setSeries(investor.getDocumentSeries());
        doc.setIssuer(investor.getDocumentIssuer());
        doc.setIssuerCode(investor.getDocumentIssuerCode());


        // todo тут всегда будет паспорт !!!
        // todo: А если иностранец ???
        // todo: в ss.mv_investor это текстовое значение, а в du.tab_contract - ссылка на справочник
        doc.setType("1");
        investor.getDocumentType();
        GregorianCalendar date = new GregorianCalendar();
        date.setTime(investor.getDocDate());
        try {
            doc.setIssueDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(date));
        } catch (DatatypeConfigurationException e) {
            logger.error("Не указана или указана неверно дата выдачи документа");
        }
        request.setDocument(doc);
        request.setInn(investor.getInn() == null ? "" : investor.getInn());
        //todo: А если иностранец ???
        request.setRussianResident(true);
        request.setRulesAccepted(true);
    }

    private static java.util.Date parseAKDate(String date) {
        try {
            return ALFA_CLICK_DATE_FORMATER.parse(date);

        } catch (ParseException e) {
            // если не получилось пробуем другой фромат
        }
        try {
            return DATE_FORMATER.parse(date);
        } catch (ParseException e) {
            // если не получилось возвращаем нчего
        }
        return null;
    }

}
