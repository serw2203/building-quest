package ru.alfacapital.alphecca.services.legacy;

import java.io.Serializable;
import java.math.BigDecimal;

public class SSAMOperBean implements Serializable {

    private String operationId;
    private String investorId;
    private String contractId;
    private Long dateDQ;
    private BigDecimal amount;
    private int investmentType;

    private BigDecimal currencyAmount;

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public int getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(int investmentType) {
        this.investmentType = investmentType;
    }

    public Long getDateDQ() {
        return dateDQ;
    }

    public void setDateDQ(Long dateDQ) {
        this.dateDQ = dateDQ;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getCurrencyAmount() {
        return currencyAmount;
    }

    public void setCurrencyAmount(BigDecimal currencyAmount) {
        this.currencyAmount = currencyAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SSAMOperBean that = (SSAMOperBean) o;

        if (operationId != null ? !operationId.equals(that.operationId) : that.operationId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return operationId != null ? operationId.hashCode() : 0;
    }

}