package ru.alfacapital.alphecca.services.legacy.data.model;

import ru.alfacapital.alphecca.services.legacy.CurrencyRater;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class SSConstants {

    public static final int TYPE_FUND = 0;
    public static final int TYPE_AM = 2;

    public static final Map<Integer, String> TYPE_NAMES = new HashMap<Integer, String>();

    static {
        TYPE_NAMES.put(TYPE_FUND, "Паевые фонды");
        TYPE_NAMES.put(TYPE_AM, "Доверительное управление");
    }

    /**
     * 946674000000L = 01.01.2000
     */
    public static final Long ZERO_DQ = 946674000000L;

    public static Long toDQ(Date date) {
        return Math.round((date.getTime() - ZERO_DQ) / 86400000.0);
    }

    public static java.sql.Date toDate(Long dq) {
        return new java.sql.Date(dq * 86400000 + ZERO_DQ);
    }

    public static BigDecimal rate(CurrencyRater rater, BigDecimal value, String currencyCode, Long dateDQ) {
        if (value == null) return null;
        if (currencyCode.equals("RUB")) {
            return value;
        }
        else {
            return rater.rate(value, currencyCode, SSConstants.toDate(dateDQ));
        }
    }

//    public static void main(String[] args) throws ParseException {
//        final Date date = DateUtils2.parseDate("01.01.2000");
//        System.out.println(new SimpleDateFormat("dd.MM.yyyy").format(date));
//        System.out.println(date.getTime());
//    }

}
