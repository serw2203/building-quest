package ru.alfacapital.alphecca.services.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 11.12.2014
 *
 * @author y.bocharov
 */
@Repository
public class PasswordDao {

    private static final Logger log = LoggerFactory.getLogger(PasswordDao.class);

    private NamedParameterJdbcTemplate jdbc;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        jdbc = new NamedParameterJdbcTemplate(dataSource);
    }

    // старый пароль в запросе является избыточным, добавлен чтобы во время тестирования не сменить пароль не тому пользователю
    public boolean modifyPassword(String investorId, String oldPassword, String newPassword, Date changeDate) {

        String sql = " update SS.TAB_LOGIN " +
                     " set PASSWORD_CHANGE_DATE = :changeDate, " +
                     "     PASSHASH = :newPassword " +
                     " where INVESTOR_ID = :investorId and PASSHASH = :oldPassword";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("investorId", investorId);
        params.put("oldPassword", oldPassword);
        params.put("newPassword", newPassword);
        params.put("changeDate", changeDate);
        try {
            log.trace("Query change password :  {}", sql);
            int rows = jdbc.update(sql, params);
            log.info("Change password for investorId {} complete. Change rows: {}", investorId, rows);
            return rows > 0;
        }
        catch (DataAccessException ex) {
            log.error("DataAccessException: {}", ex.getMessage());
            return false;
        }
    }

    public String getPassword(String investorId) {
        String sql = "SELECT PASSHASH FROM SS.TAB_LOGIN where INVESTOR_ID = :investorId";
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("investorId", investorId);
        return jdbc.queryForObject(sql, params, String.class);
    }
}
