select distinct fund_id, name, order_number, order_date from (
  select o.fund_id, f.name,
    first_value(o.order_number) over (partition by o.investor_id, o.fund_id order by o.order_date desc) order_number,
    first_value(o.order_date) over (partition by o.investor_id, o.fund_id order by o.order_date desc) order_date
  from SS_DATALINK.mv_mf_order o, ss_datalink.mv_fund f
  where o.order_date >= to_date('01082008', 'DDMMRRRR') and order_type = 'Выдача паев'
        and o.fund_id = f.fund_id
        and o.investor_id = :investorId)
