SELECT SYS_NAME as file_name, FILE_DATA as bytes, MIME_TYPE mime_type
FROM SS.TAB_FILES 
where FILES_GROUP = 'OPEN_RESOURCES' and   SYS_NAME = :resName