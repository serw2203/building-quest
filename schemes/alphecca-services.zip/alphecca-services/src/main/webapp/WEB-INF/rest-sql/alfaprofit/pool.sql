/*todo: стоп пула считается не точно*/
/*todo: так ничего не увидят люди с нестартовавшим пулом */
select pc.start_date - to_date('01012000', 'DDMMRRRR') start_date_dq,
       c.step_months, c.strategy_months, c.disclaimer, c.contract_number,
       c.contract_date - to_date('01012000', 'DDMMRRRR') contract_date_dq,
       add_months(pc.start_date, c.strategy_months) - to_date('01012000', 'DDMMRRRR') stop_date_dq,
       o.in_amount, o.min_dq, c.name strategy_name, pc.composite_id product_id
  from ss_datalink.mv_pool_content pc, ss.vie_ss_contract c, (select contract_id, sum(rub_amount) in_amount, min(wiring_date_dq) min_dq from ss.vie_am_cashflow group by contract_id) o
 where pc.contract_id = c.id and c.investor_id = :investorId and pc.contract_id = :contractId and o.contract_id = :contractId

