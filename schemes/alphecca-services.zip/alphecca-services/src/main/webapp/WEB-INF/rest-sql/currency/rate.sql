select cr.rate_to_rub rate
  from ss_datalink.mv_currency_rate cr, ss_datalink.mv_currency c
 where c.currency_id = cr.currency_id and c.iso_alpha3 = :currency and cr.rate_date_dq = :dateDQ
