select report_id id, name, mime_type, to_char(publication_date, 'DD.MM.RRRR HH24:MI') publication_date_fmtd, to_char(report_date, 'RRRR') year, to_char(report_date, 'MM') month
from ss.tab_report
where (investor_id = :investorId or contract_id in (select contract_id from ss_datalink.mv_contract where investor_id = :investorId))
  and show_to_client = 1
order by report_date