select wiring_date_dq dq, sum(rub_amount) val, sum(rub_amount) total
  from ss.vie_am_cashflow
 where investor_id = :investorId and contract_id = :id
   and wiring_date_dq <= (select max_report_date - to_date('01.01.2000', 'DD.MM.RRRR') from ss.vie_investor_status where investor_id = :investorId)
 GROUP BY wiring_date_dq
 order by wiring_date_dq