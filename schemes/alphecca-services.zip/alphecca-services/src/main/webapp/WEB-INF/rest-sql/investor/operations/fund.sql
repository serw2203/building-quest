select
  f.NAME          as fundName,
  o.DOC_NUMBER          as requestNumber,
  o.WIRING_DATE         as wiringDate,
  o.DOC_DATE            as realWiringDate,
  o.OPERATION_TYPE_NAME as operationType,
  o.UNITS               as units,
  o.UNIT_COST           as unitCost,
  o.UPDOWN_AMOUNT_RUB   as updownAmountRub,
  o.DISCOUNT_AMOUNT_RUB as discountAmount,
  o.TAX_AMOUNT_RUB      as taxAmountRub,
  o.TOTAL               as total
from ss.mv_ss_operation o, ss_datalink.mv_fund f
where o.fund_id = f.fund_id
  and o.investor_id = :investorId
  and o.OPERATION_TYPE = 'MF_OPER'
order by o.wiring_date desc