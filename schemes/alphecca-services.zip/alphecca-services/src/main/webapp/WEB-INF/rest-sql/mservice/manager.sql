select u.MAIL as mail, u.FIRST_NAME || ' ' || u.LAST_NAME as name
from SS_DATALINK.MV_INVESTOR i, SS_DATALINK.MV_USER u , SS.TAB_LOGIN l
where i.USER_ID = u.USER_ID
and   l.INVESTOR_ID = i.INVESTOR_ID
and l.login = :param