select wiring_date_dq dq, sum(shares_qty) val, sum(AMOUNT_RUB) as total
  from ss_datalink.mv_mf_oper
 where fund_id = :id
   and investor_id = :investorId
   and wiring_date_dq <= (select max_report_date - to_date('01.01.2000', 'DD.MM.RRRR') from SS.vie_investor_status where investor_id = :investorId)
group by wiring_date_dq
order by wiring_date_dq