select d.dq, round(a.amount_rub, 2) val from
  (select position_date_dq dq,
          lead(position_date_dq, 1, 1000000) over (order by position_date_dq) nextdq,
     amount_rub from ss.mv_ss_contract_summary2
   where investor_id = :investorId and contract_id = :id) a,
  (select day_dq dq from ss_datalink.mv_day d) d
where d.dq >= a.dq and d.dq < a.nextdq and d.dq <= (select max_report_date - to_date('01.01.2000', 'DD.MM.RRRR') from SS.vie_investor_status where investor_id = :investorId)
order by dq
 
 