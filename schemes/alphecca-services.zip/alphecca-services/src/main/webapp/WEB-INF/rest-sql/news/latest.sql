select rss_id id, to_char(pub_date, 'DD.MM.RRRR') pub_date, title, link from (
  select rss_id, pub_date, title, link from SS_datalink.mv_rss order by pub_date desc
)
where rownum <= 3