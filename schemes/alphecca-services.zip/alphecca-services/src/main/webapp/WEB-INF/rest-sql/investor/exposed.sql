select e.currency_code, e.asset_class_id, e.top_asset_class_id, e.territory_id, e.country_id, e.issuer_id,
       nvl(i.name, 'Не определено') issuer_name, e.industry_id, e.position_value
  from table(cast(ss.fun_get_position2(:investorId, to_date('01012000', 'DDMMRRRR') + :dateDQ) as ss.position_tab_type)) e, ss_datalink.mv_issuer i
 where e.issuer_id = i.issuer_id(+)