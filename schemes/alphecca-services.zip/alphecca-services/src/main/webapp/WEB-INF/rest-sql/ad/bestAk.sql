select idea_id, name, product_id, product_type, yield, currency,  strategy_months,
CASE NVL(min_amount_ak, 0) when 0 then min_amount else min_amount_ak end as min_amount
from (
    select y.idea_id, cf.name, y.product_id, y.product_type, y.yield, cu.iso_alpha3 as currency,
           cf.min_amount, min_amount_ak, coalesce(cf.strategy_months, 12) as strategy_months from ss.vie_composite_yield y
    join (select composite_id as product_id, name, currency_id, blocked, min_amount, strategy_months, min_amount_ak
          from ss_datalink.mv_composite
          union
          select f.fund_id as product_id, f.name, c.currency_id, 0 as blocked, 0 as min_amount, 12  as strategy_months, min_amount_ak
          from ss_datalink.mv_fund f
          join ss_datalink.mv_currency c on c.iso_alpha3 = 'RUB'  ) cf on  y.product_id = cf.product_id
    join ss_datalink.mv_currency cu on cf.currency_id = cu.currency_id
    where y.start_date = to_date(:startDate, 'DD.MM.RRRR') and y.stop_date = to_date(:stopDate, 'DD.MM.RRRR')
          /*and coalesce(cf.blocked, 0) = 0*/ and y.is_enabled = 1
          and cf.product_id in (select coalesce(composite_id, fund_id ) from ss_datalink.mv_user_product
          where user_id = 3132718441)
     order by y.product_type desc, y.yield desc
) where rownum <= 3