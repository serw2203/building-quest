select CONTRACT_NUMBER as contractNumber, TO_CHAR(WIRING_DATE, 'DD.MM.YYYY') as dateWiring, OPERATION_TYPE_NAME as operationType, CURRENCY_CODE as currencyCode, TOTAL as total
from ss.mv_ss_operation
where OPERATION_TYPE <> 'MF_OPER'
and investor_id = :investorId
and WIRING_DATE > TO_DATE(:startDate, 'DDMMYYYY')
and WIRING_DATE < TO_DATE(:endDate,'DDMMYYYY')
order by wiring_date desc