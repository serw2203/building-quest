select e.mail_box_entry_id, e.information_message_id, e.new_message, to_char(m.message_date, 'DD.MM.RRRR') send_date, m.message_title subj
from ss.tab_mail_box_entry e, ss.tab_information_message m
where e.information_message_id = m.information_message_id and e.message_type = 0
      and e.login_id in (select login_id from ss.tab_login where investor_id = :investorId)
order by m.message_date desc