select c.contract_number, to_char(c.contract_date, 'DD.MM.RRRR') contract_date, c.name product_name
  from ss.vie_ss_contract c
 where c.investor_id = :investorId and c.contract_id = :contractId