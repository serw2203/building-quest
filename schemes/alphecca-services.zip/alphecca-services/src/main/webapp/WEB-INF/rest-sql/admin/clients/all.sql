select name, manager, email, phone, login, id from
  (select rownum idx, name, manager, email, phone, login, id from (
      select investor_id id, name, document_series, document_number, full_name manager, login, investor_email email, investor_cell_phone phone from ss.vie_ss_investor
       where lower(name) like lower(:search || '%') and length(trim(:search)) >= 1
         and user_id in (select column_value from table(ss.user_ids(:login, :noFilters)))
       order by name asc))
where idx >= :start and idx < :start + :length



