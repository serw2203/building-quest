select cr.rate_date_dq, cr.rate_to_rub
  from ss_datalink.mv_currency_rate cr
  join ss_datalink.mv_currency c on c.currency_id = cr.currency_id
 where c.iso_alpha3 = :currency and cr.RATE_DATE_DQ between :minDateDQ and :maxDateDQ
