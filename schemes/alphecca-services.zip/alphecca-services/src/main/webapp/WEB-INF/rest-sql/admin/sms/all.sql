select send_date_fmtd send_date, status, phone, gate, message from
  (SELECT
     rownum idx,
     send_date_fmtd,
     status,
     phone,
     gate,
     message
   FROM
     (SELECT
        to_char(send_date, 'DD.MM.RRRR HH24:MI:SS') send_date_fmtd,
        status,
        phone,
        gate,
        message,
        send_date
      FROM ss.tab_sms
      WHERE login_id IN (SELECT login_id
                         FROM ss.vie_ss_investor
                         WHERE investor_id = :investorId)
      ORDER BY send_date DESC)
  )
where idx >= :start and idx < :start + :length
