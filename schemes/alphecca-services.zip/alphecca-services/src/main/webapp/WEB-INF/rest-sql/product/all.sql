select c.composite_id id, c.name, c.description, c.investment_goal, c.benchmark_id,
       c.strategy_months, c.step_months, c.coeff_yield, c.cancel_condition, c.disclaimer,
       c.currency_id, cr.iso_alpha3, cr.name as currencyname, c.min_amount, c.sys_name, nvl(c.blocked, 0) is_blocked
  from ss_datalink.mv_composite c
  join ss_datalink.mv_currency cr on c.currency_id = cr.currency_id
 where c.composite_id in (select composite_id from ss.tab_idea2 where composite_id is not null) and nvl(c.blocked, 0) = 0
 and c.min_amount is not null
 and c.strategy_months is not null
