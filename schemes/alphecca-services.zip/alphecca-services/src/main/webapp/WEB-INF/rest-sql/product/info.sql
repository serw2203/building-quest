select c.composite_id id, c.name, c.description, c.investment_goal, c.benchmark_id,
       c.strategy_months, c.step_months, c.coeff_yield, c.cancel_condition, c.disclaimer,
       c.currency_id, cr.iso_alpha3, cr.name as currencyname,c.min_amount, c.sys_name,
       nvl(blocked, 0) is_blocked,
       c.selection_type, c.PAY_RECEIVER, c.PAY_RECEIVER_ADDRESS, c.PAY_RECEIVER_ACCOUNT,
       c.PAY_BANK, c.PAY_BANK_ADDRESS, c.PAY_BANK_SWIFT, c.PAY_CORR_BANK, c.PAY_CORR_BANK_SWIFT, c.PAY_CORR_BANK_ACCOUNT,
       c.PAY_INN, c.PAY_KPP, c.PAY_BANK_BIK, c.PAY_BANK_CORR_ACCOUNT,
       'Перевод в доверительное управление по договору доверительного управления, заключаемого путем присоединения посредством сети «Интернет»' purpose
  from ss_datalink.mv_composite c
  join ss_datalink.mv_currency cr on c.currency_id = cr.currency_id
 where c.composite_id = :productId
