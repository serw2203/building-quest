select name clientName,
       document_series || ' ' || document_number clientDocument,
       full_name managerName,
       login clientLogin,
       decode(nvl(legal_entity, 0), 0, 'Физическое лицо', 'Юридическое лицо') clientType,
       is_blocked clientBlocked,
       investor_cell_phone effectivePhone,
       investor_email effectiveEmail
from ss.vie_ss_investor
where investor_id = :investorId