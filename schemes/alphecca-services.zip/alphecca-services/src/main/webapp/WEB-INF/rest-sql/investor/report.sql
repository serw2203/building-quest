select report_body bytes, name file_name, mime_type
  from ss.tab_report
 where report_id = :reportId
   and (investor_id = :investorId or contract_id in (select contract_id from ss_datalink.mv_contract where investor_id = :investorId))