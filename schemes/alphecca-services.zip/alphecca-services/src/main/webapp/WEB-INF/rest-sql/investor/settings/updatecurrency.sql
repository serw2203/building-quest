update SS.TAB_LOGIN 
set REPORT_CURRENCY_ID = (select currency_Id from ss_datalink.mv_currency where ss_available = 1 and iso_alpha3 = :currency)
where INVESTOR_ID = :investorId
and :currency in (select iso_alpha3 from ss_datalink.mv_currency where ss_available = 1 union select 'auto' from dual)