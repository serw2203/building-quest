select nav_date_dq dq, share_value val
  from SS.mv_fund_nav
 where fund_id = :id
   and ((nav_date <= (select max_report_date from SS.mv_investor_status2 where investor_id = :investorId)) or
        (select count(*) from SS.mv_investor_status2 where investor_id = :investorId) = 0)
   and nav_date_dq >= (select min(wiring_date_dq) from ss_datalink.mv_mf_oper where investor_id = :investorId and fund_id = :id)
order by nav_date_dq