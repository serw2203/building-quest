select
  ASSET_NAME          as fundName,
  DOC_NUMBER || ' ' || DOC_DATE      as requestNumber,
  TO_CHAR(WIRING_DATE, 'DD.MM.YYYY') as wiringDate,
  OPERATION_TYPE_NAME as operationType,
  UNITS               as units,
  UNIT_COST           as unitCost,
  case when UPDOWN_AMOUNT_RUB is null or UPDOWN_AMOUNT_RUB = 0 then DISCOUNT_AMOUNT_RUB else UPDOWN_AMOUNT_RUB end DISCOUNT_UPDOWN,
  TAX_AMOUNT_RUB      as taxAmountRub,
  TOTAL               as total
from ss.mv_ss_operation
where investor_id = :investorId
and OPERATION_TYPE = 'MF_OPER'
and WIRING_DATE > TO_DATE(:startDate, 'DDMMYYYY')
and WIRING_DATE < TO_DATE(:endDate,'DDMMYYYY')
order by wiring_date desc