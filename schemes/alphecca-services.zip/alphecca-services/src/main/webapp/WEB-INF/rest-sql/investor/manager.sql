SELECT m.USER_ID,
       m.PARENT_USER_ID,
       m.FIRST_NAME,
       m.LAST_NAME,
       case when m.user_id is null then 'customerservices@alfacapital.ru' else m.MAIL end mail,
       case when m.user_id is null then '+7 (495) 783-4-783' else m.MOBILE end mobile,
       case when m.user_id is null then '+7 (800) 200-28-28' else '' end mobile2,

       case when m.photo   is null  then r.PHOTO else m.PHOTO end PHOTO,
       case when m.photo   is null  then r.PHOTO_MIME_TYPE else m.PHOTO_MIME_TYPE end PHOTO_MIME_TYPE,
       case when m.user_id is null then 1 else (case when m.photo is null then 0 else 1 end) end contain_photo

  FROM SS_DATALINK.MV_USER m,
       SS_DATALINK.MV_INVESTOR i,
       (select * from (select FILE_DATA as PHOTO, MIME_TYPE as PHOTO_MIME_TYPE
                       from SS.TAB_FILES
                       where FILES_GROUP = 'CONSULTANT_RANDOM_PHOTO'
                       order by dbms_random.normal
       ) where rownum = 1) r

 where m.USER_ID(+) = i.USER_ID
   and m.is_active(+) = 1
   and i.INVESTOR_ID = :investorId
