select s.FROM_FUND_ID  as FROM_FUND_ID, s.TO_FUND_ID as TO_FUND_ID, nf1.SHARE_VALUE as from_value, nf2.SHARE_VALUE as to_value from
SS.TAB_FUND_SWAP s, 
(select max(NAV_DATE_DQ) as max_date from SS.MV_FUND_NAV where FUND_ID = 2867829943 and SHARE_VALUE <> 0) md,
SS.MV_FUND_NAV nf1,
SS.MV_FUND_NAV nf2
where s.FROM_FUND_ID = nf1.FUND_ID 
and   s.TO_FUND_ID = nf2.FUND_ID 
and   nf1.NAV_DATE_DQ = md.max_date
and   nf2.NAV_DATE_DQ = md.max_date
and   s.FROM_FUND_ID = 2867829943
and   nf2.SHARE_VALUE <> 0