select type, id, product_id, name, contract_number, contract_date_fmtd, status from (
  select 'PE' type, pc.id id, pc.composite_id product_id, c.name, pc.application_number contract_number, null contract_date, null contract_date_fmtd, status_name status from ss.tab_pending_contract pc, ss_datalink.mv_composite c where pc.composite_id = c.composite_id and pc.investor_id = :investorId
  union all
  select 'PF' type, pr.id id, pr.FUND_ID product_id, f.name, pr.application_number contract_number, null contract_date, null contract_date_fmtd, status_name status from SS.TAB_PENDING_REQUEST pr, SS_DATALINK.MV_FUND f where pr.FUND_ID = f.FUND_ID and pr.investor_id = :investorId
) order by decode(type, 'MF', 0, 'AM', 1, 'AP', 2, 'PE', 100, 3), contract_date, contract_number, name
