select CONTRACT_NUMBER as contractNumber, OPERATION_TYPE_NAME as operationType, WIRING_DATE as dateWiring, CURRENCY_CODE as currencyCode, TOTAL as total
from ss.mv_ss_operation
where OPERATION_TYPE <> 'MF_OPER'
and investor_id = :investorId
order by wiring_date desc