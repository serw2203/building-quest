select y.aum_date - to_date('01012000', 'DDMMRRRR') aum_date_dq, y.rate, y.yield
  from ss_datalink.mv_pool_yield y
 where y.composite_id = :productId and y.start_date = to_date('01012000', 'DDMMRRRR') + :startDateDQ
