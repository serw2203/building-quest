select s.MAX_REPORT_DATE - to_date('01012000', 'DDMMRRRR') max_report_date_dq,
       s.INFLOW,
       s.OUTFLOW,
       s.AUM,
       trunc(nvl(o.MIN_REPORT_DATE, s.MAX_REPORT_DATE)) - to_date('01012000', 'DDMMRRRR') min_report_date_dq,
       i.name,
       nvl(m.new_mail_count, 0) new_mail_count
  from ss.vie_investor_status s,
       (select min(WIRING_DATE) as MIN_REPORT_DATE from SS.MV_SS_OPERATION where investor_id = :investorId) o,
       (select login_id, nvl(override_name, case when legal_entity = 1 then name else trim(substr(name, instr(name, ' '))) end) name from ss.vie_ss_investor where investor_id = :investorId) i,
       (select login_id, count(*) new_mail_count from ss.tab_mail_box_entry where MESSAGE_TYPE = 0 and new_message > 0 group by login_id) m
 where s.investor_id = :investorId
   and m.login_id(+) = i.login_id
